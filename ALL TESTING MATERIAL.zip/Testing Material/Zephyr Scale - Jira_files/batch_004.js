;
/* module-key = 'com.atlassian.jira.jira-atlaskit-plugin:global-cache', location = 'jira-atlaskit-module/js/cache-api.js' */
!function(){var n,e=new Promise(function(e){n=e});AJS.namespace("JIRA.API"),JIRA.API.getCache=function(){return e},define("jira/cache",function(){return function(e){n(e)}})}();;