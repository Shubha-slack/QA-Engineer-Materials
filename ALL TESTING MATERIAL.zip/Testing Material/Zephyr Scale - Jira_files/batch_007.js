;try{window.performance.mark('jira.webresources,jira.webresources,com.atlassian.administration.atlassian-admin-quicksearch-jira,jira.webresources,com.atlassian.jira.plugins.jira-development-integration-plugin,com.atlassian.analytics.analytics-client,com.atlassian.jira.jira-issue-nav-plugin,com.atlassian.crowd.user-provisioning-vertigo-plugin,com.atlassian.jira.jira-atlaskit-plugin,com.atlassian.pas,com.atlassian.auiplugin,com.atlassian.jira.plugins.jira-development-integration-plugin,com.pyxis.greenhopper.jira_batch_file_eval:start');} catch(e){};;
/* module-key = 'jira.webresources:key-commands', location = '/includes/jquery/plugins/keyevents/keyevents.js' */
!function(e){function t(t,n,r){function i(t){var i=n(t);if(i){var c=new e.Event(r);c.key=i,"aui:keypress"!==r&&(c.shiftKey=t.shiftKey,c.ctrlKey=t.ctrlKey,c.altKey=t.altKey);var u=t.target,a=9===u.nodeType?u:u.ownerDocument;a!==document?(c.target=u,arguments[0]=c,e.event.trigger(c,arguments,document,!0)):e(u).trigger(c),c.isDefaultPrevented()&&t.preventDefault()}}var c=0;e.event.special[r]={setup:function(){0===c&&e(document).bind(t,i),c++},teardown:function(){c--,0===c&&e(document).unbind(t,i)}}}var n={8:"Backspace",9:"Tab",13:"Return",16:"Shift",17:"Control",18:"Alt",27:"Esc",32:"Spacebar",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"Left",38:"Up",39:"Right",40:"Down",46:"Del"},r={16:"Shift",17:"Control",18:"Alt"},i=0;t("keydown",function(e){if(e.which in r){if(e.which===i)return null;i=e.which}else i=0;return n[e.which]||null},"aui:keydown"),t("keypress",function(e){var t=e.altKey&&e.ctrlKey;switch(i=0,e.which){case 0:case 8:case 9:case 27:break;default:if(t||!e.ctrlKey&&!e.metaKey)return String.fromCharCode(e.which)}return null},"aui:keypress"),t("keyup",function(e){return e.which===i&&(i=0),n[e.which]||null},"aui:keyup")}(jQuery);;
;
/* module-key = 'jira.webresources:key-commands', location = '/includes/jquery/plugins/shortcuts/shortcuts.js' */
!function(t){function n(t){h&&r(),h=16!==t.which}function e(n){var e=t(n.target).prop("contenteditable");if(t(n.target).is(":input:not(button[type=button])")||"true"===e||""===e)return void r();a.push(n.key),clearTimeout(c),c=setTimeout(r,2e3),a.length>d&&a.shift();for(var o=a.join(""),i=0;i<o.length;i++){var s=o.slice(i);if(s in u){n.preventDefault(),n=new t.Event("shortcut"),n.data=s,u[s].call(document,n),a.length=0;break}}h=!1}function o(){h&&r()}function r(){a.length=0}function i(t,n){var e=t.length,o=n.length;if(e===o)return t===n;var r,i;return e<o?(r=n.indexOf(t),i=o-e):(r=t.indexOf(n),i=e-o),r>=0&&r<i}var u={},a=[],d=0,c=0,h=!1,s=t(document);t.event.special.shortcut={setup:function(){s.bind("keydown",n),s.bind("aui:keypress",e),s.bind("keyup",o)},teardown:function(){s.unbind("keydown",n),s.unbind("aui:keypress",e),s.unbind("keyup",o)},add:function(t){if(this!==document)throw new TypeError('"shortcut" event handlers must be bound at the document');if(void 0===t.data)throw new Error('No data argument supplied in call to jQuery.fn.bind("shortcut", '+(t.handler.name||"function")+")");if("string"!=typeof t.data)throw new TypeError("Object "+t.data+" is not a string");if(0===t.data.length)throw new Error("Shortcut sequence must not be empty");for(var n in u)if(i(n,t.data))return void console.log('Cannot bind new shortcut "'+t.data+'" due to conflict with existing shortcut "'+n+'"');t.data.length>d&&(d=t.data.length),u[t.data]=t.handler},remove:function(t){if(this!==document)throw new TypeError('"shortcut" event handlers must be bound at the document');delete u[t.data]}}}(jQuery);;
;
/* module-key = 'jira.webresources:key-commands', location = '/includes/ajs/keyboardshortcut/KeyboardShortcuts.js' */
define("jira/ajs/keyboardshortcut/keyboard-shortcut",["jira/util/formatter","aui/inline-dialog","wrm/context-path","jquery","underscore"],function(t,e,o,r,n){var i=o(),c=function(t,e){this._executer=null,this.shortcuts=[t],this._bindShortcut(t,e)};return c.prototype._bindShortcut=function(t,o){if("string"!=typeof t)throw new TypeError("KeyboardShortcut expects string; received "+typeof t);if(/^(?:ctrl|alt|shift|meta)+/i.test(t))throw new SyntaxError('KeyboardShortcut cannot bind the shortcut "'+t+'" because it uses a modifier');var n=this;r(document).bind("shortcut",t,function(r){n._executer&&!n._ignoreShortcut(r,t,o)&&(e.current&&e.current.hide(),n._executer(r),r.preventDefault())})},c.prototype._ignoreShortcut=function(t,e,o){var r=!1;return n.each(c._ignoreConditions,function(n){n(t,e,o)&&(r=!0)}),r},c.prototype._addShortcutTitle=function(e){var o=r(e),n=o.attr("title")||"",i="Type",c="then",u="OR",s=r.map(this.shortcuts,function(t){return" '"+t.split("").join("' "+c+" '")+"'"});n+=" ( "+i+s.join(" "+u+" ")+" )",o.attr("title",n)},c.prototype.moveToNextItem=function(t){this._executer=function(){var e,o=r(t),n=r(t+".focused");this._executer.blurHandler||r(document).one("keypress",function(t){27===t.keyCode&&n&&n.removeClass("focused")}),0===n.length?n=r(t).eq(0):(n.removeClass("focused"),e=r.inArray(n.get(0),o),e<o.length-1?(e+=1,n=o.eq(e)):(n.removeClass("focused"),n=r(t).eq(0))),n&&n.length>0&&(n.addClass("focused"),n.scrollIntoView(),n.find("a:first").focus())}},c.prototype.moveToPrevItem=function(t){this._executer=function(){var e,o=r(t),n=r(t+".focused");this._executer.blurHandler||r(document).one("keypress",function(t){27===t.keyCode&&n&&n.removeClass("focused")}),0===n.length?n=r(t+":last"):(n.removeClass("focused"),e=r.inArray(n.get(0),o),e>0?(e-=1,n=o.eq(e)):(n.removeClass("focused"),n=r(t+":last"))),n&&n.length>0&&(n.addClass("focused"),n.scrollIntoView(),n.find("a:first").focus())}},c.prototype.click=function(t){this._addShortcutTitle(t),this._executer=function(){var e=r(t).eq(0);e.length>0&&e.click()}},c.prototype.goTo=function(t){this._executer=function(){window.location.href=i+t}},c.prototype.followLink=function(t){this._addShortcutTitle(t),this._executer=function(){var e=r(t).eq(0);e.length>0&&("a"===e.prop("nodeName").toLowerCase()||"link"===e.prop("nodeName").toLowerCase())&&(e.click(),window.location.href=e.attr("href"))}},c.prototype.moveToAndClick=function(t){this._addShortcutTitle(t),this._executer=function(){var e=r(t).eq(0);e.length>0&&(e.click(),e.scrollIntoView())}},c.prototype.moveToAndFocus=function(t){this._addShortcutTitle(t),this._executer=function(e){var o=r(t).eq(0);o.length>0&&(o.focus(),o.scrollIntoView(),o.is(":input")&&e.preventDefault())}},c.prototype.evaluate=function(t){"function"!=typeof t&&(t=new Function(t)),t.call(this)},c.prototype.execute=function(t){var e=this;this._executer=function(){"function"!=typeof t&&(t=new Function(t)),t.call(e)}},c.prototype.or=function(t){return this.shortcuts.push(t),this._bindShortcut(t),this},c._ignoreConditions=[],c._shortcuts=[],c.addIgnoreCondition=function(t){c._ignoreConditions.push(t)},c.getKeyboardShortcutKeys=function(t){for(var e in c._shortcuts){var o=c._shortcuts[e];if(o.moduleKey===t)return o.keys.toString()}return null},c.fromJSON=function(t){var e;return t&&(c._shortcuts=t,e={},n.each(t,function(t){t.keys.forEach(function(o){var r=o.join("");if(o.length<r.length)throw new Error("Shortcut sequence ["+o.join(",")+"] contains invalid keys");var n=e[r]=new c(r,t.context);n[t.op](t.param)})})),e},c}),AJS.namespace("AJS.KeyboardShortcut",null,require("jira/ajs/keyboardshortcut/keyboard-shortcut"));;
;
/* module-key = 'jira.webresources:key-commands', location = '/includes/ajs/keyboardshortcut/initKeyboardShortcuts.js' */
!function(){var r=require("jira/ajs/keyboardshortcut/keyboard-shortcut"),e=require("jira/ajs/keyboardshortcut/keyboard-shortcut-toggle"),t=require("jira/util/data/meta"),u=require("jira/dialog/dialog"),a=require("aui/dropdown"),o=require("aui/popup"),i=require("jquery"),n=require("wrm/data");r.addIgnoreCondition(function(){return o.current||a.current||u.current||e.areKeyboardShortcutsDisabled()}),i(function(){t.get("keyboard-shortcuts-enabled")?e.enable():e.disable();var u=n.claim("jira.webresources:key-commands.shortcuts");u&&(AJS.activeShortcuts=r.fromJSON(u),i(document).bind("aui:keyup",function(r){var e,t;"Esc"===r.key&&(e=i(r.target),e.is(":input:not(button[type='button'])")&&(t=new i.Event("beforeBlurInput"),e.trigger(t,[{reason:"escPressed"}]),t.isDefaultPrevented()||e.blur()))}))})}();;
;
/* module-key = 'jira.webresources:key-commands', location = '/includes/ajs/whenitype/whenIType.js' */
!function(r){AJS.whenIType=function(e,n){return new r(e,n)},AJS.whenIType.fromJSON=r.fromJSON}(require("jira/ajs/keyboardshortcut/keyboard-shortcut"));;
;
/* module-key = 'jira.webresources:header', location = '/includes/jira/common/headerModule.js' */
define("jira/common/header",["jira/util/formatter","jira/message","jira/issue","jira/util/events","jquery","exports","wrm/context-path"],function(e,n,t,s,i,r,o){var a,c,u,d,p={},f={getPath:function(){return window.location.pathname}},m=function(n,t){var s=n.substr(0,n.indexOf("-"));return e.format('<a href="{0}" target="_blank">',o()+"/plugins/servlet/project-config/"+s+"/"+t)},l=function(e){e&&n.showSuccessMsg(e,{closeable:!0}),p={}},I=function(e,n){var t="";return p.versionCreated&&(t="<p>"+e+"</p>"),p.componentCreated&&(t+="<p>"+n+"</p>"),t},g=function(){var e=/jira\/software\/(c\/)?projects\/[a-zA-Z0-9]+\/boards\/\d+\/roadmap/g;return e.test(f.getPath())},v=function(){var e=/jira\/software\/projects\/[a-zA-Z0-9]+\/((boards\/\d+(\/)?$)|(boards\/\d+\/backlog)\/?)/g;return e.test(f.getPath())},b=function(){return!!(JIRA&&JIRA.Issues&&JIRA.Issues.Application)&&JIRA.Issues.Application};r.initialize=function(){s.bind("QuickCreateIssue.sessionComplete",a=function(n,s){if(!g()&&!v()){var i=[].concat(s).pop(),r=t.issueCreatedMessage(i);r+=I(e.format("You also added a new version to this project. You can set a release date for this version in {0}project admin{1}.",m(i.issueKey,"versions"),"</a>"),e.format("You also added a new component to this project. You can assign a component lead for this component in {0}project admin{1}.",m(i.issueKey,"administer-components"),"</a>")),l(r)}}),b()&&b().on("issueEditor:saveSuccess",c=function(n){var s=n&&n.issueKey?n.issueKey:t.getIssueKey(),i=I(e.format("A new version has been added to your project. You can set a release date for this version in {0}project admin{1}.",m(s,"versions"),"</a>"),e.format("A new component has been added to your project. You can assign a component lead for this component in {0}project admin{1}.",m(s,"administer-components"),"</a>"));l(i)}),s.bind("Issue.Version.new.selected",u=function(){p.versionCreated=!0}),s.bind("Issue.Component.new.selected",d=function(){p.componentCreated=!0})},r.unbind=function(){s.unbind("QuickCreateIssue.sessionComplete",a),s.unbind("Issue.Version.new.selected",u),s.unbind("Issue.Component.new.selected",d),b()&&b().unbind("issueEditor:saveSuccess",c)},r.location=f});;
;
/* module-key = 'jira.webresources:header', location = '/includes/jira/common/initHeader.js' */
!function(){var i=require("jira/common/header");jQuery(function(){i.initialize()})}();;
;
/* module-key = 'com.atlassian.administration.atlassian-admin-quicksearch-jira:admin-quicksearch-webresources', location = 'atlassian-admin-quicksearch-jira-module/com/atlassian/administration/quicksearch/jira/js/adminQuickNav.js' */
/**
 * Shifter group for admin search
 */
require([
    'jquery',
    'underscore',
    'jira/ajs/ajax/smart-ajax',
    'jira/shifter',
    'wrm/context-path'
], function (jQuery,
             _,
             SmartAjax,
             Shifter,
             contextPath) {
    Shifter.register(function () {
        var suggestionsDeferred = jQuery.Deferred();

        function formatItem(item) {
            return {
                label: item.label,
                value: item.linkUrl,
                keywords: item.aliases
            };
        }

        function formatResponseSPA(data) {
            // In SPA underscore is replaced by Lodash that has .flatMap instead of .flatten
            var flatMap = _.flatMap
                ? _.flatMap
                : function(collection, fn) {
                    return _.flatten(_.map(collection, fn));
                }

            function getItems(section) {
                return _.map(section.items, formatItem).concat(flatMap(section.sections, getItems));
            }

            return getItems(data)
        }

        SmartAjax.makeRequest({
            dataType: 'json',
            url: contextPath() + '/rest/adminquicksearch/latest/links/default'
        })
            .pipe(formatResponseSPA)
            .done(function (suggestions) {
                suggestionsDeferred.resolve(suggestions);
            })
            .fail(function () {
                suggestionsDeferred.reject();
            });

        return {
            id: 'admin',
            name: "Administration Search",
            weight: 500,
            getSuggestions: function () {
                return suggestionsDeferred;
            },
            onSelection: function (value) {
                var ContainerApi;
                var nativeNavigate = function() {
                    window.location = value;
                };

                try {
                    ContainerApi = require('jira/container-api');
                } catch (e) {
                    nativeNavigate();
                }

                ContainerApi && ContainerApi.navigate(value, nativeNavigate);

                return jQuery.Deferred();
            }
        };
    });
});
;
;
/* module-key = 'jira.webresources:global-static', location = '/includes/jira/wikipreview/wiki-renderer.js' */
AJS.$(function(){AJS.$(".code-bidi-warning").tooltip()});;
;
/* module-key = 'com.atlassian.auiplugin:ajs-raf', location = 'auiplugin/node_modules/@atlassian/aui/src/js-vendor/raf/raf.js' */
("undefined"===typeof window?global:window).__0e57a5ff611a3173e3f9aa2306aea259=function(){for(var a=window,f=0,d=["webkit","moz"],b=a.requestAnimationFrame,c=a.cancelAnimationFrame,e=d.length;0<=--e&&!b;)b=a[d[e]+"RequestAnimationFrame"],c=a[d[e]+"CancelAnimationFrame"];if(!b||!c)b=function(a){var b=Date.now(),c=Math.max(f+16,b);return setTimeout(function(){a(f=c)},c-b)},c=clearTimeout;a.requestAnimationFrame=b;a.cancelAnimationFrame=c;return{}}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-aui-internal-is-input', location = 'auiplugin/node_modules/@atlassian/aui/src/js/aui/internal/is-input.js' */
("undefined"===typeof window?global:window).__f268bb685e7e11f511cb91a156a783b0=function(){var a={};"use strict";Object.defineProperty(a,"__esModule",{value:!0});a.default=function(a){return"value"in a||a.isContentEditable};return a=a["default"]}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-vendor-raf-raf', location = 'auiplugin/node_modules/@atlassian/aui/src/js-vendor/raf/raf.js' */
("undefined"===typeof window?global:window).__0e57a5ff611a3173e3f9aa2306aea259=function(){for(var a=window,f=0,d=["webkit","moz"],b=a.requestAnimationFrame,c=a.cancelAnimationFrame,e=d.length;0<=--e&&!b;)b=a[d[e]+"RequestAnimationFrame"],c=a[d[e]+"CancelAnimationFrame"];if(!b||!c)b=function(a){var b=Date.now(),c=Math.max(f+16,b);return setTimeout(function(){a(f=c)},c-b)},c=clearTimeout;a.requestAnimationFrame=b;a.cancelAnimationFrame=c;return{}}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-aui-internal-has-touch', location = 'auiplugin/node_modules/@atlassian/aui/src/js/aui/internal/has-touch.js' */
("undefined"===typeof window?global:window).__29f0b74d9ef495751062ec4e83e0b098=function(){var a={};"use strict";Object.defineProperty(a,"__esModule",{value:!0});var b=window.DocumentTouch;a.default="ontouchstart"in window||b&&document instanceof b;return a=a["default"]}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-aui-internal-mediaQuery', location = 'auiplugin/node_modules/@atlassian/aui/src/js/aui/internal/mediaQuery.js' */
("undefined"===typeof window?global:window).__e67a99ea27950f14c1291fb7cebabf6d=function(){var a={};Object.defineProperty(a,"__esModule",{value:!0});a.default=function(a){if(window.matchMedia)return window.matchMedia(a).matches;var b=document.createElement("style");b.type="text/css";b.id="testMedia";b.innerText="@media "+a+" { #testMedia { width: 1px; } }";document.head.appendChild(b);a="1px"===window.getComputedStyle(b,null).width;b.parentNode.removeChild(b);return a};return a=a["default"]}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-aui-sidebar', location = 'auiplugin/node_modules/@atlassian/aui/src/js/aui/sidebar.js' */
("undefined"===typeof window?global:window).__c0275cfdb12ae34a5641a8e219403604=function(){function j(a){return a&&a.__esModule?a:{"default":a}}function c(a){this.$el=(0,e.default)(a);if(this.$el.length){this.$body=(0,e.default)("body");this.$wrapper=this.$el.children(".aui-sidebar-wrapper");this.$body.addClass("aui-page-sidebar");this._previousOffsetTop=this._previousViewportWidth=this._previousViewportHeight=this._previousScrollTop=null;this.submenus=new g;var b=this;if((0,e.default)(".aui-sidebar").length){b.$el.on("hover click focus",
b.collapsedTriggersSelector,function(a){a=(0,e.default)(a.target);r(b,a)});if(y.default&&(0,z.default)("only screen and (max-device-width:1024px)"))(0,e.default)("body").addClass("aui-page-sidebar-touch");var d=null,c=function(){null===d&&(d=requestAnimationFrame(function(){b.reflow();d=null}))};(0,e.default)(window).on("scroll resize",c);b.reflow();if(b.isAnimated())b.$el.on("transitionend webkitTransitionEnd",function(){b.$el.trigger(e.default.Event(l+(b.isCollapsed()?"collapse-end":"expand-end")))});
b.$el.on("click",".aui-sidebar-toggle",function(a){a.preventDefault();b.toggle()});(0,e.default)(".aui-page-panel").click(function(){!b.isCollapsed()&&b.isViewportNarrow()&&b.collapse()});var s=function(a){a.which===AJS.keyCode.LEFT_SQUARE_BRACKET&&(!a.shiftKey&&!a.ctrlKey&&!a.metaKey&&!(0,A.default)(a.target))&&b.toggle()};(0,e.default)(document).on("keypress",s);b._remove=function(){this._removeAllTooltips();(0,e.default)(this.inlineDialogSelector).remove();this.$el.off();this.$el.remove();(0,e.default)(document).off("keypress",
s);(0,e.default)(window).off("scroll resize",c)};b.$el.on("touchend",function(a){b.isCollapsed()&&(b.expand(),a.preventDefault())});b.$el.on("mouseenter focus",b.collapsedTriggersSelector,function(){if(b.isCollapsed()){var a=(0,e.default)(this);0!==m(a).length||t(a)}});b.$el.on("click blur mouseleave",b.collapsedTriggersSelector,function(){b.isCollapsed()&&u((0,e.default)(this))});b.$el.on("mouseenter focus",b.toggleSelector,function(){var a=(0,e.default)(this);b.isCollapsed()?a.data("tooltip","Expand sidebar ( [ )"):
a.data("tooltip","Collapse sidebar ( [ )");t(a)});b.$el.on("click blur mouseleave",b.toggleSelector,function(){u((0,e.default)(this))});b.$el.on("keydown",b.collapsedTriggersSelector,function(a){if(b.isCollapsed()){var d=a.target,c=v(d);if(c){var f=(0,e.default)(c);a.keyCode===AJS.keyCode.TAB&&(!a.shiftKey&&!a.altKey)&&c.open&&(a.preventDefault(),f.attr("persistent",""),f.find(":aui-tabbable").first().focus(),setTimeout(function(){f.removeAttr("persistent")},100),f.on("keydown",
function(a){if(a.keyCode===AJS.keyCode.TAB&&a.shiftKey&&a.target===f.find(":aui-tabbable")[0]||a.keyCode===AJS.keyCode.TAB&&(!a.shiftKey&&!a.altKey)&&a.target===f.find(":aui-tabbable").last()[0])d.focus(),(0,e.default)(this).off("keydown"),p()}))}}})}var f=this;(0,e.default)(f.collapsedTriggersSelector).each(function(){var a=(0,e.default)(this);r(f,a)})}}function w(a){return e.default.map(a.split(" "),function(a){return l+a}).join(" ")}function g(){this.inlineDialog=null}function m(a){return a.is("a")?
a.next(".aui-nav"):a.children(".aui-nav, hr")}function v(a){a=a.getAttribute("aria-controls");return document.getElementById(a)}function p(){var a=document.querySelectorAll(c.prototype.inlineDialogSelector);Array.prototype.forEach.call(a,function(a){a.open=!1})}function r(a,b){if(!b.data("_aui-sidebar-submenu-constructed")&&(b.data("_aui-sidebar-submenu-constructed",!0),0!==m(b).length)){var d=document.createElement("aui-inline-dialog"),g=(0,B.default)("sidebar-submenu");b.attr("aria-controls",g);
b.attr("data-aui-trigger","");x.default.init(b);d.setAttribute("id",g);d.setAttribute("alignment","right top");d.setAttribute("aria-hidden","true");a.isCollapsed()&&d.setAttribute("responds-to","hover");(0,e.default)(d).addClass(c.prototype.inlineDialogClass);document.body.appendChild(d);x.default.init(d);d.addEventListener("aui-layer-show",function(c){if(a.isCollapsed()){b.addClass("active");d.innerHTML=C;var f=b.is("a")?b.text():b.children(".aui-nav-heading").text(),c=(0,e.default)(d).find(".aui-navgroup-inner");
c.children(".aui-nav-heading").attr("title",f).children("strong").text(f);f=m(b);f=AJS.clone(f);f.hasClass("aui-expander-content")&&(f.find(".aui-expander-cutoff").remove(),f.removeClass("aui-expander-content"));f.appendTo(c)}else c.preventDefault()});d.addEventListener("aui-layer-hide",function(){b.removeClass("active")});return d}}function t(a){a.tipsy(D).tipsy("show");(a=a.data("tipsy")&&a.data("tipsy").$tip)&&a.css({opacity:""}).addClass("tooltip-shown")}function u(a){var b=a.data("tipsy")&&a.data("tipsy").$tip;
if(b){var d=b.css("transition-duration");d&&(d=0<=d.indexOf("ms")?parseInt(d.substring(0,d.length-2),10):1E3*parseInt(d.substring(0,d.length-1),10),setTimeout(function(){a.tipsy("hide")},d));b.removeClass("tooltip-shown")}}var o={};"use strict";Object.defineProperty(o,"__esModule",{value:!0});var e=j(__307d3e18fd611f85395c67cddeb1fe24);__f673a5150978887490995d88aeec0c8d;__0e57a5ff611a3173e3f9aa2306aea259;__d74c881c8f23921c15438d0f30c99f80;var k;var h=__c8cfa00f1eba9ac7af89ee3d0d33961d;if(h&&h.__esModule)k=
h;else{var n={};if(null!=h)for(k in h)Object.prototype.hasOwnProperty.call(h,k)&&(n[k]=h[k]);n.default=h;k=n}var h=j(__4d02fe17b8e885a34493e34af3d145dd),y=j(__29f0b74d9ef495751062ec4e83e0b098),A=j(__f268bb685e7e11f511cb91a156a783b0),z=j(__e67a99ea27950f14c1291fb7cebabf6d),x=j(__c1ce1f1e3e613f564fc234ff043570f1),B=j(__9fa5e8acd81f0f9028180b8fcdcd9cb4),n=j(__e3152236c406a356c24f20f7bfcccf21),E="undefined"!==typeof document.documentElement.style.transition||"undefined"!==typeof document.documentElement.style.webkitTransition,
l="_aui-internal-sidebar-";c.prototype.on=function(){var a=arguments[0],b=Array.prototype.slice.call(arguments,1),a=w(a);this.$el.on.apply(this.$el,[a].concat(b));return this};c.prototype.off=function(){var a=arguments[0],b=Array.prototype.slice.call(arguments,1),a=w(a);this.$el.off.apply(this.$el,[a].concat(b));return this};c.prototype.setHeight=function(a,b,d){a=Math.max(0,d-a);this.$wrapper.height(b-a);return this};c.prototype.setPosition=function(a){a=a||window.pageYOffset;this.$wrapper.toggleClass("aui-is-docked",
a>this.$el.offset().top);return this};c.prototype.setCollapsedState=function(a){var b={collapsed:{},expanded:{}};b.collapsed.narrow={narrow:e.default.noop,wide:function(b){b._expand(a,!0)}};b.collapsed.wide={narrow:e.default.noop,wide:e.default.noop};b.expanded.narrow={narrow:e.default.noop,wide:function(a){a.$body.removeClass("aui-sidebar-collapsed");a.$el.removeClass("aui-sidebar-fly-out")}};b.expanded.wide={narrow:function(a){a._collapse(!0)},wide:e.default.noop};var d=this.isCollapsed()?"collapsed":
"expanded",c=this.isViewportNarrow(this._previousViewportWidth)?"narrow":"wide",g=this.isViewportNarrow(a)?"narrow":"wide";b[d][c][g](this);return this};c.prototype._collapse=function(a){if(this.isCollapsed())return this;var b=e.default.Event(l+"collapse-start",{isResponsive:a});this.$el.trigger(b);if(b.isDefaultPrevented())return this;this.$body.addClass("aui-sidebar-collapsed");this.$el.attr("aria-expanded","false");this.$el.removeClass("aui-sidebar-fly-out");this.$el.find(this.submenuTriggersSelector).attr("tabindex",
0);(0,e.default)(this.inlineDialogSelector).attr("responds-to","hover");this.isAnimated()||this.$el.trigger(e.default.Event(l+"collapse-end",{isResponsive:a}));return this};c.prototype.collapse=function(){return this._collapse(!1)};c.prototype._expand=function(a,b){var d=e.default.Event(l+"expand-start",{isResponsive:b});this.$el.trigger(d);if(d.isDefaultPrevented())return this;d=this.isViewportNarrow(a);this.$el.attr("aria-expanded","true");this.$body.toggleClass("aui-sidebar-collapsed",d);this.$el.toggleClass("aui-sidebar-fly-out",
d);this.$el.find(this.submenuTriggersSelector).removeAttr("tabindex");(0,e.default)(this.inlineDialogSelector).removeAttr("responds-to");this.isAnimated()||this.$el.trigger(e.default.Event(l+"expand-end",{isResponsive:b}));return this};c.prototype.expand=function(){this.isCollapsed()&&this._expand(this._previousViewportWidth,!1);return this};c.prototype.isAnimated=function(){return E&&this.$el.hasClass("aui-is-animated")};c.prototype.isCollapsed=function(){return"false"===this.$el.attr("aria-expanded")};
c.prototype.isViewportNarrow=function(a){a=void 0===a?this._previousViewportWidth:a;return 1240>a};c.prototype._removeAllTooltips=function(){(0,e.default)(this.tooltipSelector).remove()};c.prototype.responsiveReflow=function(a,b){if(a){if(!this.isCollapsed()&&this.isViewportNarrow(b)){var d=this.isAnimated();d&&this.$el.removeClass("aui-is-animated");this.collapse();d&&(this.$el[0].offsetHeight,this.$el.addClass("aui-is-animated"))}}else b!==this._previousViewportWidth&&this.setCollapsedState(b)};
c.prototype.reflow=function(a,b,d,c){var a=void 0===a?window.pageYOffset:a,b=void 0===b?document.documentElement.clientHeight:b,c=void 0===c?document.documentElement.scrollHeight:c,d=void 0===d?window.innerWidth:d,e=this.$el.offset().top,f=null===this._previousViewportWidth;if(!(a===this._previousScrollTop&&b===this._previousViewportHeight&&e===this._previousOffsetTop)){this.isCollapsed()&&(!f&&a!==this._previousScrollTop)&&(p(),this._removeAllTooltips());var g=this.$body.hasClass("aui-page-sidebar-touch"),
c=a!==this._previousScrollTop&&(0>a||a+b>c);if(!g&&(f||!c))this.setHeight(a,b,e),this.setPosition(a)}"false"!==this.$el.attr("data-aui-responsive")?this.responsiveReflow(f,d):(f=!this.isCollapsed()&&this.isViewportNarrow(d),this.$el.toggleClass("aui-sidebar-fly-out",f));this._previousScrollTop=a;this._previousViewportHeight=b;this._previousViewportWidth=d;this._previousOffsetTop=e;return this};c.prototype.toggle=function(){this.isCollapsed()?(this.expand(),this._removeAllTooltips()):this.collapse();
return this};c.prototype.submenuTriggersSelector=".aui-sidebar-group:not(.aui-sidebar-group-tier-one)";c.prototype.collapsedTriggersSelector=[c.prototype.submenuTriggersSelector,".aui-sidebar-group.aui-sidebar-group-tier-one > .aui-nav > li > a",".aui-sidebar-footer > .aui-sidebar-settings-button"].join(", ");c.prototype.toggleSelector=".aui-sidebar-footer > .aui-sidebar-toggle";c.prototype.tooltipSelector=".aui-sidebar-section-tooltip";c.prototype.inlineDialogClass="aui-sidebar-submenu-dialog";c.prototype.inlineDialogSelector=
"."+c.prototype.inlineDialogClass;g.prototype.submenu=function(a){i();return m(a)};g.prototype.hasSubmenu=function(a){i();return 0!==m(a).length};g.prototype.submenuHeadingHeight=function(){i();return 34};g.prototype.isShowing=function(){i();return c.prototype.isSubmenuVisible()};g.prototype.show=function(a,b){i();v(b).open=!0};g.prototype.hide=function(){i();p()};g.prototype.inlineDialogShowHandler=function(){i()};g.prototype.inlineDialogHideHandler=function(){i()};g.prototype.moveSubmenuToInlineDialog=
function(){i()};g.prototype.restoreSubmenu=function(){i()};c.prototype.getVisibleSubmenus=function(){return Array.prototype.filter.call(document.querySelectorAll(c.prototype.inlineDialogSelector),function(a){return a.open})};c.prototype.isSubmenuVisible=function(){return 0<this.getVisibleSubmenus().length};var C='<div class="aui-inline-dialog-contents"><div class="aui-sidebar-submenu" ><div class="aui-navgroup aui-navgroup-vertical"><div class="aui-navgroup-inner"><div class="aui-nav-heading"><strong></strong></div></div></div></div></div>',
D={trigger:"manual",gravity:"w",className:"aui-sidebar-section-tooltip",title:function(){var a=(0,e.default)(this);return a.is("a")?a.attr("title")||a.find(".aui-nav-item-label").text()||a.data("tooltip"):a.children(".aui-nav").attr("title")||a.children(".aui-nav-heading").text()}},q=(0,n.default)("sidebar",c);(0,e.default)(function(){q(".aui-sidebar")});var i=k.getMessageLogger("Sidebar.submenus",{removeInVersion:"6.0",sinceVersion:"5.8"});(0,h.default)("sidebar",q);o.default=q;return o=o["default"]}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:internal-@atlassian-aui-src-js-aui-dialog2', location = 'auiplugin/node_modules/@atlassian/aui/src/js/aui/dialog2.js' */
("undefined"===typeof window?global:window).__bdbf9d213bf319eb4577ef21ac6c491c=function(){function f(a){return a&&a.__esModule?a:{"default":a}}function e(a){var c=this.$el=a?(0,g.default)(a):(0,g.default)(aui.dialog.dialog2({}));g.default.each(i,function(a,b){var d="data-"+a;c[0].hasAttribute(d)||c.attr(d,b)})}var h={};"use strict";Object.defineProperty(h,"__esModule",{value:!0});var g=f(__307d3e18fd611f85395c67cddeb1fe24),j=f(__574ac67f906effeb9d8ec2753b23cf28),k=f(__4d02fe17b8e885a34493e34af3d145dd),
b=f(__fe0cd0a7ef176e2ef4e0e105d1ce31f5),l=f(__e3152236c406a356c24f20f7bfcccf21),i={"aui-focus":"false","aui-blanketed":"true"};e.prototype.on=function(a,c){(0,b.default)(this.$el).on(a,c);return this};e.prototype.off=function(a,c){(0,b.default)(this.$el).off(a,c);return this};e.prototype.show=function(){(0,b.default)(this.$el).show();return this};e.prototype.hide=function(){(0,b.default)(this.$el).hide();return this};e.prototype.remove=function(){(0,b.default)(this.$el).remove();return this};e.prototype.isVisible=
function(){return(0,b.default)(this.$el).isVisible()};var d=(0,l.default)("dialog2",e);d.on=function(a,c){b.default.on(a,".aui-dialog2",c);return this};d.off=function(a,c){b.default.off(a,".aui-dialog2",c);return this};(0,g.default)(document).on("click",".aui-dialog2-header-close",function(a){a.preventDefault();d((0,g.default)(this).closest(".aui-dialog2")).hide()});d.on("show",function(a,c){var b;[".aui-dialog2-content",".aui-dialog2-footer",".aui-dialog2-header"].some(function(a){b=c.find(a+" :aui-tabbable");
return b.length});b&&b.first().focus()});d.on("hide",function(a,c){var d=(0,b.default)(c);c.data("aui-remove-on-hide")&&d.remove()});(0,j.default)("aui/dialog2",d);(0,k.default)("dialog2",d);h.default=d;return h=h["default"]}.call(this);;
;
/* module-key = 'com.atlassian.auiplugin:dialog2', location = 'auiplugin/src/soy/dialog2.soy' */
// This file was automatically generated from dialog2.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace aui.dialog.
 */

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.dialog == 'undefined') { aui.dialog = {}; }


aui.dialog.dialog2 = function(opt_data, opt_ignored) {
  return '' + aui.dialog.dialog2Chrome({id: opt_data.id, titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, modal: opt_data.modal, tagName: opt_data.tagName, removeOnHide: opt_data.removeOnHide, visible: opt_data.visible, size: opt_data.size, extraClasses: opt_data.extraClasses, extraAttributes: opt_data.extraAttributes, content: '' + aui.dialog.dialog2Content({id: null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, headerActionContent: opt_data.headerActionContent, headerSecondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal, content: opt_data.content, footerHintText: opt_data.footerHintText, footerHintContent: opt_data.footerHintContent, footerActionContent: opt_data.footerActionContent})});
};
if (goog.DEBUG) {
  aui.dialog.dialog2.soyTemplateName = 'aui.dialog.dialog2';
}


aui.dialog.dialog2Chrome = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section') + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ((opt_data.titleId) ? ' aria-labelledby="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '') + ' role="dialog" class=" aui-layer aui-dialog2 aui-dialog2-' + soy.$$escapeHtml(opt_data.size ? opt_data.size : 'medium') + aui.renderExtraClasses(opt_data) + '"' + ((opt_data.modal) ? 'data-aui-modal="true"' : '') + ((opt_data.removeOnHide) ? 'data-aui-remove-on-hide="true"' : '') + ((opt_data.visible != true) ? 'aria-hidden="true"' : '') + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + '</' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section') + '>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Chrome.soyTemplateName = 'aui.dialog.dialog2Chrome';
}


aui.dialog.dialog2Content = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '' + aui.dialog.dialog2Header({titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, actionContent: opt_data.headerActionContent, secondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal}) + aui.dialog.dialog2Panel(opt_data) + aui.dialog.dialog2Footer({hintText: opt_data.footerHintText, hintContent: opt_data.footerHintContent, actionContent: opt_data.footerActionContent});
};
if (goog.DEBUG) {
  aui.dialog.dialog2Content.soyTemplateName = 'aui.dialog.dialog2Content';
}


aui.dialog.dialog2Header = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<header' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-header' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '><h2 ' + ((opt_data.titleId) ? ' id="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '') + ' class="aui-dialog2-header-main">' + ((opt_data.titleText) ? soy.$$escapeHtml(opt_data.titleText) : '') + ((opt_data.titleContent) ? soy.$$filterNoAutoescape(opt_data.titleContent) : '') + '</h2>' + ((opt_data.actionContent) ? '<div class="aui-dialog2-header-actions">' + soy.$$filterNoAutoescape(opt_data.actionContent) + '</div>' : '') + ((opt_data.secondaryContent) ? '<div class="aui-dialog2-header-secondary">' + soy.$$filterNoAutoescape(opt_data.secondaryContent) + '</div>' : '') + ((opt_data.modal != true) ? '<a class="aui-dialog2-header-close"><span class="aui-icon aui-icon-small aui-iconfont-close-dialog">' + soy.$$escapeHtml('Close') + '</span></a>' : '') + '</header>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Header.soyTemplateName = 'aui.dialog.dialog2Header';
}


aui.dialog.dialog2Footer = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<footer' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-footer' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.actionContent) ? '<div class="aui-dialog2-footer-actions">' + soy.$$filterNoAutoescape(opt_data.actionContent) + '</div>' : '') + ((opt_data.hintText || opt_data.hintContent) ? '<div class="aui-dialog2-footer-hint">' + ((opt_data.hintText) ? soy.$$escapeHtml(opt_data.hintText) : '') + ((opt_data.hintContent) ? soy.$$filterNoAutoescape(opt_data.hintContent) : '') + '</div>' : '') + '</footer>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Footer.soyTemplateName = 'aui.dialog.dialog2Footer';
}


aui.dialog.dialog2Panel = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<div' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-content' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + '</div>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Panel.soyTemplateName = 'aui.dialog.dialog2Panel';
}
;
;
/* module-key = 'com.atlassian.plugin.jslibs:marionette-2.1.0-factory-legacy', location = 'atlassian-jslibs/factories/marionette/2.1.0/marionette-2.1.0-factory.js' */
!function(t){define("atlassian/libs/factories/marionette-2.1.0",function(){return function(e,i){var n={_:e,Backbone:i};return t.call(n),n.Marionette.noConflict()}})}(function(){/*!
   * Includes BabySitter
   * https://github.com/marionettejs/backbone.babysitter/
   *
   * Includes Wreqr
   * https://github.com/marionettejs/backbone.wreqr/
   */
!function(t,e){t.Marionette=e(t,t.Backbone,t._)}(this,function(t,e,i){"use strict";function n(t,e){var i=new Error(t);throw i.name=e||"Error",i}!function(t,e){var i=t.ChildViewContainer;return t.ChildViewContainer=function(t,e){var i=function(t){this._views={},this._indexByModel={},this._indexByCustom={},this._updateLength(),e.each(t,this.add,this)};e.extend(i.prototype,{add:function(t,e){var i=t.cid;return this._views[i]=t,t.model&&(this._indexByModel[t.model.cid]=i),e&&(this._indexByCustom[e]=i),this._updateLength(),this},findByModel:function(t){return this.findByModelCid(t.cid)},findByModelCid:function(t){var e=this._indexByModel[t];return this.findByCid(e)},findByCustom:function(t){var e=this._indexByCustom[t];return this.findByCid(e)},findByIndex:function(t){return e.values(this._views)[t]},findByCid:function(t){return this._views[t]},remove:function(t){var i=t.cid;return t.model&&delete this._indexByModel[t.model.cid],e.any(this._indexByCustom,function(t,e){if(t===i)return delete this._indexByCustom[e],!0},this),delete this._views[i],this._updateLength(),this},call:function(t){this.apply(t,e.tail(arguments))},apply:function(t,i){e.each(this._views,function(n){e.isFunction(n[t])&&n[t].apply(n,i||[])})},_updateLength:function(){this.length=e.size(this._views)}});var n=["forEach","each","map","find","detect","filter","select","reject","every","all","some","any","include","contains","invoke","toArray","first","initial","rest","last","without","isEmpty","pluck"];return e.each(n,function(t){i.prototype[t]=function(){var i=e.values(this._views),n=[i].concat(e.toArray(arguments));return e[t].apply(e,n)}}),i}(t,e),t.ChildViewContainer.VERSION="0.1.4",t.ChildViewContainer.noConflict=function(){return t.ChildViewContainer=i,this},t.ChildViewContainer}(e,i),function(t,e){var i=t.Wreqr,n=t.Wreqr={};return t.Wreqr.VERSION="1.3.1",t.Wreqr.noConflict=function(){return t.Wreqr=i,this},n.Handlers=function(t,e){var i=function(t){this.options=t,this._wreqrHandlers={},e.isFunction(this.initialize)&&this.initialize(t)};return i.extend=t.Model.extend,e.extend(i.prototype,t.Events,{setHandlers:function(t){e.each(t,function(t,i){var n=null;e.isObject(t)&&!e.isFunction(t)&&(n=t.context,t=t.callback),this.setHandler(i,t,n)},this)},setHandler:function(t,e,i){var n={callback:e,context:i};this._wreqrHandlers[t]=n,this.trigger("handler:add",t,e,i)},hasHandler:function(t){return!!this._wreqrHandlers[t]},getHandler:function(t){var e=this._wreqrHandlers[t];if(e)return function(){var t=Array.prototype.slice.apply(arguments);return e.callback.apply(e.context,t)}},removeHandler:function(t){delete this._wreqrHandlers[t]},removeAllHandlers:function(){this._wreqrHandlers={}}}),i}(t,e),n.CommandStorage=function(){var i=function(t){this.options=t,this._commands={},e.isFunction(this.initialize)&&this.initialize(t)};return e.extend(i.prototype,t.Events,{getCommands:function(t){var e=this._commands[t];return e||(e={command:t,instances:[]},this._commands[t]=e),e},addCommand:function(t,e){var i=this.getCommands(t);i.instances.push(e)},clearCommands:function(t){var e=this.getCommands(t);e.instances=[]}}),i}(),n.Commands=function(t){return t.Handlers.extend({storageType:t.CommandStorage,constructor:function(e){this.options=e||{},this._initializeStorage(this.options),this.on("handler:add",this._executeCommands,this);var i=Array.prototype.slice.call(arguments);t.Handlers.prototype.constructor.apply(this,i)},execute:function(t,e){t=arguments[0],e=Array.prototype.slice.call(arguments,1),this.hasHandler(t)?this.getHandler(t).apply(this,e):this.storage.addCommand(t,e)},_executeCommands:function(t,i,n){var r=this.storage.getCommands(t);e.each(r.instances,function(t){i.apply(n,t)}),this.storage.clearCommands(t)},_initializeStorage:function(t){var i,n=t.storageType||this.storageType;i=e.isFunction(n)?new n:n,this.storage=i}})}(n),n.RequestResponse=function(t){return t.Handlers.extend({request:function(){var t=arguments[0],e=Array.prototype.slice.call(arguments,1);if(this.hasHandler(t))return this.getHandler(t).apply(this,e)}})}(n),n.EventAggregator=function(t,e){var i=function(){};return i.extend=t.Model.extend,e.extend(i.prototype,t.Events),i}(t,e),n.Channel=function(t){var i=function(e){this.vent=new t.EventAggregator,this.reqres=new t.RequestResponse,this.commands=new t.Commands,this.channelName=e};return e.extend(i.prototype,{reset:function(){return this.vent.off(),this.vent.stopListening(),this.reqres.removeAllHandlers(),this.commands.removeAllHandlers(),this},connectEvents:function(t,e){return this._connect("vent",t,e),this},connectCommands:function(t,e){return this._connect("commands",t,e),this},connectRequests:function(t,e){return this._connect("reqres",t,e),this},_connect:function(t,i,n){if(i){n=n||this;var r="vent"===t?"on":"setHandler";e.each(i,function(i,o){this[t][r](o,e.bind(i,n))},this)}}}),i}(n),n.radio=function(t){var i=function(){this._channels={},this.vent={},this.commands={},this.reqres={},this._proxyMethods()};e.extend(i.prototype,{channel:function(t){if(!t)throw new Error("Channel must receive a name");return this._getChannel(t)},_getChannel:function(e){var i=this._channels[e];return i||(i=new t.Channel(e),this._channels[e]=i),i},_proxyMethods:function(){e.each(["vent","commands","reqres"],function(t){e.each(n[t],function(e){this[t][e]=r(this,t,e)},this)},this)}});var n={vent:["on","off","trigger","once","stopListening","listenTo","listenToOnce"],commands:["execute","setHandler","setHandlers","removeHandler","removeAllHandlers"],reqres:["request","setHandler","setHandlers","removeHandler","removeAllHandlers"]},r=function(t,e,i){return function(n){var r=t._getChannel(n)[e],o=Array.prototype.slice.call(arguments,1);return r[i].apply(r,o)}};return new i}(n),t.Wreqr}(e,i);var r=e.ChildViewContainer.noConflict(),o=e.Wreqr.noConflict(),s=t.Marionette,h=e.Marionette={};h.VERSION="2.1.0",h.noConflict=function(){return t.Marionette=s,this},e.Marionette=h,h.Deferred=e.$.Deferred;var a=Array.prototype.slice;return h.extend=e.Model.extend,h.getOption=function(t,e){if(t&&e){var i;return i=t.options&&void 0!==t.options[e]?t.options[e]:t[e]}},h.proxyGetOption=function(t){return h.getOption(this,t)},h.normalizeMethods=function(t){var e={};return i.each(t,function(t,n){i.isFunction(t)||(t=this[t]),t&&(e[n]=t)},this),e},h.normalizeUIKeys=function(t,e){if("undefined"!=typeof t)return i.each(i.keys(t),function(i){var n=/@ui\.[a-zA-Z_$0-9]*/g;i.match(n)&&(t[i.replace(n,function(t){return e[t.slice(4)]})]=t[i],delete t[i])}),t},h.actAsCollection=function(t,e){var n=["forEach","each","map","find","detect","filter","select","reject","every","all","some","any","include","contains","invoke","toArray","first","initial","rest","last","without","isEmpty","pluck"];i.each(n,function(n){t[n]=function(){var t=i.values(i.result(this,e)),r=[t].concat(i.toArray(arguments));return i[n].apply(i,r)}})},h.triggerMethod=function(){function t(t,e,i){return i.toUpperCase()}var e=/(^|:)(\w)/gi,n=function(n){var r,o="on"+n.replace(e,t),s=this[o];return i.isFunction(s)&&(r=s.apply(this,i.tail(arguments))),i.isFunction(this.trigger)&&this.trigger.apply(this,arguments),r};return n}(),h.MonitorDOMRefresh=function(t){function n(t){t._isShown=!0,o(t)}function r(t){t._isRendered=!0,o(t)}function o(t){t._isShown&&t._isRendered&&s(t)&&i.isFunction(t.triggerMethod)&&t.triggerMethod("dom:refresh")}function s(i){return e.$.contains(t,i.el)}return function(t){t.listenTo(t,"show",function(){n(t)}),t.listenTo(t,"render",function(){r(t)})}}(document.documentElement),function(t){function e(t,e,r,o){var s=o.split(/\s+/);i.each(s,function(i){var o=t[i];o||n('Method "'+i+'" was configured as an event handler, but does not exist.'),t.listenTo(e,r,o)})}function r(t,e,i,n){t.listenTo(e,i,n)}function o(t,e,n,r){var o=r.split(/\s+/);i.each(o,function(i){var r=t[i];t.stopListening(e,n,r)})}function s(t,e,i,n){t.stopListening(e,i,n)}function h(t,e,n,r,o){e&&n&&(i.isFunction(n)&&(n=n.call(t)),i.each(n,function(n,s){i.isFunction(n)?r(t,e,s,n):o(t,e,s,n)}))}t.bindEntityEvents=function(t,i,n){h(t,i,n,r,e)},t.unbindEntityEvents=function(t,e,i){h(t,e,i,s,o)},t.proxyBindEntityEvents=function(e,i){return t.bindEntityEvents(this,e,i)},t.proxyUnbindEntityEvents=function(e,i){return t.unbindEntityEvents(this,e,i)}}(h),h.Callbacks=function(){this._deferred=h.Deferred(),this._callbacks=[]},i.extend(h.Callbacks.prototype,{add:function(t,e){var n=i.result(this._deferred,"promise");this._callbacks.push({cb:t,ctx:e}),n.then(function(i){e&&(i.context=e),t.call(i.context,i.options)})},run:function(t,e){this._deferred.resolve({options:t,context:e})},reset:function(){var t=this._callbacks;this._deferred=h.Deferred(),this._callbacks=[],i.each(t,function(t){this.add(t.cb,t.ctx)},this)}}),h.Controller=function(t){this.options=t||{},i.isFunction(this.initialize)&&this.initialize(this.options)},h.Controller.extend=h.extend,i.extend(h.Controller.prototype,e.Events,{destroy:function(){var t=a.call(arguments);return this.triggerMethod.apply(this,["before:destroy"].concat(t)),this.triggerMethod.apply(this,["destroy"].concat(t)),this.stopListening(),this.off(),this},triggerMethod:h.triggerMethod,getOption:h.proxyGetOption}),h.Object=function(t){this.options=i.extend({},i.result(this,"options"),t),this.initialize(this.options)},h.Object.extend=h.extend,i.extend(h.Object.prototype,{initialize:function(){},destroy:function(){this.triggerMethod("before:destroy"),this.triggerMethod("destroy"),this.stopListening()},triggerMethod:h.triggerMethod,getOption:h.proxyGetOption,bindEntityEvents:h.proxyBindEntityEvents,unbindEntityEvents:h.proxyUnbindEntityEvents}),i.extend(h.Object.prototype,e.Events),h.Region=function(t){if(this.options=t||{},this.el=this.getOption("el"),this.el=this.el instanceof e.$?this.el[0]:this.el,this.el||n('An "el" must be specified for a region.',"NoElError"),this.$el=this.getEl(this.el),this.initialize){var i=a.apply(arguments);this.initialize.apply(this,i)}},i.extend(h.Region,{buildRegion:function(t,e){return i.isString(t)?this._buildRegionFromSelector(t,e):t.selector||t.el||t.regionClass?this._buildRegionFromObject(t,e):i.isFunction(t)?this._buildRegionFromRegionClass(t):void n("Improper region configuration type. Please refer to http://marionettejs.com/docs/marionette.region.html#region-configuration-types")},_buildRegionFromSelector:function(t,e){return new e({el:t})},_buildRegionFromObject:function(t,n){var r=t.regionClass||n,o=i.omit(t,"selector","regionClass");t.selector&&!o.el&&(o.el=t.selector);var s=new r(o);return t.parentEl&&(s.getEl=function(n){if(i.isObject(n))return e.$(n);var r=t.parentEl;return i.isFunction(r)&&(r=r()),r.find(n)}),s},_buildRegionFromRegionClass:function(t){return new t}}),i.extend(h.Region.prototype,e.Events,{show:function(t,e){this._ensureElement();var n=e||{},r=t!==this.currentView,o=!!n.preventDestroy,s=!!n.forceShow,h=!!this.currentView,a=!o&&r;a&&this.empty();var l=r||s;return l?(t.once("destroy",i.bind(this.empty,this)),t.render(),h&&this.triggerMethod("before:swap",t),this.triggerMethod("before:show",t),i.isFunction(t.triggerMethod)?t.triggerMethod("before:show"):this.triggerMethod.call(t,"before:show"),this.attachHtml(t),this.currentView=t,h&&this.triggerMethod("swap",t),this.triggerMethod("show",t),i.isFunction(t.triggerMethod)?t.triggerMethod("show"):this.triggerMethod.call(t,"show"),this):this},_ensureElement:function(){i.isObject(this.el)||(this.$el=this.getEl(this.el),this.el=this.$el[0]),this.$el&&0!==this.$el.length||n('An "el" '+this.$el.selector+" must exist in DOM")},getEl:function(t){return e.$(t)},attachHtml:function(t){this.el.innerHTML="",this.el.appendChild(t.el)},empty:function(){var t=this.currentView;if(t)return this.triggerMethod("before:empty",t),this._destroyView(),this.triggerMethod("empty",t),delete this.currentView,this},_destroyView:function(){var t=this.currentView;t.destroy&&!t.isDestroyed?t.destroy():t.remove&&t.remove()},attachView:function(t){return this.currentView=t,this},hasView:function(){return!!this.currentView},reset:function(){return this.empty(),this.$el&&(this.el=this.$el.selector),delete this.$el,this},getOption:h.proxyGetOption,triggerMethod:h.triggerMethod}),h.Region.extend=h.extend,h.RegionManager=function(t){var e=t.Controller.extend({constructor:function(e){this._regions={},t.Controller.call(this,e)},addRegions:function(t,e){i.isFunction(t)&&(t=t.apply(this,arguments));var n={};return i.each(t,function(t,r){i.isString(t)&&(t={selector:t}),t.selector&&(t=i.defaults({},t,e));var o=this.addRegion(r,t);n[r]=o},this),n},addRegion:function(e,n){var r,o=i.isObject(n),s=i.isString(n),h=!!n.selector;return r=s||o&&h?t.Region.buildRegion(n,t.Region):i.isFunction(n)?t.Region.buildRegion(n,t.Region):n,this.triggerMethod("before:add:region",e,r),this._store(e,r),this.triggerMethod("add:region",e,r),r},get:function(t){return this._regions[t]},getRegions:function(){return i.clone(this._regions)},removeRegion:function(t){var e=this._regions[t];return this._remove(t,e),e},removeRegions:function(){var t=this.getRegions();return i.each(this._regions,function(t,e){this._remove(e,t)},this),t},emptyRegions:function(){var t=this.getRegions();return i.each(t,function(t){t.empty()},this),t},destroy:function(){return this.removeRegions(),t.Controller.prototype.destroy.apply(this,arguments)},_store:function(t,e){this._regions[t]=e,this._setLength()},_remove:function(t,e){this.triggerMethod("before:remove:region",t,e),e.empty(),e.stopListening(),delete this._regions[t],this._setLength(),this.triggerMethod("remove:region",t,e)},_setLength:function(){this.length=i.size(this._regions)}});return t.actAsCollection(e.prototype,"_regions"),e}(h),h.TemplateCache=function(t){this.templateId=t},i.extend(h.TemplateCache,{templateCaches:{},get:function(t){var e=this.templateCaches[t];return e||(e=new h.TemplateCache(t),this.templateCaches[t]=e),e.load()},clear:function(){var t,e=a.call(arguments),i=e.length;if(i>0)for(t=0;t<i;t++)delete this.templateCaches[e[t]];else this.templateCaches={}}}),i.extend(h.TemplateCache.prototype,{load:function(){if(this.compiledTemplate)return this.compiledTemplate;var t=this.loadTemplate(this.templateId);return this.compiledTemplate=this.compileTemplate(t),this.compiledTemplate},loadTemplate:function(t){var i=e.$(t).html();return i&&0!==i.length||n('Could not find template: "'+t+'"',"NoTemplateError"),i},compileTemplate:function(t){return i.template(t)}}),h.Renderer={render:function(t,e){t||n("Cannot render the template since its false, null or undefined.","TemplateNotFoundError");var i;return(i="function"==typeof t?t:h.TemplateCache.get(t))(e)}},h.View=e.View.extend({constructor:function(t){i.bindAll(this,"render"),this.options=i.extend({},i.result(this,"options"),i.isFunction(t)?t.call(this):t),this.events=this.normalizeUIKeys(i.result(this,"events")),i.isObject(this.behaviors)&&new h.Behaviors(this),e.View.apply(this,arguments),h.MonitorDOMRefresh(this),this.listenTo(this,"show",this.onShowCalled)},getTemplate:function(){return this.getOption("template")},serializeModel:function(t){return t.toJSON.apply(t,a.call(arguments,1))},mixinTemplateHelpers:function(t){t=t||{};var e=this.getOption("templateHelpers");return i.isFunction(e)&&(e=e.call(this)),i.extend(t,e)},normalizeUIKeys:function(t){var e=i.result(this,"ui"),n=i.result(this,"_uiBindings");return h.normalizeUIKeys(t,n||e)},configureTriggers:function(){if(this.triggers){var t={},e=this.normalizeUIKeys(i.result(this,"triggers"));return i.each(e,function(e,n){var r=i.isObject(e),o=r?e.event:e;t[n]=function(t){if(t){var i=t.preventDefault,n=t.stopPropagation,s=r?e.preventDefault:i,h=r?e.stopPropagation:n;s&&i&&i.apply(t),h&&n&&n.apply(t)}var a={view:this,model:this.model,collection:this.collection};this.triggerMethod(o,a)}},this),t}},delegateEvents:function(t){return this._delegateDOMEvents(t),this.bindEntityEvents(this.model,this.getOption("modelEvents")),this.bindEntityEvents(this.collection,this.getOption("collectionEvents")),this},_delegateDOMEvents:function(t){t=t||this.events,i.isFunction(t)&&(t=t.call(this)),t=this.normalizeUIKeys(t);var n={},r=i.result(this,"behaviorEvents")||{},o=this.configureTriggers();i.extend(n,r,t,o),e.View.prototype.delegateEvents.call(this,n)},undelegateEvents:function(){var t=a.call(arguments);return e.View.prototype.undelegateEvents.apply(this,t),this.unbindEntityEvents(this.model,this.getOption("modelEvents")),this.unbindEntityEvents(this.collection,this.getOption("collectionEvents")),this},onShowCalled:function(){},_ensureViewIsIntact:function(){if(this.isDestroyed){var t=new Error("Cannot use a view thats already been destroyed.");throw t.name="ViewDestroyedError",t}},destroy:function(){if(!this.isDestroyed){var t=a.call(arguments);return this.triggerMethod.apply(this,["before:destroy"].concat(t)),this.isDestroyed=!0,this.triggerMethod.apply(this,["destroy"].concat(t)),this.unbindUIElements(),this.remove(),this}},bindUIElements:function(){if(this.ui){this._uiBindings||(this._uiBindings=this.ui);var t=i.result(this,"_uiBindings");this.ui={},i.each(i.keys(t),function(e){var i=t[e];this.ui[e]=this.$(i)},this)}},unbindUIElements:function(){this.ui&&this._uiBindings&&(i.each(this.ui,function(t,e){delete this.ui[e]},this),this.ui=this._uiBindings,delete this._uiBindings)},triggerMethod:h.triggerMethod,normalizeMethods:h.normalizeMethods,getOption:h.proxyGetOption,bindEntityEvents:h.proxyBindEntityEvents,unbindEntityEvents:h.proxyUnbindEntityEvents}),h.ItemView=h.View.extend({constructor:function(){h.View.apply(this,arguments)},serializeData:function(){var t={};return this.model?t=i.partial(this.serializeModel,this.model).apply(this,arguments):this.collection&&(t={items:i.partial(this.serializeCollection,this.collection).apply(this,arguments)}),t},serializeCollection:function(t){return t.toJSON.apply(t,a.call(arguments,1))},render:function(){return this._ensureViewIsIntact(),this.triggerMethod("before:render",this),this._renderTemplate(),this.bindUIElements(),this.triggerMethod("render",this),this},_renderTemplate:function(){var t=this.getTemplate();if(t!==!1){t||n("Cannot render the template since it is null or undefined.","UndefinedTemplateError");var e=this.serializeData();e=this.mixinTemplateHelpers(e);var i=h.Renderer.render(t,e,this);return this.attachElContent(i),this}},attachElContent:function(t){return this.$el.html(t),this},destroy:function(){if(!this.isDestroyed)return h.View.prototype.destroy.apply(this,arguments)}}),h.CollectionView=h.View.extend({childViewEventPrefix:"childview",constructor:function(t){var e=t||{};this.sort=!!i.isUndefined(e.sort)||e.sort,this._initChildViewStorage(),h.View.apply(this,arguments),this._initialEvents(),this.initRenderBuffer()},initRenderBuffer:function(){this.elBuffer=document.createDocumentFragment(),this._bufferedChildren=[]},startBuffering:function(){this.initRenderBuffer(),this.isBuffering=!0},endBuffering:function(){this.isBuffering=!1,this._triggerBeforeShowBufferedChildren(),this.attachBuffer(this,this.elBuffer),this._triggerShowBufferedChildren(),this.initRenderBuffer()},_triggerBeforeShowBufferedChildren:function(){this._isShown&&i.invoke(this._bufferedChildren,"triggerMethod","before:show")},_triggerShowBufferedChildren:function(){this._isShown&&(i.each(this._bufferedChildren,function(t){i.isFunction(t.triggerMethod)?t.triggerMethod("show"):h.triggerMethod.call(t,"show")}),this._bufferedChildren=[])},_initialEvents:function(){this.collection&&(this.listenTo(this.collection,"add",this._onCollectionAdd),this.listenTo(this.collection,"remove",this._onCollectionRemove),this.listenTo(this.collection,"reset",this.render),this.sort&&this.listenTo(this.collection,"sort",this._sortViews))},_onCollectionAdd:function(t){this.destroyEmptyView();var e=this.getChildView(t),i=this.collection.indexOf(t);this.addChild(t,e,i)},_onCollectionRemove:function(t){var e=this.children.findByModel(t);this.removeChildView(e),this.checkEmpty()},onShowCalled:function(){this.children.each(function(t){i.isFunction(t.triggerMethod)?t.triggerMethod("show"):h.triggerMethod.call(t,"show")})},render:function(){return this._ensureViewIsIntact(),this.triggerMethod("before:render",this),this._renderChildren(),this.triggerMethod("render",this),this},resortView:function(){this.render()},_sortViews:function(){var t=this.collection.find(function(t,e){var i=this.children.findByModel(t);return!i||i._index!==e},this);t&&this.resortView()},_renderChildren:function(){this.destroyEmptyView(),this.destroyChildren(),this.isEmpty(this.collection)?this.showEmptyView():(this.triggerMethod("before:render:collection",this),this.startBuffering(),this.showCollection(),this.endBuffering(),this.triggerMethod("render:collection",this))},showCollection:function(){var t;this.collection.each(function(e,i){t=this.getChildView(e),this.addChild(e,t,i)},this)},showEmptyView:function(){var t=this.getEmptyView();if(t&&!this._showingEmptyView){this.triggerMethod("before:render:empty"),this._showingEmptyView=!0;var i=new e.Model;this.addEmptyView(i,t),this.triggerMethod("render:empty")}},destroyEmptyView:function(){this._showingEmptyView&&(this.destroyChildren(),delete this._showingEmptyView)},getEmptyView:function(){return this.getOption("emptyView")},addEmptyView:function(t,e){var n=this.getOption("emptyViewOptions")||this.getOption("childViewOptions");i.isFunction(n)&&(n=n.call(this));var r=this.buildChildView(t,e,n);this._isShown&&this.triggerMethod.call(r,"before:show"),this.children.add(r),this.renderChildView(r,-1),this._isShown&&this.triggerMethod.call(r,"show")},getChildView:function(t){var e=this.getOption("childView");return e||n('A "childView" must be specified',"NoChildViewError"),e},addChild:function(t,e,n){var r=this.getOption("childViewOptions");i.isFunction(r)&&(r=r.call(this,t,n));var o=this.buildChildView(t,e,r);return this._updateIndices(o,!0,n),this._addChildView(o,n),o},_updateIndices:function(t,e,i){this.sort&&(e?(t._index=i,this.children.each(function(e){e._index>=t._index&&e._index++})):this.children.each(function(e){e._index>=t._index&&e._index--}))},_addChildView:function(t,e){this.proxyChildEvents(t),this.triggerMethod("before:add:child",t),this.children.add(t),this.renderChildView(t,e),this._isShown&&!this.isBuffering&&(i.isFunction(t.triggerMethod)?t.triggerMethod("show"):h.triggerMethod.call(t,"show")),this.triggerMethod("add:child",t)},renderChildView:function(t,e){return t.render(),this.attachHtml(this,t,e),t},buildChildView:function(t,e,n){var r=i.extend({model:t},n);return new e(r)},removeChildView:function(t){return t&&(this.triggerMethod("before:remove:child",t),t.destroy?t.destroy():t.remove&&t.remove(),this.stopListening(t),this.children.remove(t),this.triggerMethod("remove:child",t),this._updateIndices(t,!1)),t},isEmpty:function(t){return!this.collection||0===this.collection.length},checkEmpty:function(){this.isEmpty(this.collection)&&this.showEmptyView()},attachBuffer:function(t,e){t.$el.append(e)},attachHtml:function(t,e,i){t.isBuffering?(t.elBuffer.appendChild(e.el),t._bufferedChildren.push(e)):t._insertBefore(e,i)||t._insertAfter(e)},_insertBefore:function(t,e){var i,n=this.sort&&e<this.children.length-1;return n&&(i=this.children.find(function(t){return t._index===e+1})),!!i&&(i.$el.before(t.el),!0)},_insertAfter:function(t){this.$el.append(t.el)},_initChildViewStorage:function(){this.children=new r},destroy:function(){if(!this.isDestroyed)return this.triggerMethod("before:destroy:collection"),this.destroyChildren(),this.triggerMethod("destroy:collection"),h.View.prototype.destroy.apply(this,arguments)},destroyChildren:function(){var t=this.children.map(i.identity);return this.children.each(this.removeChildView,this),this.checkEmpty(),t},proxyChildEvents:function(t){var e=this.getOption("childViewEventPrefix");this.listenTo(t,"all",function(){var n=a.call(arguments),r=n[0],o=this.normalizeMethods(i.result(this,"childEvents"));n[0]=e+":"+r,n.splice(1,0,t),"undefined"!=typeof o&&i.isFunction(o[r])&&o[r].apply(this,n.slice(1)),this.triggerMethod.apply(this,n)},this)}}),h.CompositeView=h.CollectionView.extend({constructor:function(){h.CollectionView.apply(this,arguments)},_initialEvents:function(){this.once("render",function(){this.collection&&(this.listenTo(this.collection,"add",this._onCollectionAdd),this.listenTo(this.collection,"remove",this._onCollectionRemove),this.listenTo(this.collection,"reset",this._renderChildren),this.sort&&this.listenTo(this.collection,"sort",this._sortViews))})},getChildView:function(t){var e=this.getOption("childView")||this.constructor;return e||n('A "childView" must be specified',"NoChildViewError"),e},serializeData:function(){var t={};return this.model&&(t=i.partial(this.serializeModel,this.model).apply(this,arguments)),t},render:function(){return this._ensureViewIsIntact(),this.isRendered=!0,this.resetChildViewContainer(),this.triggerMethod("before:render",this),this._renderTemplate(),this._renderChildren(),this.triggerMethod("render",this),this},_renderChildren:function(){this.isRendered&&h.CollectionView.prototype._renderChildren.call(this)},_renderTemplate:function(){var t={};t=this.serializeData(),t=this.mixinTemplateHelpers(t),this.triggerMethod("before:render:template");var e=this.getTemplate(),i=h.Renderer.render(e,t,this);this.attachElContent(i),this.bindUIElements(),this.triggerMethod("render:template")},attachElContent:function(t){return this.$el.html(t),this},attachBuffer:function(t,e){var i=this.getChildViewContainer(t);i.append(e)},_insertAfter:function(t){var e=this.getChildViewContainer(this);e.append(t.el)},getChildViewContainer:function(t){if("$childViewContainer"in t)return t.$childViewContainer;var e,r=h.getOption(t,"childViewContainer");if(r){var o=i.isFunction(r)?r.call(t):r;e="@"===o.charAt(0)&&t.ui?t.ui[o.substr(4)]:t.$(o),e.length<=0&&n('The specified "childViewContainer" was not found: '+t.childViewContainer,"ChildViewContainerMissingError")}else e=t.$el;return t.$childViewContainer=e,e},resetChildViewContainer:function(){this.$childViewContainer&&delete this.$childViewContainer}}),h.LayoutView=h.ItemView.extend({regionClass:h.Region,constructor:function(t){t=t||{},this._firstRender=!0,this._initializeRegions(t),h.ItemView.call(this,t)},render:function(){return this._ensureViewIsIntact(),this._firstRender?this._firstRender=!1:this._reInitializeRegions(),h.ItemView.prototype.render.apply(this,arguments)},destroy:function(){return this.isDestroyed?this:(this.regionManager.destroy(),h.ItemView.prototype.destroy.apply(this,arguments))},addRegion:function(t,e){this.triggerMethod("before:region:add",t);var i={};return i[t]=e,this._buildRegions(i)[t]},addRegions:function(t){return this.regions=i.extend({},this.regions,t),this._buildRegions(t)},removeRegion:function(t){return this.triggerMethod("before:region:remove",t),delete this.regions[t],this.regionManager.removeRegion(t)},getRegion:function(t){return this.regionManager.get(t)},getRegions:function(){return this.regionManager.getRegions()},_buildRegions:function(t){var e=this,i={regionClass:this.getOption("regionClass"),parentEl:function(){return e.$el}};return this.regionManager.addRegions(t,i)},_initializeRegions:function(t){var e;this._initRegionManager(),e=i.isFunction(this.regions)?this.regions(t):this.regions||{};var n=this.getOption.call(t,"regions");i.isFunction(n)&&(n=n.call(this,t)),i.extend(e,n),this.addRegions(e)},_reInitializeRegions:function(){this.regionManager.emptyRegions(),this.regionManager.each(function(t){t.reset()})},getRegionManager:function(){return new h.RegionManager},_initRegionManager:function(){this.regionManager=this.getRegionManager(),this.listenTo(this.regionManager,"before:add:region",function(t){this.triggerMethod("before:add:region",t)}),this.listenTo(this.regionManager,"add:region",function(t,e){this[t]=e,this.triggerMethod("add:region",t,e)}),this.listenTo(this.regionManager,"before:remove:region",function(t){this.triggerMethod("before:remove:region",t)}),this.listenTo(this.regionManager,"remove:region",function(t,e){delete this[t],this.triggerMethod("remove:region",t,e)})}}),h.Behavior=function(t,e){function i(e,i){this.view=i,this.defaults=t.result(this,"defaults")||{},this.options=t.extend({},this.defaults,e),this.$=function(){return this.view.$.apply(this.view,arguments)},this.initialize.apply(this,arguments)}return t.extend(i.prototype,e.Events,{initialize:function(){},destroy:function(){this.stopListening()},triggerMethod:h.triggerMethod,getOption:h.proxyGetOption,bindEntityEvents:h.proxyBindEntityEvents,unbindEntityEvents:h.proxyUnbindEntityEvents}),i.extend=h.extend,i}(i,e),h.Behaviors=function(t,e){function i(t,r){r=i.parseBehaviors(t,r||e.result(t,"behaviors")),i.wrap(t,r,e.keys(n))}var n={setElement:function(t,i){return t.apply(this,e.tail(arguments,2)),e.each(i,function(t){t.$el=this.$el,t.el=this.el},this),this},destroy:function(t,i){var n=e.tail(arguments,2);return t.apply(this,n),e.invoke(i,"destroy",n),this},bindUIElements:function(t,i){t.apply(this),e.invoke(i,t)},unbindUIElements:function(t,i){t.apply(this),e.invoke(i,t)},triggerMethod:function(t,i){var n=e.tail(arguments,2);t.apply(this,n),e.each(i,function(e){t.apply(e,n)})},delegateEvents:function(i,n){var r=e.tail(arguments,2);return i.apply(this,r),e.each(n,function(e){t.bindEntityEvents(e,this.model,t.getOption(e,"modelEvents")),t.bindEntityEvents(e,this.collection,t.getOption(e,"collectionEvents"))},this),this},undelegateEvents:function(i,n){var r=e.tail(arguments,2);return i.apply(this,r),e.each(n,function(e){t.unbindEntityEvents(e,this.model,t.getOption(e,"modelEvents")),t.unbindEntityEvents(e,this.collection,t.getOption(e,"collectionEvents"))},this),this},behaviorEvents:function(i,n){var r={},o=e.result(this,"ui");return e.each(n,function(i,n){var s={},h=e.clone(e.result(i,"events"))||{},a=e.result(i,"ui"),l=e.extend({},o,a);h=t.normalizeUIKeys(h,l),e.each(e.keys(h),function(t){var r=new Array(n+2).join(" "),o=t+r,a=e.isFunction(h[t])?h[t]:i[h[t]];s[o]=e.bind(a,i)}),r=e.extend(r,s)}),r}};return e.extend(i,{behaviorsLookup:function(){throw new Error("You must define where your behaviors are stored.See https://github.com/marionettejs/backbone.marionette/blob/master/docs/marionette.behaviors.md#behaviorslookup")},getBehaviorClass:function(t,n){return t.behaviorClass?t.behaviorClass:e.isFunction(i.behaviorsLookup)?i.behaviorsLookup.apply(this,arguments)[n]:i.behaviorsLookup[n]},parseBehaviors:function(t,n){return e.chain(n).map(function(n,r){var o=i.getBehaviorClass(n,r),s=new o(n,t),h=i.parseBehaviors(t,e.result(s,"behaviors"));return[s].concat(h)}).flatten().value()},wrap:function(t,i,r){e.each(r,function(r){t[r]=e.partial(n[r],t[r],i)})}}),i}(h,i),h.AppRouter=e.Router.extend({constructor:function(t){e.Router.apply(this,arguments),this.options=t||{};var i=this.getOption("appRoutes"),n=this._getController();this.processAppRoutes(n,i),this.on("route",this._processOnRoute,this)},appRoute:function(t,e){var i=this._getController();this._addAppRoute(i,t,e)},_processOnRoute:function(t,e){var n=i.invert(this.getOption("appRoutes"))[t];i.isFunction(this.onRoute)&&this.onRoute(t,n,e)},processAppRoutes:function(t,e){if(e){var n=i.keys(e).reverse();i.each(n,function(i){this._addAppRoute(t,i,e[i])},this)}},_getController:function(){return this.getOption("controller")},_addAppRoute:function(t,e,r){var o=t[r];o||n('Method "'+r+'" was not found on the controller'),this.route(e,r,i.bind(o,t))},getOption:h.proxyGetOption}),h.Application=function(t){this._initializeRegions(t),this._initCallbacks=new h.Callbacks,this.submodules={},i.extend(this,t),this._initChannel()},i.extend(h.Application.prototype,e.Events,{execute:function(){this.commands.execute.apply(this.commands,arguments)},request:function(){return this.reqres.request.apply(this.reqres,arguments)},addInitializer:function(t){this._initCallbacks.add(t)},start:function(t){this.triggerMethod("before:start",t),this._initCallbacks.run(t,this),this.triggerMethod("start",t)},addRegions:function(t){return this._regionManager.addRegions(t)},emptyRegions:function(){
return this._regionManager.emptyRegions()},removeRegion:function(t){return this._regionManager.removeRegion(t)},getRegion:function(t){return this._regionManager.get(t)},getRegions:function(){return this._regionManager.getRegions()},module:function(t,e){var i=h.Module.getClass(e),n=a.call(arguments);return n.unshift(this),i.create.apply(i,n)},getRegionManager:function(){return new h.RegionManager},_initializeRegions:function(t){var e=i.isFunction(this.regions)?this.regions(t):this.regions||{};this._initRegionManager();var n=h.getOption(t,"regions");return i.isFunction(n)&&(n=n.call(this,t)),i.extend(e,n),this.addRegions(e),this},_initRegionManager:function(){this._regionManager=this.getRegionManager(),this.listenTo(this._regionManager,"before:add:region",function(t){this.triggerMethod("before:add:region",t)}),this.listenTo(this._regionManager,"add:region",function(t,e){this[t]=e,this.triggerMethod("add:region",t,e)}),this.listenTo(this._regionManager,"before:remove:region",function(t){this.triggerMethod("before:remove:region",t)}),this.listenTo(this._regionManager,"remove:region",function(t,e){delete this[t],this.triggerMethod("remove:region",t,e)})},_initChannel:function(){this.channelName=i.result(this,"channelName")||"global",this.channel=i.result(this,"channel")||o.radio.channel(this.channelName),this.vent=i.result(this,"vent")||this.channel.vent,this.commands=i.result(this,"commands")||this.channel.commands,this.reqres=i.result(this,"reqres")||this.channel.reqres},triggerMethod:h.triggerMethod,getOption:h.proxyGetOption}),h.Application.extend=h.extend,h.Module=function(t,e,n){this.moduleName=t,this.options=i.extend({},this.options,n),this.initialize=n.initialize||this.initialize,this.submodules={},this._setupInitializersAndFinalizers(),this.app=e,this.startWithParent=!0,i.isFunction(this.initialize)&&this.initialize(t,e,this.options)},h.Module.extend=h.extend,i.extend(h.Module.prototype,e.Events,{initialize:function(){},addInitializer:function(t){this._initializerCallbacks.add(t)},addFinalizer:function(t){this._finalizerCallbacks.add(t)},start:function(t){this._isInitialized||(i.each(this.submodules,function(e){e.startWithParent&&e.start(t)}),this.triggerMethod("before:start",t),this._initializerCallbacks.run(t,this),this._isInitialized=!0,this.triggerMethod("start",t))},stop:function(){this._isInitialized&&(this._isInitialized=!1,this.triggerMethod("before:stop"),i.each(this.submodules,function(t){t.stop()}),this._finalizerCallbacks.run(void 0,this),this._initializerCallbacks.reset(),this._finalizerCallbacks.reset(),this.triggerMethod("stop"))},addDefinition:function(t,e){this._runModuleDefinition(t,e)},_runModuleDefinition:function(t,n){if(t){var r=i.flatten([this,this.app,e,h,e.$,i,n]);t.apply(this,r)}},_setupInitializersAndFinalizers:function(){this._initializerCallbacks=new h.Callbacks,this._finalizerCallbacks=new h.Callbacks},triggerMethod:h.triggerMethod}),i.extend(h.Module,{create:function(t,e,n){var r=t,o=a.call(arguments);o.splice(0,3),e=e.split(".");var s=e.length,h=[];return h[s-1]=n,i.each(e,function(e,i){var s=r;r=this._getModule(s,e,t,n),this._addModuleDefinition(s,r,h[i],o)},this),r},_getModule:function(t,e,n,r,o){var s=i.extend({},r),h=this.getClass(r),a=t[e];return a||(a=new h(e,n,s),t[e]=a,t.submodules[e]=a),a},getClass:function(t){var e=h.Module;return t?t.prototype instanceof e?t:t.moduleClass||e:e},_addModuleDefinition:function(t,e,i,n){var r=this._getDefine(i),o=this._getStartWithParent(i,e);r&&e.addDefinition(r,n),this._addStartWithParent(t,e,o)},_getStartWithParent:function(t,e){var n;return i.isFunction(t)&&t.prototype instanceof h.Module?(n=e.constructor.prototype.startWithParent,!!i.isUndefined(n)||n):!i.isObject(t)||(n=t.startWithParent,!!i.isUndefined(n)||n)},_getDefine:function(t){return!i.isFunction(t)||t.prototype instanceof h.Module?i.isObject(t)?t.define:null:t},_addStartWithParent:function(t,e,i){e.startWithParent=e.startWithParent&&i,e.startWithParent&&!e.startWithParentIsConfigured&&(e.startWithParentIsConfigured=!0,t.addInitializer(function(t){e.startWithParent&&e.start(t)}))}}),h})});;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:marionette', location = 'jira-projects-module/sidebar/lib/backbone.marionette.adapter.js' */
define("jira/projects/libs/marionette",["backbone","underscore","atlassian/libs/factories/marionette-2.1.0"],function(e,r,t){"use strict";return t(r,e)}),AJS.namespace("JIRA.Projects.Libs.Marionette",null,require("jira/projects/libs/marionette"));;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:marionette', location = 'jira-projects-module/sidebar/lib/backbone.marionette.mixins.js' */
!function(){"use strict";function e(e,t){var i=this,r=_.defaults({},t||{},{isPrevented:!1,emitter:this,preventDefault:function(){this.isPrevented=!0,i.trigger(e+":prevented",this)}});return this.trigger(e,r),r}function t(e,t){var i=this.triggerPreventable(e,t);i.isPrevented&&t.preventDefault()}_.extend(JIRA.Projects.Libs.Marionette.View.prototype,{unwrapTemplate:function(){if(this.$el.parent().length){var e=this.$el.children();this.$el.replaceWith(e),this.setElement(e)}else this.setElement(this.$el.children())},triggerPreventable:e,retriggerPreventable:t}),_.extend(JIRA.Projects.Libs.Marionette.Controller.prototype,{triggerPreventable:e,retriggerPreventable:t}),JIRA.Projects.Libs.Marionette.ViewManager=JIRA.Projects.Libs.Marionette.Controller.extend({constructor:function(){JIRA.Projects.Libs.Marionette.Controller.apply(this,arguments),this.views={}},hideView:function(e){var t=this.views[e];t&&(this.stopListening(t),t.isDestroyed||t.destroy(),delete this.views[e])},showView:function(e,t){var i=this.buildView(e,t);i.render()},buildView:function(e,t){var i=this.views[e];return i||(i=t.call(this),this.listenTo(i,"destroy",function(){this.hideView(e)}),this.views[e]=i),i},getView:function(e){return this.views[e]}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:data', location = 'jira-projects-module/data/web-resource-manager.js' */
define("jira/projects/data/WRM",window.WRM);;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:projects-api', location = 'jira-projects-module/page/projects-api.js' */
define("jira/api/projects",["jira/projects/data/WRM"],function(e){"use strict";function t(t,r){if(void 0!==t)return t;var n=e.data.claim(r);return void 0!==n?n:AJS.Meta.get(r)}function r(e){return AJS.$('meta[name="'+e+'"]').attr("content")}var n=e.data.claim("project-key"),i=e.data.claim("project-id"),c=e.data.claim("project-name"),a=e.data.claim("project-type"),o=e.data.claim("is-project-admin"),u=e.data.claim("project-simplified");return{ProjectType:Object.freeze({SOFTWARE:"software",BUSINESS:"business"}),getCurrentProjectId:function(e){return i=t(i,"project-id"),(null==i||e)&&(i=r("ghx-project-id")),i},getCurrentProjectKey:function(e){return n=t(n,"project-key"),(null==n||e)&&(n=r("ghx-project-key")),n},getCurrentProjectName:function(){return c=t(c,"project-name")},getCurrentProjectType:function(){return a=t(a,"project-type")},isCurrentUserProjectAdmin:function(){return o=t(o,"is-project-admin")},isCurrentProjectSimplified:function(){return u=t(u,"project-simplified")}}}),AJS.namespace("JIRA.API.Projects",null,require("jira/api/projects"));;
;
/* module-key = 'com.atlassian.jira.jira-issue-nav-components:ajs-helper', location = 'jira-issue-navigator-components-module/util/ajshelper.js' */
define("jira/components/utils/ajshelper",[],function(){"use strict";function e(){return function(e,n){if(n){var r=n.data||{};r.searchSessionId=r.searchSessionId||t.Meta.get("search-session-id"),r.searchObjectId=r.searchObjectId||t.Meta.get("search-object-id"),r.searchContainerId=r.searchContainerId||t.Meta.get("search-container-id"),r.searchContentType=r.searchContentType||t.Meta.get("search-content-type"),n.data=r}t.trigger(e,n)}}var t=window.AJS;return{escapeHtml:t.escapeHtml.bind(t),LEFT:t.LEFT,Templates:t.Templates,HIDE_REASON:t.HIDE_REASON,trigger:e(),log:t.log.bind(t),extractBodyFromResponse:t.extractBodyFromResponse,whenIType:function(){return t.whenIType},activeShortcuts:function(){return t.activeShortcuts}}});
//# sourceMappingURL=ajshelper-min.js.map
;
;
/* module-key = 'com.atlassian.plugin.jslibs:underscore-1.5.2', location = 'atlassian-jslibs/libs/underscore/1.5.2/underscore.js' */
!function(n){define("atlassian/libs/underscore-1.5.2",function(){var t={};return n.call(t),"undefined"!=typeof exports?"undefined"!=typeof module&&module.exports?module.exports.noConflict():exports.noConflict():t._.noConflict()})}(function(){(function(){var n=this,t=n._,r={},e=Array.prototype,i=Object.prototype,u=Function.prototype,o=e.push,a=e.slice,c=e.concat,l=i.toString,f=i.hasOwnProperty,s=e.forEach,p=e.map,h=e.reduce,v=e.reduceRight,d=e.filter,y=e.every,g=e.some,m=e.indexOf,x=e.lastIndexOf,w=Array.isArray,b=Object.keys,_=u.bind,j=function(n){return n instanceof j?n:this instanceof j?void(this._wrapped=n):new j(n)};"undefined"!=typeof exports?("undefined"!=typeof module&&module.exports&&(exports=module.exports=j),exports._=j):n._=j,j.VERSION="1.5.2";var A=j.each=j.forEach=function(n,t,e){if(null!=n)if(s&&n.forEach===s)n.forEach(t,e);else if(n.length===+n.length){for(var i=0,u=n.length;i<u;i++)if(t.call(e,n[i],i,n)===r)return}else for(var o=j.keys(n),i=0,u=o.length;i<u;i++)if(t.call(e,n[o[i]],o[i],n)===r)return};j.map=j.collect=function(n,t,r){var e=[];return null==n?e:p&&n.map===p?n.map(t,r):(A(n,function(n,i,u){e.push(t.call(r,n,i,u))}),e)};var E="Reduce of empty array with no initial value";j.reduce=j.foldl=j.inject=function(n,t,r,e){var i=arguments.length>2;if(null==n&&(n=[]),h&&n.reduce===h)return e&&(t=j.bind(t,e)),i?n.reduce(t,r):n.reduce(t);if(A(n,function(n,u,o){i?r=t.call(e,r,n,u,o):(r=n,i=!0)}),!i)throw new TypeError(E);return r},j.reduceRight=j.foldr=function(n,t,r,e){var i=arguments.length>2;if(null==n&&(n=[]),v&&n.reduceRight===v)return e&&(t=j.bind(t,e)),i?n.reduceRight(t,r):n.reduceRight(t);var u=n.length;if(u!==+u){var o=j.keys(n);u=o.length}if(A(n,function(a,c,l){c=o?o[--u]:--u,i?r=t.call(e,r,n[c],c,l):(r=n[c],i=!0)}),!i)throw new TypeError(E);return r},j.find=j.detect=function(n,t,r){var e;return O(n,function(n,i,u){if(t.call(r,n,i,u))return e=n,!0}),e},j.filter=j.select=function(n,t,r){var e=[];return null==n?e:d&&n.filter===d?n.filter(t,r):(A(n,function(n,i,u){t.call(r,n,i,u)&&e.push(n)}),e)},j.reject=function(n,t,r){return j.filter(n,function(n,e,i){return!t.call(r,n,e,i)},r)},j.every=j.all=function(n,t,e){t||(t=j.identity);var i=!0;return null==n?i:y&&n.every===y?n.every(t,e):(A(n,function(n,u,o){if(!(i=i&&t.call(e,n,u,o)))return r}),!!i)};var O=j.some=j.any=function(n,t,e){t||(t=j.identity);var i=!1;return null==n?i:g&&n.some===g?n.some(t,e):(A(n,function(n,u,o){if(i||(i=t.call(e,n,u,o)))return r}),!!i)};j.contains=j.include=function(n,t){return null!=n&&(m&&n.indexOf===m?n.indexOf(t)!=-1:O(n,function(n){return n===t}))},j.invoke=function(n,t){var r=a.call(arguments,2),e=j.isFunction(t);return j.map(n,function(n){return(e?t:n[t]).apply(n,r)})},j.pluck=function(n,t){return j.map(n,function(n){return n[t]})},j.where=function(n,t,r){return j.isEmpty(t)?r?void 0:[]:j[r?"find":"filter"](n,function(n){for(var r in t)if(t[r]!==n[r])return!1;return!0})},j.findWhere=function(n,t){return j.where(n,t,!0)},j.max=function(n,t,r){if(!t&&j.isArray(n)&&n[0]===+n[0]&&n.length<65535)return Math.max.apply(Math,n);if(!t&&j.isEmpty(n))return-(1/0);var e={computed:-(1/0),value:-(1/0)};return A(n,function(n,i,u){var o=t?t.call(r,n,i,u):n;o>e.computed&&(e={value:n,computed:o})}),e.value},j.min=function(n,t,r){if(!t&&j.isArray(n)&&n[0]===+n[0]&&n.length<65535)return Math.min.apply(Math,n);if(!t&&j.isEmpty(n))return 1/0;var e={computed:1/0,value:1/0};return A(n,function(n,i,u){var o=t?t.call(r,n,i,u):n;o<e.computed&&(e={value:n,computed:o})}),e.value},j.shuffle=function(n){var t,r=0,e=[];return A(n,function(n){t=j.random(r++),e[r-1]=e[t],e[t]=n}),e},j.sample=function(n,t,r){return arguments.length<2||r?n[j.random(n.length-1)]:j.shuffle(n).slice(0,Math.max(0,t))};var k=function(n){return j.isFunction(n)?n:function(t){return t[n]}};j.sortBy=function(n,t,r){var e=k(t);return j.pluck(j.map(n,function(n,t,i){return{value:n,index:t,criteria:e.call(r,n,t,i)}}).sort(function(n,t){var r=n.criteria,e=t.criteria;if(r!==e){if(r>e||void 0===r)return 1;if(r<e||void 0===e)return-1}return n.index-t.index}),"value")};var F=function(n){return function(t,r,e){var i={},u=null==r?j.identity:k(r);return A(t,function(r,o){var a=u.call(e,r,o,t);n(i,a,r)}),i}};j.groupBy=F(function(n,t,r){(j.has(n,t)?n[t]:n[t]=[]).push(r)}),j.indexBy=F(function(n,t,r){n[t]=r}),j.countBy=F(function(n,t){j.has(n,t)?n[t]++:n[t]=1}),j.sortedIndex=function(n,t,r,e){r=null==r?j.identity:k(r);for(var i=r.call(e,t),u=0,o=n.length;u<o;){var a=u+o>>>1;r.call(e,n[a])<i?u=a+1:o=a}return u},j.toArray=function(n){return n?j.isArray(n)?a.call(n):n.length===+n.length?j.map(n,j.identity):j.values(n):[]},j.size=function(n){return null==n?0:n.length===+n.length?n.length:j.keys(n).length},j.first=j.head=j.take=function(n,t,r){if(null!=n)return null==t||r?n[0]:a.call(n,0,t)},j.initial=function(n,t,r){return a.call(n,0,n.length-(null==t||r?1:t))},j.last=function(n,t,r){if(null!=n)return null==t||r?n[n.length-1]:a.call(n,Math.max(n.length-t,0))},j.rest=j.tail=j.drop=function(n,t,r){return a.call(n,null==t||r?1:t)},j.compact=function(n){return j.filter(n,j.identity)};var M=function(n,t,r){return t&&j.every(n,j.isArray)?c.apply(r,n):(A(n,function(n){j.isArray(n)||j.isArguments(n)?t?o.apply(r,n):M(n,t,r):r.push(n)}),r)};j.flatten=function(n,t){return M(n,t,[])},j.without=function(n){return j.difference(n,a.call(arguments,1))},j.uniq=j.unique=function(n,t,r,e){j.isFunction(t)&&(e=r,r=t,t=!1);var i=r?j.map(n,r,e):n,u=[],o=[];return A(i,function(r,e){(t?e&&o[o.length-1]===r:j.contains(o,r))||(o.push(r),u.push(n[e]))}),u},j.union=function(){return j.uniq(j.flatten(arguments,!0))},j.intersection=function(n){var t=a.call(arguments,1);return j.filter(j.uniq(n),function(n){return j.every(t,function(t){return j.indexOf(t,n)>=0})})},j.difference=function(n){var t=c.apply(e,a.call(arguments,1));return j.filter(n,function(n){return!j.contains(t,n)})},j.zip=function(){for(var n=j.max(j.pluck(arguments,"length").concat(0)),t=new Array(n),r=0;r<n;r++)t[r]=j.pluck(arguments,""+r);return t},j.object=function(n,t){if(null==n)return{};for(var r={},e=0,i=n.length;e<i;e++)t?r[n[e]]=t[e]:r[n[e][0]]=n[e][1];return r},j.indexOf=function(n,t,r){if(null==n)return-1;var e=0,i=n.length;if(r){if("number"!=typeof r)return e=j.sortedIndex(n,t),n[e]===t?e:-1;e=r<0?Math.max(0,i+r):r}if(m&&n.indexOf===m)return n.indexOf(t,r);for(;e<i;e++)if(n[e]===t)return e;return-1},j.lastIndexOf=function(n,t,r){if(null==n)return-1;var e=null!=r;if(x&&n.lastIndexOf===x)return e?n.lastIndexOf(t,r):n.lastIndexOf(t);for(var i=e?r:n.length;i--;)if(n[i]===t)return i;return-1},j.range=function(n,t,r){arguments.length<=1&&(t=n||0,n=0),r=arguments[2]||1;for(var e=Math.max(Math.ceil((t-n)/r),0),i=0,u=new Array(e);i<e;)u[i++]=n,n+=r;return u};var R=function(){};j.bind=function(n,t){var r,e;if(_&&n.bind===_)return _.apply(n,a.call(arguments,1));if(!j.isFunction(n))throw new TypeError;return r=a.call(arguments,2),e=function(){if(!(this instanceof e))return n.apply(t,r.concat(a.call(arguments)));R.prototype=n.prototype;var i=new R;R.prototype=null;var u=n.apply(i,r.concat(a.call(arguments)));return Object(u)===u?u:i}},j.partial=function(n){var t=a.call(arguments,1);return function(){return n.apply(this,t.concat(a.call(arguments)))}},j.bindAll=function(n){var t=a.call(arguments,1);if(0===t.length)throw new Error("bindAll must be passed function names");return A(t,function(t){n[t]=j.bind(n[t],n)}),n},j.memoize=function(n,t){var r={};return t||(t=j.identity),function(){var e=t.apply(this,arguments);return j.has(r,e)?r[e]:r[e]=n.apply(this,arguments)}},j.delay=function(n,t){var r=a.call(arguments,2);return setTimeout(function(){return n.apply(null,r)},t)},j.defer=function(n){return j.delay.apply(j,[n,1].concat(a.call(arguments,1)))},j.throttle=function(n,t,r){var e,i,u,o=null,a=0;r||(r={});var c=function(){a=r.leading===!1?0:new Date,o=null,u=n.apply(e,i)};return function(){var l=new Date;a||r.leading!==!1||(a=l);var f=t-(l-a);return e=this,i=arguments,f<=0?(clearTimeout(o),o=null,a=l,u=n.apply(e,i)):o||r.trailing===!1||(o=setTimeout(c,f)),u}},j.debounce=function(n,t,r){var e,i,u,o,a;return function(){u=this,i=arguments,o=new Date;var c=function(){var l=new Date-o;l<t?e=setTimeout(c,t-l):(e=null,r||(a=n.apply(u,i)))},l=r&&!e;return e||(e=setTimeout(c,t)),l&&(a=n.apply(u,i)),a}},j.once=function(n){var t,r=!1;return function(){return r?t:(r=!0,t=n.apply(this,arguments),n=null,t)}},j.wrap=function(n,t){return function(){var r=[n];return o.apply(r,arguments),t.apply(this,r)}},j.compose=function(){var n=arguments;return function(){for(var t=arguments,r=n.length-1;r>=0;r--)t=[n[r].apply(this,t)];return t[0]}},j.after=function(n,t){return function(){if(--n<1)return t.apply(this,arguments)}},j.keys=b||function(n){if(n!==Object(n))throw new TypeError("Invalid object");var t=[];for(var r in n)j.has(n,r)&&t.push(r);return t},j.values=function(n){for(var t=j.keys(n),r=t.length,e=new Array(r),i=0;i<r;i++)e[i]=n[t[i]];return e},j.pairs=function(n){for(var t=j.keys(n),r=t.length,e=new Array(r),i=0;i<r;i++)e[i]=[t[i],n[t[i]]];return e},j.invert=function(n){for(var t={},r=j.keys(n),e=0,i=r.length;e<i;e++)t[n[r[e]]]=r[e];return t},j.functions=j.methods=function(n){var t=[];for(var r in n)j.isFunction(n[r])&&t.push(r);return t.sort()},j.extend=function(n){return A(a.call(arguments,1),function(t){if(t)for(var r in t)n[r]=t[r]}),n},j.pick=function(n){var t={},r=c.apply(e,a.call(arguments,1));return A(r,function(r){r in n&&(t[r]=n[r])}),t},j.omit=function(n){var t={},r=c.apply(e,a.call(arguments,1));for(var i in n)j.contains(r,i)||(t[i]=n[i]);return t},j.defaults=function(n){return A(a.call(arguments,1),function(t){if(t)for(var r in t)void 0===n[r]&&(n[r]=t[r])}),n},j.clone=function(n){return j.isObject(n)?j.isArray(n)?n.slice():j.extend({},n):n},j.tap=function(n,t){return t(n),n};var S=function(n,t,r,e){if(n===t)return 0!==n||1/n==1/t;if(null==n||null==t)return n===t;n instanceof j&&(n=n._wrapped),t instanceof j&&(t=t._wrapped);var i=l.call(n);if(i!=l.call(t))return!1;switch(i){case"[object String]":return n==String(t);case"[object Number]":return n!=+n?t!=+t:0==n?1/n==1/t:n==+t;case"[object Date]":case"[object Boolean]":return+n==+t;case"[object RegExp]":return n.source==t.source&&n.global==t.global&&n.multiline==t.multiline&&n.ignoreCase==t.ignoreCase}if("object"!=typeof n||"object"!=typeof t)return!1;for(var u=r.length;u--;)if(r[u]==n)return e[u]==t;var o=n.constructor,a=t.constructor;if(o!==a&&!(j.isFunction(o)&&o instanceof o&&j.isFunction(a)&&a instanceof a))return!1;r.push(n),e.push(t);var c=0,f=!0;if("[object Array]"==i){if(c=n.length,f=c==t.length)for(;c--&&(f=S(n[c],t[c],r,e)););}else{for(var s in n)if(j.has(n,s)&&(c++,!(f=j.has(t,s)&&S(n[s],t[s],r,e))))break;if(f){for(s in t)if(j.has(t,s)&&!c--)break;f=!c}}return r.pop(),e.pop(),f};j.isEqual=function(n,t){return S(n,t,[],[])},j.isEmpty=function(n){if(null==n)return!0;if(j.isArray(n)||j.isString(n))return 0===n.length;for(var t in n)if(j.has(n,t))return!1;return!0},j.isElement=function(n){return!(!n||1!==n.nodeType)},j.isArray=w||function(n){return"[object Array]"==l.call(n)},j.isObject=function(n){return n===Object(n)},A(["Arguments","Function","String","Number","Date","RegExp"],function(n){j["is"+n]=function(t){return l.call(t)=="[object "+n+"]"}}),j.isArguments(arguments)||(j.isArguments=function(n){return!(!n||!j.has(n,"callee"))}),"function"!=typeof/./&&(j.isFunction=function(n){return"function"==typeof n}),j.isFinite=function(n){return isFinite(n)&&!isNaN(parseFloat(n))},j.isNaN=function(n){return j.isNumber(n)&&n!=+n},j.isBoolean=function(n){return n===!0||n===!1||"[object Boolean]"==l.call(n)},j.isNull=function(n){return null===n},j.isUndefined=function(n){return void 0===n},j.has=function(n,t){return f.call(n,t)},j.noConflict=function(){return n._=t,this},j.identity=function(n){return n},j.times=function(n,t,r){for(var e=Array(Math.max(0,n)),i=0;i<n;i++)e[i]=t.call(r,i);return e},j.random=function(n,t){return null==t&&(t=n,n=0),n+Math.floor(Math.random()*(t-n+1))};var I={escape:{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;"}};I.unescape=j.invert(I.escape);var T={escape:new RegExp("["+j.keys(I.escape).join("")+"]","g"),unescape:new RegExp("("+j.keys(I.unescape).join("|")+")","g")};j.each(["escape","unescape"],function(n){j[n]=function(t){return null==t?"":(""+t).replace(T[n],function(t){return I[n][t]})}}),j.result=function(n,t){if(null!=n){var r=n[t];return j.isFunction(r)?r.call(n):r}},j.mixin=function(n){A(j.functions(n),function(t){var r=j[t]=n[t];j.prototype[t]=function(){var n=[this._wrapped];return o.apply(n,arguments),z.call(this,r.apply(j,n))}})};var N=0;j.uniqueId=function(n){var t=++N+"";return n?n+t:t},j.templateSettings={evaluate:/<%([\s\S]+?)%>/g,interpolate:/<%=([\s\S]+?)%>/g,escape:/<%-([\s\S]+?)%>/g};var q=/(.)^/,B={"'":"'","\\":"\\","\r":"r","\n":"n","\t":"t","\u2028":"u2028","\u2029":"u2029"},C=/\\|'|\r|\n|\t|\u2028|\u2029/g,D=/^\s*(\w|\$)+\s*$/;j.template=function(n,t,r){var e;r=j.defaults({},r,j.templateSettings);var i=new RegExp([(r.escape||q).source,(r.interpolate||q).source,(r.evaluate||q).source].join("|")+"|$","g"),u=0,o="__p+='";n.replace(i,function(t,r,e,i,a){return o+=n.slice(u,a).replace(C,function(n){return"\\"+B[n]}),r&&(o+="'+\n((__t=("+r+"))==null?'':_.escape(__t))+\n'"),e&&(o+="'+\n((__t=("+e+"))==null?'':__t)+\n'"),i&&(o+="';\n"+i+"\n__p+='"),u=a+t.length,t}),o+="';\n";var a=r.variable;if(a){if(!D.test(a))throw new Error(a)}else o="with(obj||{}){\n"+o+"}\n",a="obj";o="var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n"+o+"return __p;\n";try{e=new Function(a,"_",o)}catch(n){throw n.source=o,n}if(t)return e(t,j);var c=function(n){return e.call(this,n,j)};return c.source="function("+a+"){\n"+o+"}",c},j.chain=function(n){return j(n).chain()};var z=function(n){return this._chain?j(n).chain():n};j.mixin(j),A(["pop","push","reverse","shift","sort","splice","unshift"],function(n){var t=e[n];j.prototype[n]=function(){var r=this._wrapped;return t.apply(r,arguments),"shift"!=n&&"splice"!=n||0!==r.length||delete r[0],z.call(this,r)}}),A(["concat","join","slice"],function(n){var t=e[n];j.prototype[n]=function(){return z.call(this,t.apply(this._wrapped,arguments))}}),j.extend(j.prototype,{chain:function(){return this._chain=!0,this},value:function(){return this._wrapped}})}).call(this)});;
;
/* module-key = 'com.atlassian.jira.jira-issue-nav-components:underscore', location = 'jira-issue-navigator-components-module/libs/underscore.js' */
define("jira/components/libs/underscore",["require"],function(e){"use strict";return e("atlassian/libs/underscore-1.5.2")});
//# sourceMappingURL=underscore-min.js.map
;
;
/* module-key = 'com.atlassian.jira.jira-issue-nav-components:analytics-tracker', location = 'jira-issue-navigator-components-module/analytics-tracker/tracker.js' */
define("jira/components/analytics-tracker/tracker",["jira/components/libs/underscore","jira/issue","jira/components/utils/ajshelper","jquery","jira/customevents/trigger-custom-event"],function(e,t,n,r,i){"use strict";function o(){if(!h)try{h=require("jira/api/projects")}catch(e){h=null}}function a(){return g?g:(o(),h?h.getCurrentProjectId():void 0)}function c(){return j?j:(o(),h?h.getCurrentProjectType():void 0)}function s(){return k?k:t?t.getIssueId():void 0}function u(e){if(e.attr("class")||e.attr("id"))return e;var t=e.parent().closest("[class], [id]");return t.length?t:e}function d(e){var t=r(e.target).closest(p),n=u(t);v("viewissue","generic-action",{className:n.attr("class")||"no-element-className",id:n.attr("id")||"no-element-id"}),w=!1}function l(){r(".issue-container").off("click",p,d).on("click",p,d),r("#create_link").off("click",d).on("click",d),y&&clearTimeout(y),y=setTimeout(function(){w&&v("viewissue","inactive-timeout")},m)}function v(t,r,o){var u=f+"."+t+"."+r;I=I||Math.round(performance.now());var d=Math.round(performance.now())-I;o=o||{};var l={projectId:o.projectId||a(),projectType:o.projectType||c(),issueId:o.issueId||s(),userAgent:window.navigator.userAgent,timeSinceIssueLoaded:d},v=e.extend(l,o);n.trigger("analyticsEvent",{name:u,data:v}),i.trigger("legacy-gas-v2-event",u,v)}var f="jira.platform.fe.web",m=3e5,p="a, .editable-field, button",g=void 0,j=void 0,k=void 0,w=void 0,y=void 0,I=void 0,h=void 0;return{initialize:function(e,t,n){g=e,j=t,k=n,w=!0,I=Math.round(performance.now()),l()},trackEvent:v}});
//# sourceMappingURL=tracker-min.js.map
;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-component', location = 'jira-projects-module/sidebar/component/component.js' */
define("jira/projects/sidebar/component",["underscore","jira/projects/data/WRM"],function(e,t){"use strict";var r=Boolean(t.data.claim("is-global-sidebar"));return JIRA.Projects.Libs.Marionette.CompositeView.extend({childEvents:{"before:select":function(e,t){this.hasASelectedItem()||(t.isInitial=!0),this.retriggerPreventable("before:select",t),t.isPrevented||this.deselectAllGroups()},select:function(e,t){this.trigger("select",t)},"before:deselect":function(e,t){this.retriggerPreventable("before:deselect",t)},deselect:function(e,t){this.trigger("deselect",t)},"before:navigate":function(e,t){this.retriggerPreventable("before:navigate",t)},"before:navigate:prevented":function(e,t){this.trigger("before:navigate:prevented",t)}},events:{"click .js-nav-project-title-link":"_clickProjectName","click .js-nav-project-avatar-link":"_clickProjectAvatar","click a[data-link-id='com.atlassian.jira.jira-projects-plugin:summary-page']":"_clickProjectSummary"},initialize:function(){this.render({force:!0});try{this.tracker=require("jira/components/analytics-tracker/tracker")}catch(e){}this.bindUIElements();var t=AJS.sidebar(".aui-sidebar");e.each(["expand-end","collapse-end","collapse-start"],function(e){t.on(e,function(){this.trigger(e)}.bind(this))}.bind(this))},render:function(t){t=e.defaults({},t,{force:!1});var r="el"in t,i=r||t.force===!0,n=this.children.length>0;if(!i)return this;var a=this.triggerPreventable("before:render");if(a.isPrevented)return this;if(n){var c=this.triggerPreventable("before:detach");if(c.isPrevented)return this;this.destroyChildren({checkEmpty:!1}),this.trigger("detach")}if(r){var o=jQuery(t.el);this.$el.replaceWith(o),this.setElement(o)}return this.$(".aui-sidebar-group").each(e.bind(function(e,t){var r=new JIRA.Projects.Sidebar.Component.NavigationGroup({el:t}),i=!!this.getGroup(r.id);i&&AJS.warn&&AJS.warn('Duplicated IDs detected. There are more than one NavigationGroup with id data-id="'+r.id+'"'),this.proxyChildEvents(r),this.children.add(r,r.id)},this)),this.trigger("render"),this},reflow:function(){AJS.sidebar(".aui-sidebar").reflow()},isCollapsed:function(){return AJS.sidebar(".aui-sidebar").isCollapsed()},deselectAllGroups:function(){this.children.call("deselect")},on:function(){return JIRA.Projects.Libs.Marionette.CompositeView.prototype.on.apply(this,arguments)},off:function(){return JIRA.Projects.Libs.Marionette.CompositeView.prototype.off.apply(this,arguments)},replaceGroup:function(e,t){var r=this.getGroup(e);r.$el.replaceWith(t.$el),t.cid=r.cid,this.children.remove(r),this.children.add(t,t.id)},getGroup:function(e){return this.children.findByCustom(e)},getGroupAt:function(e){return this.children.findByIndex(e)},getItem:function(e){return this.getDefaultGroup().getItem(e)},getElement:function(){return this._trackDeprecated("getElement"),this.el},getDefaultGroup:function(){return this.getGroup("sidebar-navigation-panel")},isProjectSidebar:function(){return!r},getSelectedScopeFilterId:function(){return this._trackDeprecated("getSelectedScopeFilterId"),this.$(".scope-filter a.scope-filter-trigger").attr("data-scope-filter-id")},setReportsItemLink:function(e){this._trackDeprecated("setReportsItemLink");var t=this.getGroup("sidebar-navigation-panel"),r=t.getItem("com.atlassian.jira.jira-projects-plugin:report-page");"undefined"==typeof r&&(r=t.getItem("com.pyxis.greenhopper.jira:global-sidebar-report")),r&&r.attr("href",e)},getAUISidebar:function(){return this._trackDeprecated("getAUISidebar"),AJS.sidebar(".aui-sidebar")},getContentContainer:function(){return this._trackDeprecated("getContentContainer"),this.$(".aui-sidebar-body .sidebar-content-container")},getSelectedNavigationItem:function(){return this.getDefaultGroup().getSelectedNavigationItem()},hasASelectedItem:function(){return this.getDefaultGroup().hasASelectedItem()},dim:function(){this._trackDeprecated("dim"),this.$el.attr({dimmed:"","aria-hidden":"true"})},undim:function(){this._trackDeprecated("undim"),this.$el.removeAttr("dimmed"),this.$el.removeAttr("aria-hidden")},_clickProjectName:function(){"undefined"!=typeof this.tracker&&this.tracker.trackEvent("project.sidebar","click.projectName")},_clickProjectAvatar:function(){"undefined"!=typeof this.tracker&&this.tracker.trackEvent("project.sidebar","click.avatar")},_clickProjectSummary:function(){"undefined"!=typeof this.tracker&&this.tracker.trackEvent("project.sidebar","click.projectSummary")},_trackDeprecated:function(e){AJS.warn("The Sidebar method "+e+" is going to be deprecated"),AJS.trigger("analyticsEvent",{name:"jira.project.centric.navigation.sidebar.method.deprecated",data:{method:e}})}})}),AJS.namespace("JIRA.Projects.Sidebar.Component",null,require("jira/projects/sidebar/component"));;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-component', location = 'jira-projects-module/sidebar/component/navigation-item.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.Component.NavigationItem"),JIRA.Projects.Sidebar.Component.NavigationItem=JIRA.Projects.Libs.Marionette.CompositeView.extend({ui:{link:"a.aui-nav-item"},events:{'simpleClick @ui.link:not([target="_blank"])':function(e){e.preventDefault(),this.navigate()}},initialize:function(){this.id=this.$el.find(">a").attr("data-link-id"),this.bindUIElements()},onDestroy:function(){this.unbind()},getElement:function(){return this._trackDeprecated("getElement"),this.el},navigate:function(){if(this.select()){var e=this.triggerPreventable("before:navigate");if(e.isPrevented)return!1;var t=this.ui.link.attr("href");return t&&require("jira/util/browser").reloadViaWindowLocation(t),!0}},select:function(){var e=this.triggerPreventable("before:select");return!e.isPrevented&&(this.$el.addClass("aui-nav-selected"),this.trigger("select",e),!0)},deselect:function(){if(!this.isSelected())return!0;var e=this.triggerPreventable("before:deselect");return!e.isPrevented&&(this.$el.removeClass("aui-nav-selected"),this.$el.find("a").blur(),this.trigger("deselect",e),!0)},isSelected:function(){return this.$el.hasClass("aui-nav-selected")},removeBadge:function(){this.$el.find(".aui-badge").remove()},getId:function(){return this.id},getSelectedNavigationItem:function(){if(this.isSelected())return this},hasASelectedItem:function(){return this.isSelected()},attr:function(e,t){var i=this.ui.link.attr(e,t);return t?i:this},_trackDeprecated:function(e){AJS.warn("The Sidebar item method "+e+" is going to be deprecated"),AJS.trigger("analyticsEvent",{name:"jira.project.centric.navigation.sidebar.item.method.deprecated",data:{method:e}})}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-component', location = 'jira-projects-module/sidebar/component/navigation-group.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.Component.NavigationGroup"),JIRA.Projects.Sidebar.Component.NavigationGroup=JIRA.Projects.Libs.Marionette.CompositeView.extend({childEvents:{"before:select":function(e,t){if(this.retriggerPreventable("before:select",t),!t.isPrevented){var i=this.deselect();i||t.preventDefault()}},select:function(e,t){this.trigger("select",t)},"before:deselect":function(e,t){this.retriggerPreventable("before:deselect",t)},deselect:function(e,t){this.trigger("deselect",t)},"before:navigate":function(e,t){this.retriggerPreventable("before:navigate",t)},"before:navigate:prevented":function(e,t){this.trigger("before:navigate:prevented",t)}},initialize:function(){this.id=this.$el.attr("data-id"),this.$(">ul>li").each(_.bind(function(e,t){var i=JIRA.Projects.Sidebar.Component.NavigationGroup.build(t),n=!!this.getItem(i.id);n&&AJS.warn&&AJS.warn("Duplicated IDs detected. There are more than one NavigationItem with id data-link-id='"+i.id+"'"),this.proxyChildEvents(i),this.children.add(i,i.id)},this))},onDestroy:function(){this.unbind()},getElement:function(){return this._trackDeprecated("getElement"),this.el},deselect:function(){var e=this.triggerPreventable("before:deselect");if(e.isPrevented)return!1;var t=!0;return this.children.each(function(e){t=e.deselect()&&t}),t},getItem:function(e){return this.children.findByCustom(e)},getItemAt:function(e){return this.children.findByIndex(e)},getSelectedNavigationItem:function(){var e=this.children.find(function(e){return e.hasASelectedItem()});if(e)return e.getSelectedNavigationItem()},hasASelectedItem:function(){return this.children.any(function(e){return e.hasASelectedItem()})},_trackDeprecated:function(e){AJS.warn("The Sidebar group method "+e+" is going to be deprecated"),AJS.trigger("analyticsEvent",{name:"jira.project.centric.navigation.sidebar.group.method.deprecated",data:{method:e}})}},{build:function(e){var t;return t=AJS.$(e).find("ul").length?new JIRA.Projects.Sidebar.Component.NavigationSubgroup({el:e}):new JIRA.Projects.Sidebar.Component.NavigationItem({el:e})}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-component', location = 'jira-projects-module/sidebar/component/navigation-subgroup.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.Component.NavigationSubgroup"),JIRA.Projects.Sidebar.Component.NavigationSubgroup=JIRA.Projects.Sidebar.Component.NavigationGroup.extend({childEvents:{"before:select":function(e,t){JIRA.Projects.Sidebar.Component.NavigationGroup.prototype.childEvents["before:select"].apply(this,arguments),t.isPrevented||this.expand()}},initialize:function(){this.childEvents=_.extend({},JIRA.Projects.Sidebar.Component.NavigationGroup.prototype.childEvents,this.childEvents),JIRA.Projects.Sidebar.Component.NavigationGroup.prototype.initialize.apply(this,arguments),this.id=this.$el.find(">a[data-link-id]").attr("data-link-id")},expand:function(){this.$el.attr("aria-expanded","true")},collapse:function(){this.$el.attr("aria-expanded","false")},isExpanded:function(){return"true"===this.$el.attr("aria-expanded")},isSelected:function(){return this.$el.hasClass("aui-nav-selected")},getId:function(){return this.id},getSelectedNavigationItem:function(){if(this.isSelected())return this;var e=this.children.find(function(e){return e.hasASelectedItem()});return e?e.getSelectedNavigationItem():void 0},hasASelectedItem:function(){return!!this.isSelected()||this.children.any(function(e){return e.hasASelectedItem()})}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-api', location = 'jira-projects-module/sidebar/api.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar"),AJS.namespace("JIRA.API");var e=AJS.$.Deferred();JIRA.API.getSidebar=JIRA.API.getSidebar||function(){return e.promise()},JIRA.Projects.Sidebar.initAPI=function(r){JIRA.API.Sidebar=r,e.resolve(JIRA.API.Sidebar)}}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/templates.soy.js' */
if("undefined"==typeof JIRA)var JIRA={};"undefined"==typeof JIRA.Projects&&(JIRA.Projects={}),"undefined"==typeof JIRA.Projects.Sidebar&&(JIRA.Projects.Sidebar={}),"undefined"==typeof JIRA.Projects.Sidebar.ProjectShortcuts&&(JIRA.Projects.Sidebar.ProjectShortcuts={}),"undefined"==typeof JIRA.Projects.Sidebar.ProjectShortcuts.Templates&&(JIRA.Projects.Sidebar.ProjectShortcuts.Templates={}),JIRA.Projects.Sidebar.ProjectShortcuts.Templates.content=function(t,e){var o="";if(t.canManage||t.numberOfShortcuts>0){if(o+='<div class="aui-sidebar-group jira-sidebar-group-with-divider project-shortcuts-group'+(0==t.numberOfShortcuts?" project-shortcuts-group_empty":"")+'" data-id="project-shortcuts-group"><div class="aui-nav-heading">'+soy.$$escapeHtml("Project Shortcuts")+'</div><ul class="aui-nav project-shortcuts-list">',t.shortcuts)for(var s=t.shortcuts,a=s.length,i=0;i<a;i++){var r=s[i];o+=JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcut({id:r.id,name:r.name,url:r.url,icon:r.icon,canManage:t.canManage,iconsMap:t.iconsMap,isWithIcon:t.isWithIcons})}o+=(t.canManage?'<li><a class="aui-nav-item project-shortcuts-group__add" href="#" data-link-id="project-shortcut-add"><span class="aui-icon aui-icon-large aui-iconfont-add-small"></span><span class="aui-nav-item-label">'+soy.$$escapeHtml("Add shortcut")+"</span></a></li>":"")+"</ul></div>"}return o},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcut=function(t,e){return'<li class="project-shortcut"><a class="aui-nav-item project-shortcuts-group__link" href="'+soy.$$escapeHtml(t.url)+'" title="'+soy.$$escapeHtml(t.name)+'" target="_blank" data-shortcut-id="'+soy.$$escapeHtml(t.id)+'" data-link-id="project-shortcut-'+soy.$$escapeHtml(t.id)+'">'+(t.isWithIcon?'<span class="aui-icon aui-icon-large '+JIRA.Projects.Sidebar.ProjectShortcuts.Templates.icon({iconId:t.icon,iconsMap:t.iconsMap})+'" data-project-shortcuts-icon-id="'+soy.$$escapeHtml(t.icon)+'">'+soy.$$escapeHtml("Project shortcut icon")+"</span>":"")+'<span class="aui-nav-item-label">'+soy.$$escapeHtml(t.name)+"</span></a>"+(t.canManage?'<a href="#project-shortcuts-dropdown_'+soy.$$escapeHtml(t.id)+'" aria-owns="project-shortcuts-dropdown_'+soy.$$escapeHtml(t.id)+'" aria-haspopup="true" class="aui-dropdown2-trigger project-shortcuts-group__actions"><span>'+soy.$$escapeHtml("Actions")+'</span></a><div id="project-shortcuts-dropdown_'+soy.$$escapeHtml(t.id)+'" class="aui-dropdown2 aui-style-default project-shortcuts-group__dropdown"><ul class="aui-list-truncate"><li><a class="project-shortcuts-group__actions__edit" href="#">'+soy.$$escapeHtml("Edit")+'</a></li><li><a class="project-shortcuts-group__actions__delete  " href="#">'+soy.$$escapeHtml("Delete")+"</a></li></ul></div>":"")+"</li>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.icon=function(t,e){t=t||{};var o="";if(t.iconsMap){var s=t.iconId&&t.iconsMap[t.iconId]?t.iconId:"1";o+=t.iconsMap[s]?soy.$$escapeHtml(t.iconsMap[s].className):""}return o},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcutFormFields=function(t,e){return'<div class="project-shortcuts-field-group">'+aui.form.textField({name:"project-shortcuts-url-"+t.action,id:"project-shortcuts-url-"+t.action,labelContent:"Web address",placeholderText:"e.g. http://www.atlassian.com",extraClasses:"project-shortcuts-url",value:t.url?t.url:"",errorTexts:t.errors.urlError?[t.errors.urlError]:[]})+'<div class="field-group project-shortcuts-name">'+aui.form.label({forField:"project-shortcuts-name-"+t.action,content:"Name"})+'<div class="project-shortcuts-name-icon-block"><div class="project-shortcuts-icon-picker-block"></div>'+aui.form.input({name:"project-shortcuts-name-"+t.action,id:"project-shortcuts-name-"+t.action,placeholderText:"e.g. Atlassian website",extraClasses:"project-shortcuts-name-input"+(t.isWithIcon?" project-shortcuts-name-input-with-icon":""),value:t.name?t.name:"",type:"text"})+"</div>"+(t.errors.iconError?aui.form.fieldError({message:t.errors.iconError}):"")+(t.errors.nameError?aui.form.fieldError({message:t.errors.nameError}):"")+"</div></div>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.iconsPicker=function(t,e){return"<span>"+JIRA.Projects.Sidebar.ProjectShortcuts.Templates.iconsList(t)+"</span>"+aui.dropdown2.trigger({menu:{id:"project-shortcuts-icons-list-"+t.cid},extraClasses:"aui-button project-shortcuts-icons-picker",iconClasses:"aui-icon aui-icon-large  "+soy.$$escapeHtml(t.icon.className),extraAttributes:{href:"#"}})},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.iconsList=function(t,e){for(var o='<div id="project-shortcuts-icons-list-'+soy.$$escapeHtml(t.cid)+'" aria-hidden="true" class="aui-style-default aui-dropdown2 project-shortcuts-icons-list aui-dropdown2-section"><ul>',s=t.iconsList,a=s.length,i=0;i<a;i++){var r=s[i];o+='<li><a class="project-shortcuts-icons-icon" data-project-shortcuts-icons-id="'+soy.$$escapeHtml(r.name)+'"><span class="aui-icon aui-icon-large '+soy.$$escapeHtml(r.className)+'">'+soy.$$escapeHtml("Project shortcut icon")+"</span></a></li>"}return o+="</ul></div>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.addDialog=function(t,e){return'<section role="dialog" id="add-shortcut-dialog" class="aui-layer aui-dialog2 aui-dialog2-medium" aria-hidden="false"><header class="aui-dialog2-header" id="add-shortcut-dialog-header"></header><div class="aui-dialog2-content"><div id="image-behind"><div id="image-behind-top"></div><div id="image-behind-bottom"></div></div><div id="add-shortcut-image-container"><div id="add-shortcut-dialog-image"></div></div><form action="" method="post" class="aui"><h1>'+soy.$$escapeHtml("Add shortcut")+"</h1><fieldset>"+JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcutFormFields(soy.$$augmentMap(t,{action:"add"}))+'</fieldset><button type="submit" class="project-shortcuts-hidden-submit" tabindex="-1"></button></form></div><div class="aui-dialog2-footer"><div class="buttons-container"><div class="buttons"><button class="aui-button aui-button-primary project-shortcuts-submit">'+soy.$$escapeHtml("Add")+'</button><button class="aui-button aui-button-text aui-button-subtle project-shortcuts-cancel">'+soy.$$escapeHtml("Cancel")+"</button></div></div></div></section>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.editDialogChrome=function(t,e){return'<section role="dialog" id="edit-project-shortcut-dialog" class="aui-layer aui-dialog2 aui-dialog2-small" aria-hidden="true" data-aui-remove-on-hide="true"><header class="aui-dialog2-header"><h2 class="aui-dialog2-header-main">'+soy.$$escapeHtml("Edit shortcut")+"</h2></header></section>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.editDialog=function(t,e){return'<section role="dialog" id="add-shortcut-dialog" class="aui-layer aui-dialog2 aui-dialog2-medium" aria-hidden="false"><header class="aui-dialog2-header" id="add-shortcut-dialog-header"></header><div class="aui-dialog2-content"><div id="image-behind"><div id="image-behind-top"></div><div id="image-behind-bottom"></div></div><div id="add-shortcut-image-container"><div id="add-shortcut-dialog-image"></div></div><form class="aui" method="post"><h1>'+soy.$$escapeHtml("Edit shortcut")+"</h1>"+JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcutFormFields(soy.$$augmentMap(t,{action:"edit"}))+'<button type="submit" class="project-shortcuts-hidden-submit" tabindex="-1"></button></form></div><footer class="aui-dialog2-footer"><div class="aui-dialog2-footer-actions"><button class="aui-button project-shortcuts-delete">'+soy.$$escapeHtml("Delete")+'</button><button class="aui-button aui-button-primary project-shortcuts-submit">'+soy.$$escapeHtml("Save")+'</button><button class="aui-button aui-button-link project-shortcuts-cancel aui-button-subtle">'+soy.$$escapeHtml("Cancel")+"</button></div></footer></section>"},JIRA.Projects.Sidebar.ProjectShortcuts.Templates.deleteDialog=function(t,e){return'<section role="dialog" id="delete-project-shortcut-dialog" class="aui-layer aui-dialog2 aui-dialog2-small" aria-hidden="true" data-aui-remove-on-hide="true"><header class="aui-dialog2-header"><h2 class="aui-dialog2-header-main">'+soy.$$escapeHtml("Delete shortcut")+'</h2></header><div class="aui-dialog2-content"><p>'+soy.$$escapeHtml("Are you sure you want to delete this shortcut?")+'</p></div><footer class="aui-dialog2-footer"><div class="aui-dialog2-footer-actions"><button class="aui-button aui-button-primary project-shortcuts-submit">'+soy.$$escapeHtml("Delete")+'</button><button class="aui-button aui-button-link project-shortcuts-cancel aui-button-subtle">'+soy.$$escapeHtml("Cancel")+"</button></div></footer></section>"};;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/dialogs/Add.js' */
define("jira/projects/sidebar/projectShortcuts/dialogs/add",["underscore","jquery","jira/projects/libs/marionette","aui/flag"],function(e,t,i,o){return i.Controller.extend({initialize:function(t){e.bindAll(this,"hide","refresh","focusForm");var i=this;this.analyticsSave=!1,this.sidebarItem=t.sidebarItem,this.projectKey=t.projectKey,this.collection=t.collection,this.model=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut(null,{projectKey:this.projectKey}),this.errorModel=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors(null,{model:this.model}),this.view=new JIRA.Projects.Sidebar.ProjectShortcuts.Views.AddDialogContent({model:this.model,errorModel:this.errorModel}),this.view.render(),this.dialog=AJS.dialog2(i.view.$el),this.dialog.show(),this.view.ui.url.focus(),this.dialog.on("hide",function(){i.trigger("dialog:close",i.analyticsSave)}),this.listenTo(this.view,"render",this.refresh),this.listenTo(this.view,"cancel",this.hideAndRender),this.listenTo(this.model,"save:success",function(){var e=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut(this.model.toJSON(),{projectKey:this.projectKey});this.model.clear(),this.collection.add(e),this._addToADG3Sidebar(e),o({type:"success",title:"You have added the shortcut",body:"Nicely done! Your team is going to love this.",close:"auto"}),this.analyticsSave=!0,this.hide()})},_addToADG3Sidebar:function(e){JIRA.API.getSidebar().done(function(t){var i="sidebar-project-shortcuts",o="com.atlassian.jira.jira-projects-plugin:project.shortcut.default.link."+e.id,r={id:o,name:e.get("name"),url:e.get("url"),icon:"shortcut",canEdit:!0};t.addItem(i,r,!0)})},show:function(){this.dialog.show()},hide:function(){this.view.hideIconPicker(),this.dialog.hide()},refresh:function(){this.view.hideIconPicker()},hideAndRender:function(){this.hide()},focusForm:function(){this.view.ui.url.focus()}})}),AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Add",null,require("jira/projects/sidebar/projectShortcuts/dialogs/add"));;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/services/AvailableIcons.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons");var t=[],n={},e=!1;JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons={initialize:function(e){t=e||t,n={},_.each(e,function(t){n[t.name]=t})},getIconsList:function(){return t},getIconsMap:function(){return n},getAllIconsClasses:function(){return _.reduce(t,function(t,n){return t+n.className+" "},"")},getIconFromName:function(t){return this.getIconsMap()[t]?this.getIconsMap()[t]:this.getIconsList()[0]?this.getIconsList()[0]:{}},setWithIcons:function(t){e=t},isWithIcons:function(){return e}}}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/entities/Shortcut.js' */
!function(){"use strict";function t(t){var e;try{e=JSON.parse(t.responseText)}catch(t){e={message:"We couldn\'t complete the action as there seems to be a communication issue."}}return e}AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut"),JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut=Backbone.Model.extend({defaults:{url:"",name:"",icon:"",type:""},initialize:function(t,e){if(!e||!e.projectKey)throw"Project key is required";this.projectKey=e.projectKey},urlRoot:function(){return AJS.contextPath()+"/rest/projects/1.0/project/"+encodeURIComponent(this.projectKey)+"/shortcut"},clear:function(){this.unset("id"),this.set("url",this.defaults.url),this.set("name",this.defaults.name),this.set("icon",this.defaults.icon),this.set("type",this.defaults.type)},save:function(){if(1!=this.saving){this.saving=!0;var e=this;e.trigger("save:start");var s=this.isNew()?"create":"update";this.sync(s,e).always(function(){e.saving=!1,e.trigger("save:finish")}).done(function(t){e.set(t,{silent:!0}),JIRA.trace("jira.projects.shortcuts."+s+".success"),e.trigger("save:success")}).fail(function(r){var i=t(r);JIRA.trace("jira.projects.shortcuts."+s+".fail"),e.trigger("save:failure",i)})}},destroy:function(){if(1!=this.saving){this.saving=!0;var e=this;e.trigger("remove:start");var s=Backbone.Model.prototype.destroy.apply(this,arguments);return s.always(function(){e.saving=!1,e.trigger("remove:finish")}).done(function(){e.trigger("remove:success")}).fail(function(s){var r=t(s);e.trigger("remove:failure",r)}),s}}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/entities/ShortcutErrors.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors"),JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors=Backbone.Model.extend({defaults:{urlError:"",nameError:"",iconError:"",generalError:""},initialize:function(r,e){var s=e.model;this.listenTo(s,"save:failure remove:failure",function(r){this.set({urlError:r.errors&&r.errors.url,nameError:r.errors&&r.errors.name,iconError:r.errors&&r.errors.icon,generalError:r.message||r.errorMessages&&r.errorMessages.length>0?r.message||r.errorMessages[0]:void 0})}),this.listenTo(s,"save:success remove:success",this.clear)}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/entities/Shortcuts.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcuts"),JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcuts=Backbone.Collection.extend({model:JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut,initialize:function(t,e){this.projectKey=e.projectKey}})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/IconPickerContent.js' */
!function(i){"use strict";function c(i,c){var e,o=5,n=i.ui.iconList.find(".active"),s=i.ui.iconList.find("li").size();switch(c.keyCode){case AJS.keyCode.LEFT:e=-1;break;case AJS.keyCode.RIGHT:e=1;break;case AJS.keyCode.DOWN:e=o;break;case AJS.keyCode.UP:e=-o;break;default:e=0}var a=n.closest("li").index()+e;(a<0||a>=s)&&(a+=s,a%=s),n.removeClass(t),i.ui.icon.eq(a).addClass(t)}var e="projectShortcutsIconsId",t="active aui-dropdown2-active";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.IconPickerContent"),JIRA.Projects.Sidebar.ProjectShortcuts.Views.IconPickerContent=JIRA.Projects.Libs.Marionette.ItemView.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.iconsPicker,ui:{icon:".project-shortcuts-icons-icon",iconList:".project-shortcuts-icons-list",iconPicker:".project-shortcuts-icons-picker"},modelEvents:{"change:icon":function(){var i=this._modelIcon(),c=this.ui.iconPicker.children();c.removeClass(this.iconFactory.getAllIconsClasses()),c.addClass(i.className),this.ui.iconPicker.data(e,i.name)},"save:start":function(){this.ui.iconPicker.attr("aria-disabled",!0)},"save:finish":function(){this.ui.iconPicker.attr("aria-disabled",!1)}},events:{"keydown @ui.iconPicker":function(i){if(this.isPickerActive())switch(i.keyCode){case AJS.keyCode.LEFT:case AJS.keyCode.RIGHT:case AJS.keyCode.DOWN:case AJS.keyCode.UP:c(this,i),i.stopPropagation(),i.preventDefault(),this.ui.iconList.trigger("aui-dropdown2-item-selected");break;case AJS.keyCode.ESCAPE:this.hideIconPicker(),i.stopPropagation(),i.preventDefault()}}},initialize:function(i){this.iconFactory=JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons,this.analytics=JIRA.Projects.Sidebar.ProjectShortcuts.Analytics},onRender:function(){var c=this;this.ui.icon.on("click",function(){var t=i(this).data(e);c.analytics.iconChangeConfirmed(c.model,t),c.analyticsOldIconId="",c.analyticsIconClicked=!0,c.model.set("icon",t),c.ui.iconPicker.focus()}),this.ui.iconList.on("aui-dropdown2-show",function(){c.ui.iconPicker.focus(),c.analyticsIconClicked=!1,c.analytics.iconPickerOpened(c.model)}),this.ui.iconList.on("aui-dropdown2-hide",function(){c.analytics.iconPickerClosed(c.model,c.analyticsIconClicked)}),this.analyticsOldIconId="",this.ui.iconList.on("aui-dropdown2-item-selected",function(i){var t=AJS.$(this).find(".active").data(e);c.analyticsOldIconId&&c.analyticsOldIconId!==t&&c.analytics.iconChanged(c.model,t,c.analyticsOldIconId),c.analyticsOldIconId=t}),this.ui.iconPicker.data(e,this.model.get("icon"))},hideIconPicker:function(){this.isPickerActive()&&this.ui.iconPicker.trigger("aui-button-invoke")},isPickerActive:function(){return this.ui.iconPicker.hasClass("active")},_modelIcon:function(){return this.iconFactory.getIconFromName(this.model.get("icon"))},onFormSubmit:function(){this.model.set("icon",this.ui.iconPicker.data(e)||"")},focus:function(){this.ui.iconPicker.focus()},serializeData:function(){return{iconsList:this.iconFactory.getIconsList(),icon:this._modelIcon(),cid:this.cid}}})}(AJS.$);;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/DialogContent.js' */
!function(t){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent"),JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent=JIRA.Projects.Libs.Marionette.LayoutView.extend({ui:{form:"form",inputs:"input, button",submit:".project-shortcuts-submit",cancel:".project-shortcuts-cancel",url:".project-shortcuts-url input",name:".project-shortcuts-name input"},regions:{iconPicker:".project-shortcuts-icon-picker-block"},events:{"click @ui.cancel":function(t){t.preventDefault(),this.model.clear(),this.setNameAutomagically=!0,this.errorModel.clear(),this.trigger("cancel")},"click @ui.submit":"formSubmit","submit @ui.form":"formSubmit","blur @ui.url":function(){this.ensureProtocolPrefix(),this.tryToAutomagicallyDeriveNameFromUrl()},"input @ui.url":function(){this.model.set("url",this.ui.url.val()),this.tryToAutomagicallyDeriveNameFromUrl()},"input @ui.name":function(){this.setNameAutomagically=!1,this.model.set("name",this.ui.name.val())},"keydown @ui.name":function(t){this.iconPickerContent&&t.shiftKey&&t.keyCode===AJS.keyCode.TAB&&(t.preventDefault(),this.iconPickerContent.focus())},"keydown @ui.url":function(t){this.iconPickerContent&&(t.shiftKey||t.keyCode!==AJS.keyCode.TAB||(t.preventDefault(),this.iconPickerContent.focus()))}},modelEvents:{"save:start":function(){this.ui.inputs.prop("disabled",!0),this.ui.submit.addClass("loading"),this.ui.submit.spin({className:"spinner"})},"save:finish":function(){this.ui.inputs.prop("disabled",!1),this.ui.submit.removeClass("loading"),this.ui.submit.spinStop({className:"spinner"})},"save:failure":function(){if(this.render(),this.errorModel.get("generalError")){var t=require("aui/flag");t({type:"error",title:"We couldn\'t save the shortcut for you",close:"auto",body:this.errorModel.get("generalError")})}return this.errorModel.get("nameError")&&this.ui.name.focus(),this.errorModel.get("urlError")&&this.ui.url.focus(),this},"save:success":function(){this.setNameAutomagically=!0}},initialize:function(t){this.errorModel=t.errorModel;var e=this.model.get("name");this.setNameAutomagically=0==e.length,this.iconFactory=JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons},serializeData:function(){return _.extend(this.model.toJSON(),{errors:this.errorModel.toJSON(),action:this.action,isWithIcon:this.iconFactory.isWithIcons()})},onRender:function(){this.iconFactory.isWithIcons()?(this.iconPickerContent=new JIRA.Projects.Sidebar.ProjectShortcuts.Views.IconPickerContent({model:this.model,action:this.action,observable:this}),this.getRegion("iconPicker").show(this.iconPickerContent)):delete this.iconPickerContent},hideIconPicker:function(){this.iconPickerContent&&this.iconPickerContent.hideIconPicker()},setName:function(t){this.ui.name.val(t),this.model.set("name",t)},setUrl:function(t){this.ui.url.val(t),this.model.set("url",t)},ensureProtocolPrefix:function(){var t=this.ui.url.val().trim();t.length>0&&!JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent.urlPattern.test(t)&&this.setUrl("http://"+t)},tryToAutomagicallyDeriveNameFromUrl:function(){var t=this.ui.url.val().trim();if(this.setNameAutomagically)if(JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent.urlOptionalProtocolPattern.test(t)){var e=JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent.urlOptionalProtocolPattern.exec(t);this.setName(e[3])}else this.setName(t)},formSubmit:function(t){t.preventDefault(),this.ensureProtocolPrefix(),this.tryToAutomagicallyDeriveNameFromUrl(),this.iconPickerContent&&this.iconPickerContent.onFormSubmit(),this.model.set({url:this.ui.url.val(),name:this.ui.name.val()}),this.model.save()}},{urlPattern:/^[a-zA-Z0-9]+:(\/\/)?([^\/]*).*/,urlOptionalProtocolPattern:/^([a-zA-Z0-9]+:(\/\/)?)?([^\/]*).*/})}(AJS.$);;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/AddDialogContent.js' */
!function(){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.AddDialogContent"),JIRA.Projects.Sidebar.ProjectShortcuts.Views.AddDialogContent=JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.addDialog})}();;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/EditDialogContent.js' */
define("jira/projects/sidebar/project-shortcuts/views/edit-dialog-content",["underscore"],function(e){"use strict";var t=JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent,r=t.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.editDialog});return r.extend({ui:e.extend({},t.prototype.ui,{delete:".project-shortcuts-delete"})})}),AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.EditDialogContent",null,require("jira/projects/sidebar/project-shortcuts/views/edit-dialog-content"));;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/dialogs/Edit.js' */
define("jira/projects/sidebar/project-shortcuts/dialogs/edit",["jquery","jira/projects/sidebar/project-shortcuts/views/edit-dialog-content","jira/projects/libs/marionette","aui/flag","jira/api/projects"],function(e,t,o,i,s){"use strict";return o.Controller.extend({initialize:function(o){var r=this;_.bindAll(this,"hide"),this.model=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut(o.model.toJSON(),{projectKey:o.model.projectKey||o.model.collection.projectKey}),this.errorModel=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors((void 0),{model:this.model}),this.view=new t({model:this.model,errorModel:this.errorModel}),this.analyticsSave=!1,this.view.render();var c=e(JIRA.Projects.Sidebar.ProjectShortcuts.Templates.editDialogChrome({}));this.view.$el.appendTo(c),this.dialog=AJS.dialog2(c),this.dialog.show(),this.view.ui.url.focus();var d=s.getCurrentProjectType(),l=s.getCurrentProjectId();this.view.ui.delete.on("click",function(e){r.hide(),e.preventDefault(),AJS.trigger("analyticsEvent",{name:"jira.projects.shortcut.delete.dialog.opened",data:{isSave:!1,shortcutId:r.model.get("id"),projectId:l,projectType:d}});var t=new JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete({model:r.model});r.listenToOnce(t,"dialog:close",function(e){AJS.trigger("analyticsEvent",{name:"jira.projects.shortcut.delete.dialog.closed",data:{isSave:e,shortcutId:r.model.get("id"),projectId:l,projectType:d}})})}),this.listenTo(this.model,"remove:success",function(){o.model.collection&&o.model.collection.remove(r.model),i({type:"success",body:"Shortcut deleted.",close:"auto"})}),this._onResizeWindow=function(){r.hideIconPicker()},e(window).on("resize",this._onResizeWindow),this.listenTo(this.view,"cancel",this.hide),this.listenTo(this.model,"save:success",function(){i({type:"success",body:"You have updated the shortcut.",close:"auto"}),this.analyticsSave=!0,this.hide(),o.model.set(r.model.toJSON())}),this.dialog.on("hide",function(){r.trigger("dialog:close",r.analyticsSave)})},hideIconPicker:function(){this.view.hideIconPicker()},hide:function(){this.dialog.hide(),e(window).off("resize",this._onResizeWindow)}})}),AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Edit",null,require("jira/projects/sidebar/project-shortcuts/dialogs/edit"));;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/Shortcut.js' */
!function(e){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.Shortcut");var o=require("jira/projects/sidebar/project-shortcuts/dialogs/edit");JIRA.Projects.Sidebar.ProjectShortcuts.Views.Shortcut=JIRA.Projects.Libs.Marionette.ItemView.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.shortcut,initialize:function(){_.bindAll(this,"toggleDropdown"),this.iconFactory=JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons},ui:{del:".project-shortcuts-group__actions__delete",edit:".project-shortcuts-group__actions__edit",trigger:".project-shortcuts-group__actions",dropdown:".project-shortcuts-group__dropdown",link:".project-shortcuts-group__link"},modelEvents:{change:"render"},events:{"click @ui.link":function(){this.trigger("click:link",this.model)}},onRender:function(){var t=this;this.unwrapTemplate();var i=e(window),r=e(".aui-sidebar-body");this.ui.trigger.on("click",function(e){t.trigger("dropdown:click",t.model)}),this.ui.edit.on("click",function(e){e.preventDefault(),t.ui.trigger.blur();var i=new o({model:t.model});t.trigger("edit:open",t.model),t.listenToOnce(i,"dialog:close",function(e){t.trigger("edit:close",t.model,e)})}),this.ui.del.on("click",function(e){e.preventDefault(),t.ui.trigger.blur();var o=new JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete({model:t.model});t.trigger("delete:open",t.model),t.listenToOnce(o,"dialog:close",function(e){t.trigger("delete:close",t.model,e)})}),this.ui.dropdown.on({"aui-dropdown2-show":function(){t.$el.addClass("aui-nav-selected"),r.one("scroll",t.toggleDropdown),i.one("scroll",t.toggleDropdown),t.ui.trigger.focus()},"aui-dropdown2-hide":function(){t.$el.removeClass("aui-nav-selected"),r.off("scroll",t.toggleDropdown),i.off("scroll",t.toggleDropdown)}})},serializeData:function(){var e=_.extend(this.model.toJSON(),{canManage:!0,isWithIcon:this.iconFactory.isWithIcons()});return this.iconFactory.isWithIcons()&&(e=_.extend(e,{iconsMap:JIRA.Projects.Sidebar.ProjectShortcuts.Services.AvailableIcons.getIconsMap()})),e},toggleDropdown:function(){this.ui.trigger.trigger("aui-button-invoke")}})}(AJS.$);;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/views/ShortcutsList.js' */
!function(t){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Views.List");var e=require("jira/projects/sidebar/projectShortcuts/dialogs/add");JIRA.Projects.Sidebar.ProjectShortcuts.Views.List=JIRA.Projects.Libs.Marionette.CompositeView.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.content,childView:JIRA.Projects.Sidebar.ProjectShortcuts.Views.Shortcut,ui:{itemsContainer:".aui-nav",description:".project-shortcuts-group__description",add:".project-shortcuts-group__add"},collectionEvents:{"add remove":function(){(0==this.collection.length&&0!=this.lastCollectionLength||0!=this.collection.length&&0==this.lastCollectionLength)&&(this.lastCollectionLength=this.collection.length,this.ui.description.toggleClass("hidden",this.collection.length>0),this.$el.toggleClass("project-shortcuts-group_empty",0==this.collection.length))}},initialize:function(){var e=this;JIRA.API.getSidebar().done(function(o){o.on("expand-end",function(){t(".aui-sidebar-submenu-dialog .project-shortcuts-group__dropdown").remove()},!0),o.on("collapse-start",function(){e.$(".project-shortcuts-group__actions.aui-dropdown2-active").trigger("aui-button-invoke")},!0)}),this.lastCollectionLength=this.collection.length},attachElContent:function(e){var o=new JIRA.Projects.Sidebar.Component.NavigationGroup({el:e});return JIRA.API.Sidebar.replaceGroup(this.options.targetGroup,o),this.$el=t(o.getElement()),this},onRender:function(){var t=new e({sidebarItem:JIRA.API.Sidebar.getGroup("project-shortcuts-group",!0).getItem("project-shortcut-add",!0),projectKey:this.collection.projectKey,collection:this.collection});this.listenTo(t,"dialog:open",function(){this.trigger("add:open")}),this.listenTo(t,"dialog:close",function(t){this.trigger("add:close",t)})},serializeData:function(){return{canManage:!0,numberOfShortcuts:this.collection.length}},attachBuffer:function(t,e){this.ui.itemsContainer.prepend(e)},onAddChild:function(t){this.ui.add.parent().before(t.$el)}})}(AJS.$);;
;
/* module-key = 'com.atlassian.jira.jira-projects-plugin:sidebar-project-shortcuts', location = 'jira-projects-module/sidebar/project-shortcuts/dialogs/Delete.js' */
!function(e){"use strict";AJS.namespace("JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete"),JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete=JIRA.Projects.Libs.Marionette.ItemView.extend({template:JIRA.Projects.Sidebar.ProjectShortcuts.Templates.deleteDialog,ui:{inputs:"input, button",submit:".project-shortcuts-submit",cancel:".project-shortcuts-cancel"},events:{"click @ui.cancel":function(e){e.preventDefault(),this.trigger("dialog:close",!1),this.dialog.hide()},"click @ui.submit":function(e){e.preventDefault(),this.trigger("dialog:close",!0),this.model.destroy({wait:!0})}},modelEvents:{"remove:start":function(){this.ui.inputs.prop("disabled",!0),this.ui.submit.addClass("loading"),this.ui.submit.spin({className:"spinner"})},"remove:finish":function(){this.ui.inputs.prop("disabled",!1),this.ui.submit.removeClass("loading"),this.ui.submit.spinStop({className:"spinner"}),this.dialog.hide(),JIRA.trace("jira.projects.shortcuts.deleted")},"remove:failure":function(e){if(e.message||e.errorMessages&&e.errorMessages.length>0){var t=require("aui/flag");t({type:"error",title:"We couldn\'t delete the shortcut for you",close:"auto",body:e.message||e.errorMessages[0]})}}},initialize:function(){this.render(),this.$el.appendTo("body"),this.dialog=AJS.dialog2(this.$el),this.dialog.show();var e=this;this.dialog.on("hide",function(){_.defer(function(){e.destroy()})})},onRender:function(){this.unwrapTemplate()}})}(AJS.$);;
;
/* module-key = 'com.atlassian.plugin.jslibs:bluebird-2.3.6', location = 'atlassian-jslibs/libs/bluebird/js/browser/bluebird.js' */
!function(t){define("atlassian/libs/bluebird-2.3.6",function(){var e={};return t(e),"undefined"!=typeof exports?module.exports.noConflict():e.Promise.noConflict()})}(function(t){/**
 * @preserve The MIT License (MIT)
 *
 * Copyright (c) 2014 Petka Antonov
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:</p>
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */
!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var r;"undefined"!=typeof t?r=t:"undefined"!=typeof global?r=global:"undefined"!=typeof self&&(r=self),r.Promise=e()}}(function(){var t,e,r;return function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var c="function"==typeof require&&require;if(!a&&c)return c(s,!0);if(o)return o(s,!0);throw new Error("Cannot find module '"+s+"'")}var u=r[s]={exports:{}};e[s][0].call(u.exports,function(t){var r=e[s][1][t];return n(r?r:t)},u,u.exports,t,e,r,i)}return r[s].exports}for(var o="function"==typeof require&&require,s=0;s<i.length;s++)n(i[s]);return n}({1:[function(t,e,r){"use strict";e.exports=function(t){function e(t){var e=new r(t),i=e.promise();return i.isRejected()?i:(e.setHowMany(1),e.setUnwrap(),e.init(),i)}var r=t._SomePromiseArray;t.any=function(t){return e(t)},t.prototype.any=function(){return e(this)}}},{}],2:[function(t,e,r){"use strict";function i(){this._isTickUsed=!1,this._schedule=n,this._length=0,this._lateBuffer=new o(16),this._functionBuffer=new o(65536);var t=this;this.consumeFunctionBuffer=function(){t._consumeFunctionBuffer()}}var n=t("./schedule.js"),o=t("./queue.js"),s=t("./util.js").errorObj,a=t("./util.js").tryCatch1,c="undefined"!=typeof process?process:void 0;i.prototype.haveItemsQueued=function(){return this._length>0},i.prototype.invokeLater=function(t,e,r){void 0===c||null==c.domain||t.domain||(t=c.domain.bind(t)),this._lateBuffer.push(t,e,r),this._queueTick()},i.prototype.invoke=function(t,e,r){void 0===c||null==c.domain||t.domain||(t=c.domain.bind(t));var i=this._functionBuffer;i.push(t,e,r),this._length=i.length(),this._queueTick()},i.prototype._consumeFunctionBuffer=function(){for(var t=this._functionBuffer;t.length()>0;){var e=t.shift(),r=t.shift(),i=t.shift();e.call(r,i)}this._reset(),this._consumeLateBuffer()},i.prototype._consumeLateBuffer=function(){for(var t=this._lateBuffer;t.length()>0;){var e=t.shift(),r=t.shift(),i=t.shift(),n=a(e,r,i);if(n===s){if(this._queueTick(),null==e.domain)throw n.e;e.domain.emit("error",n.e)}}},i.prototype._queueTick=function(){this._isTickUsed||(this._schedule(this.consumeFunctionBuffer),this._isTickUsed=!0)},i.prototype._reset=function(){this._isTickUsed=!1,this._length=0},e.exports=new i},{"./queue.js":25,"./schedule.js":28,"./util.js":35}],3:[function(t,e,r){"use strict";var i=t("./promise.js")();e.exports=i},{"./promise.js":20}],4:[function(t,e,r){"use strict";var i=Object.create;if(i){var n=i(null),o=i(null);n[" size"]=o[" size"]=0}e.exports=function(e){function r(t){return new Function("obj","                                             \n        'use strict'                                                         \n        var len = this.length;                                               \n        switch(len) {                                                        \n            case 1: return obj.methodName(this[0]);                          \n            case 2: return obj.methodName(this[0], this[1]);                 \n            case 3: return obj.methodName(this[0], this[1], this[2]);        \n            case 0: return obj.methodName();                                 \n            default: return obj.methodName.apply(obj, this);                 \n        }                                                                    \n        ".replace(/methodName/g,t))}function i(t){return new Function("obj","                                             \n        'use strict';                                                        \n        return obj.propertyName;                                             \n        ".replace("propertyName",t))}function s(t,e,r){var i=r[t];if("function"!=typeof i){if(!_(t))return null;if(i=e(t),r[t]=i,r[" size"]++,r[" size"]>512){for(var n=Object.keys(r),o=0;o<256;++o)delete r[n[o]];r[" size"]=n.length-256}}return i}function a(t){return s(t,r,n)}function c(t){return s(t,i,o)}function u(t){return t[this.pop()].apply(t,this)}function l(t){return t[this]}function h(t){return t[this]}var f=t("./util.js"),p=f.canEvaluate,_=f.isIdentifier;e.prototype.call=function(t){for(var e=arguments.length,r=new Array(e-1),i=1;i<e;++i)r[i-1]=arguments[i];if(p){var n=a(t);if(null!==n)return this._then(n,void 0,void 0,r,void 0)}return r.push(t),this._then(u,void 0,void 0,r,void 0)},e.prototype.get=function(t){var e,r="number"==typeof t;if(r)e=h;else if(p){var i=c(t);e=null!==i?i:l}else e=l;return this._then(e,void 0,void 0,t,void 0)}}},{"./util.js":35}],5:[function(t,e,r){"use strict";e.exports=function(e,r){var i=t("./errors.js"),n=i.canAttach,o=t("./async.js"),s=i.CancellationError;e.prototype._cancel=function(t){if(!this.isCancellable())return this;for(var e,r=this;void 0!==(e=r._cancellationParent)&&e.isCancellable();)r=e;r._attachExtraTrace(t),r._rejectUnchecked(t)},e.prototype.cancel=function(t){return this.isCancellable()?(t=void 0!==t?n(t)?t:new Error(t+""):new s,o.invokeLater(this._cancel,this,t),this):this},e.prototype.cancellable=function(){return this._cancellable()?this:(this._setCancellable(),this._cancellationParent=void 0,this)},e.prototype.uncancellable=function(){var t=new e(r);return t._propagateFrom(this,6),t._follow(this),t._unsetCancellable(),t},e.prototype.fork=function(t,e,r){var i=this._then(t,e,r,void 0,void 0);return i._setCancellable(),i._cancellationParent=void 0,i}}},{"./async.js":2,"./errors.js":10}],6:[function(t,e,r){"use strict";e.exports=function(){function e(t){var e;if("function"==typeof t)e="[function "+(t.name||"anonymous")+"]";else{e=t.toString();var i=/\[object [a-zA-Z0-9$_]+\]/;if(i.test(e))try{var n=JSON.stringify(t);e=n}catch(t){}0===e.length&&(e="(empty array)")}return"(<"+r(e)+">, no stack trace)"}function r(t){var e=41;return t.length<e?t:t.substr(0,e-3)+"..."}function i(t,e){this.captureStackTrace(i,e)}var n=t("./util.js").inherits,o=t("./es5.js").defineProperty,s=new RegExp("\\b(?:[a-zA-Z0-9.]+\\$_\\w+|tryCatch(?:1|2|3|4|Apply)|new \\w*PromiseArray|\\w*PromiseArray\\.\\w*PromiseArray|setTimeout|CatchFilter\\$_\\w+|makeNodePromisified|processImmediate|process._tickCallback|nextTick|Async\\$\\w+)\\b"),a=null,c=null;n(i,Error),i.prototype.captureStackTrace=function(t,e){u(this,t,e)},i.possiblyUnhandledRejection=function(t){if("object"==typeof console){var e;if("object"==typeof t||"function"==typeof t){var r=t.stack;e="Possibly unhandled "+c(r,t)}else e="Possibly unhandled "+String(t);"function"==typeof console.error||"object"==typeof console.error?console.error(e):"function"!=typeof console.log&&"object"!=typeof console.log||console.log(e)}},i.combine=function(t,e){for(var r=t.length-1,i=e.length-1;i>=0;--i){var n=e[i];if(t[r]!==n)break;t.pop(),r--}t.push("From previous event:");for(var o=t.concat(e),c=[],i=0,u=o.length;i<u;++i)s.test(o[i])&&a.test(o[i])||i>0&&!a.test(o[i])&&"From previous event:"!==o[i]||c.push(o[i]);return c},i.protectErrorMessageNewlines=function(t){for(var e=0;e<t.length&&!a.test(t[e]);++e);if(!(e<=1)){for(var r=[],i=0;i<e;++i)r.push(t.shift());t.unshift(r.join("\0"))}},i.isSupported=function(){return"function"==typeof u};var u=function t(){if("number"==typeof Error.stackTraceLimit&&"function"==typeof Error.captureStackTrace){a=/^\s*at\s*/,c=function(t,r){return"string"==typeof t?t:void 0!==r.name&&void 0!==r.message?r.name+". "+r.message:e(r)};var r=Error.captureStackTrace;return function(t,e){r(t,e)}}var i=new Error;if("string"==typeof i.stack&&"function"==typeof"".startsWith&&i.stack.startsWith("stackDetection@")&&"stackDetection"===t.name){o(Error,"stackTraceLimit",{writable:!0,enumerable:!1,configurable:!1,value:25}),a=/@/;var n=/[@\n]/;return c=function(t,r){return"string"==typeof t?r.name+". "+r.message+"\n"+t:void 0!==r.name&&void 0!==r.message?r.name+". "+r.message:e(r)},function(t){for(var e=(new Error).stack,r=e.split(n),i=r.length,o="",s=0;s<i;s+=2)o+=r[s],o+="@",o+=r[s+1],o+="\n";t.stack=o}}return c=function(t,r){return"string"==typeof t?t:"object"!=typeof r&&"function"!=typeof r||void 0===r.name||void 0===r.message?e(r):r.name+". "+r.message},null}();return i}},{"./es5.js":12,"./util.js":35}],7:[function(t,e,r){"use strict";e.exports=function(e){function r(t,e,r){this._instances=t,this._callback=e,this._promise=r}function i(t,e){var r={},i=s(t,r,e);if(i===a)return i;var n=c(r);return n.length?(a.e=new u("Catch filter must inherit from Error or be a simple predicate function"),a):i}var n=t("./util.js"),o=t("./errors.js"),s=n.tryCatch1,a=n.errorObj,c=t("./es5.js").keys,u=o.TypeError;return r.prototype.doFilter=function(t){for(var r=this._callback,n=this._promise,c=n._boundTo,u=0,l=this._instances.length;u<l;++u){var h=this._instances[u],f=h===Error||null!=h&&h.prototype instanceof Error;if(f&&t instanceof h){var p=s(r,c,t);return p===a?(e.e=p.e,e):p}if("function"==typeof h&&!f){var _=i(h,t);if(_===a){var d=o.canAttach(a.e)?a.e:new Error(a.e+"");this._promise._attachExtraTrace(d),t=a.e;break}if(_){var p=s(r,c,t);return p===a?(e.e=p.e,e):p}}}return e.e=t,e},r}},{"./errors.js":10,"./es5.js":12,"./util.js":35}],8:[function(t,e,r){"use strict";var i=t("./util.js"),n=i.isPrimitive,o=i.wrapsPrimitiveReceiver;e.exports=function(t){var e=function(){return this},r=function(){throw this},i=function(t,e){return 1===e?function(){throw t}:2===e?function(){return t}:void 0};t.prototype.return=t.prototype.thenReturn=function(t){return o&&n(t)?this._then(i(t,2),void 0,void 0,void 0,void 0):this._then(e,void 0,void 0,t,void 0)},t.prototype.throw=t.prototype.thenThrow=function(t){return o&&n(t)?this._then(i(t,1),void 0,void 0,void 0,void 0):this._then(r,void 0,void 0,t,void 0)}}},{"./util.js":35}],9:[function(t,e,r){"use strict";e.exports=function(t,e){var r=t.reduce;t.prototype.each=function(t){return r(this,t,null,e)},t.each=function(t,i){return r(t,i,null,e)}}},{}],10:[function(t,e,r){"use strict";function i(t){try{_(t,"isOperational",!0)}catch(t){}}function n(t){return null!=t&&(t instanceof c||t.isOperational===!0)}function o(t){return t instanceof Error}function s(t){return o(t)}function a(t,e){function r(i){return this instanceof r?(this.message="string"==typeof i?i:e,this.name=t,void(Error.captureStackTrace&&Error.captureStackTrace(this,this.constructor))):new r(i)}return p(r,Error),r}function c(t){this.name="OperationalError",this.message=t,this.cause=t,this.isOperational=!0,t instanceof Error?(this.message=t.message,this.stack=t.stack):Error.captureStackTrace&&Error.captureStackTrace(this,this.constructor)}var u,l,h=t("./es5.js").freeze,f=t("./util.js"),p=f.inherits,_=f.notEnumerableProp,d=a("CancellationError","cancellation error"),v=a("TimeoutError","timeout error"),y=a("AggregateError","aggregate error");try{u=TypeError,l=RangeError}catch(t){u=a("TypeError","type error"),l=a("RangeError","range error")}for(var m="join pop push shift unshift slice filter forEach some every map indexOf lastIndexOf reduce reduceRight sort reverse".split(" "),g=0;g<m.length;++g)"function"==typeof Array.prototype[m[g]]&&(y.prototype[m[g]]=Array.prototype[m[g]]);y.prototype.length=0,y.prototype.isOperational=!0;var j=0;y.prototype.toString=function(){var t=Array(4*j+1).join(" "),e="\n"+t+"AggregateError of:\n";j++,t=Array(4*j+1).join(" ");for(var r=0;r<this.length;++r){for(var i=this[r]===this?"[Circular AggregateError]":this[r]+"",n=i.split("\n"),o=0;o<n.length;++o)n[o]=t+n[o];i=n.join("\n"),e+=i+"\n"}return j--,e},p(c,Error);var b="__BluebirdErrorTypes__",w=Error[b];w||(w=h({CancellationError:d,TimeoutError:v,OperationalError:c,RejectionError:c,AggregateError:y}),_(Error,b,w)),e.exports={Error:Error,TypeError:u,RangeError:l,CancellationError:w.CancellationError,OperationalError:w.OperationalError,TimeoutError:w.TimeoutError,AggregateError:w.AggregateError,originatesFromRejection:n,markAsOriginatingFromRejection:i,canAttach:s}},{"./es5.js":12,"./util.js":35}],11:[function(t,e,r){"use strict";e.exports=function(e){function r(t){var r=new i(t),n=e.rejected(r),o=n._peekContext();return null!=o&&o._attachExtraTrace(r),n}var i=t("./errors.js").TypeError;return r}},{"./errors.js":10}],12:[function(t,e,r){var i=function(){"use strict";return void 0===this}();if(i)e.exports={freeze:Object.freeze,defineProperty:Object.defineProperty,keys:Object.keys,getPrototypeOf:Object.getPrototypeOf,isArray:Array.isArray,isES5:i};else{var n={}.hasOwnProperty,o={}.toString,s={}.constructor.prototype,a=function(t){var e=[];for(var r in t)n.call(t,r)&&e.push(r);return e},c=function(t,e,r){return t[e]=r.value,t},u=function(t){return t},l=function(t){try{return Object(t).constructor.prototype}catch(t){return s}},h=function(t){try{return"[object Array]"===o.call(t)}catch(t){return!1}};e.exports={isArray:h,keys:a,defineProperty:c,freeze:u,getPrototypeOf:l,isES5:i}}},{}],13:[function(t,e,r){"use strict";e.exports=function(t,e){var r=t.map;t.prototype.filter=function(t,i){return r(this,t,i,e)},t.filter=function(t,i,n){return r(t,i,n,e)}}},{}],14:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(){return this}function o(){throw this}function s(t){return function(){return t}}function a(t){return function(){throw t}}function c(t,e,r){var i;return i=f&&p(e)?r?s(e):a(e):r?n:o,t._then(i,_,void 0,e,void 0)}function u(t){var n=this.promise,o=this.handler,s=n._isBound()?o.call(n._boundTo):o();if(void 0!==s){var a=i(s,void 0);if(a instanceof e)return c(a,t,n.isFulfilled())}return n.isRejected()?(r.e=t,r):t}function l(t){var r=this.promise,n=this.handler,o=r._isBound()?n.call(r._boundTo,t):n(t);if(void 0!==o){var s=i(o,void 0);if(s instanceof e)return c(s,t,!0)}return t}var h=t("./util.js"),f=h.wrapsPrimitiveReceiver,p=h.isPrimitive,_=h.thrower;e.prototype._passThroughHandler=function(t,e){if("function"!=typeof t)return this.then();var r={promise:this,handler:t};return this._then(e?u:l,e?u:void 0,void 0,r,void 0)},e.prototype.lastly=e.prototype.finally=function(t){return this._passThroughHandler(t,!0)},e.prototype.tap=function(t){return this._passThroughHandler(t,!1)}}},{"./util.js":35}],15:[function(t,e,r){"use strict";e.exports=function(e,r,i,n){function o(t,r){for(var i=h,s=e,a=r.length,c=0;c<a;++c){var u=f(r[c],void 0,t);if(u===i)return s.reject(i.e);var l=n(u,o);if(l instanceof s)return l}return null}function s(t,r,n){var o=this._promise=new e(i);o._setTrace(void 0),this._generatorFunction=t,this._receiver=r,this._generator=void 0,this._yieldHandlers="function"==typeof n?[n].concat(p):p}var a=t("./errors.js"),c=a.TypeError,u=t("./util.js").deprecated,l=t("./util.js"),h=l.errorObj,f=l.tryCatch1,p=[];s.prototype.promise=function(){return this._promise},s.prototype._run=function(){this._generator=this._generatorFunction.call(this._receiver),this._receiver=this._generatorFunction=void 0,this._next(void 0)},s.prototype._continue=function(t){if(t===h){this._generator=void 0;var r=a.canAttach(t.e)?t.e:new Error(t.e+"");return this._promise._attachExtraTrace(r),void this._promise._reject(t.e,r)}var i=t.value;if(t.done===!0)this._generator=void 0,this._promise._tryFollow(i)||this._promise._fulfill(i);else{var s=n(i,void 0);if(!(s instanceof e)&&(s=o(s,this._yieldHandlers),null===s))return void this._throw(new c("A value was yielded that could not be treated as a promise"));s._then(this._next,this._throw,void 0,this,null)}},s.prototype._throw=function(t){a.canAttach(t)&&this._promise._attachExtraTrace(t),this._continue(f(this._generator.throw,this._generator,t))},s.prototype._next=function(t){this._continue(f(this._generator.next,this._generator,t))},e.coroutine=function(t,e){if("function"!=typeof t)throw new c("generatorFunction must be a function");var r=Object(e).yieldHandler,i=s;return function(){var e=t.apply(this,arguments),n=new i((void 0),(void 0),r);return n._generator=e,n._next(void 0),n.promise()}},e.coroutine.addYieldHandler=function(t){if("function"!=typeof t)throw new c("fn must be a function");p.push(t)},e.spawn=function(t){if(u("Promise.spawn is deprecated. Use Promise.coroutine instead."),"function"!=typeof t)return r("generatorFunction must be a function");var i=new s(t,this),n=i.promise();return i._run(e.spawn),n}}},{"./errors.js":10,"./util.js":35}],16:[function(t,e,r){"use strict";e.exports=function(e,r,i,n){var o=t("./util.js"),s=o.canEvaluate,a=o.tryCatch1,c=o.errorObj;if(s){for(var u=function(t){return new Function("value","holder","                             \n            'use strict';                                                    \n            holder.pIndex = value;                                           \n            holder.checkFulfillment(this);                                   \n            ".replace(/Index/g,t))},l=function(t){for(var e=[],r=1;r<=t;++r)e.push("holder.p"+r);return new Function("holder","                                      \n            'use strict';                                                    \n            var callback = holder.fn;                                        \n            return callback(values);                                         \n            ".replace(/values/g,e.join(", ")))},h=[],f=[void 0],p=1;p<=5;++p)h.push(u(p)),f.push(l(p));var _=function(t,e){this.p1=this.p2=this.p3=this.p4=this.p5=null,this.fn=e,this.total=t,this.now=0};_.prototype.callers=f,_.prototype.checkFulfillment=function(t){var e=this.now;e++;var r=this.total;if(e>=r){var i=this.callers[r],n=a(i,void 0,this);n===c?t._rejectUnchecked(n.e):t._tryFollow(n)||t._fulfillUnchecked(n)}else this.now=e}}e.join=function(){var t,o=arguments.length-1;if(o>0&&"function"==typeof arguments[o]&&(t=arguments[o],o<6&&s)){var a=new e(n);a._setTrace(void 0);for(var c=new _(o,t),u=a._reject,l=h,f=0;f<o;++f){var p=i(arguments[f],void 0);p instanceof e?p.isPending()?p._then(l[f],u,void 0,a,c):p.isFulfilled()?l[f].call(a,p._settledValue,c):(a._reject(p._settledValue),p._unsetRejectionIsUnhandled()):l[f].call(a,p,c)}return a}for(var d=arguments.length,v=new Array(d),y=0;y<d;++y)v[y]=arguments[y];var a=new r(v).promise();return void 0!==t?a.spread(t):a}}},{"./util.js":35}],17:[function(t,e,r){"use strict";e.exports=function(e,r,i,n,o){function s(t,e,r,i){this.constructor$(t),this._callback=e,this._preservedValues=i===o?new Array(this.length()):null,this._limit=r,this._inFlight=0,this._queue=r>=1?[]:f,this._init$(void 0,-2)}function a(t,e,r,i){var n="object"==typeof r&&null!==r?r.concurrency:0;return n="number"==typeof n&&isFinite(n)&&n>=1?n:0,new s(t,e,n,i)}var c=t("./util.js"),u=c.tryCatch3,l=c.errorObj,h={},f=[];c.inherits(s,r),s.prototype._init=function(){},s.prototype._promiseFulfilled=function(t,r){var i=this._values;if(null!==i){var o=this.length(),s=this._preservedValues,a=this._limit;if(i[r]===h){if(i[r]=t,a>=1&&(this._inFlight--,this._drainQueue(),this._isResolved()))return}else{if(a>=1&&this._inFlight>=a)return i[r]=t,void this._queue.push(r);null!==s&&(s[r]=t);var c=this._callback,f=this._promise._boundTo,p=u(c,f,t,r,o);if(p===l)return this._reject(p.e);var _=n(p,void 0);if(_ instanceof e){if(_.isPending())return a>=1&&this._inFlight++,i[r]=h,_._proxyPromiseArray(this,r);if(!_.isFulfilled())return _._unsetRejectionIsUnhandled(),this._reject(_.reason());p=_.value()}i[r]=p}var d=++this._totalResolved;d>=o&&(null!==s?this._filter(i,s):this._resolve(i))}},s.prototype._drainQueue=function(){for(var t=this._queue,e=this._limit,r=this._values;t.length>0&&this._inFlight<e;){var i=t.pop();this._promiseFulfilled(r[i],i)}},s.prototype._filter=function(t,e){for(var r=e.length,i=new Array(r),n=0,o=0;o<r;++o)t[o]&&(i[n++]=e[o]);i.length=n,this._resolve(i)},s.prototype.preservedValues=function(){return this._preservedValues},e.prototype.map=function(t,e){return"function"!=typeof t?i("fn must be a function"):a(this,t,e,null).promise()},e.map=function(t,e,r,n){return"function"!=typeof e?i("fn must be a function"):a(t,e,r,n).promise()}}},{"./util.js":35}],18:[function(t,e,r){"use strict";e.exports=function(e){function r(t){throw t}function i(t,e){if(!s.isArray(t))return n(t,e);var i=s.tryCatchApply(this,[null].concat(t),e);i===l&&a.invokeLater(r,void 0,i.e)}function n(t,e){var i=this,n=void 0===t?u(i,e,null):c(i,e,null,t);n===l&&a.invokeLater(r,void 0,n.e)}function o(t,e){var i=this,n=u(i,e,t);n===l&&a.invokeLater(r,void 0,n.e)}var s=t("./util.js"),a=t("./async.js"),c=s.tryCatch2,u=s.tryCatch1,l=s.errorObj;e.prototype.nodeify=function(t,e){if("function"==typeof t){var r=n;void 0!==e&&Object(e).spread&&(r=i),this._then(r,o,void 0,t,this._boundTo)}return this}}},{"./async.js":2,"./util.js":35}],19:[function(t,e,r){"use strict";e.exports=function(e,r){var i=t("./util.js"),n=t("./async.js"),o=t("./errors.js"),s=i.tryCatch1,a=i.errorObj;e.prototype.progressed=function(t){return this._then(void 0,void 0,t,void 0,void 0)},e.prototype._progress=function(t){this._isFollowingOrFulfilledOrRejected()||this._progressUnchecked(t)},e.prototype._clearFirstHandlerData$Base=e.prototype._clearFirstHandlerData,e.prototype._clearFirstHandlerData=function(){this._clearFirstHandlerData$Base(),this._progressHandler0=void 0},e.prototype._progressHandlerAt=function(t){return 0===t?this._progressHandler0:this[(t<<2)+t-5+2]},e.prototype._doProgressWith=function(t){var r=t.value,i=t.handler,n=t.promise,c=t.receiver,u=s(i,c,r);if(u===a){if(null!=u.e&&"StopProgressPropagation"!==u.e.name){var l=o.canAttach(u.e)?u.e:new Error(u.e+"");n._attachExtraTrace(l),n._progress(u.e)}}else u instanceof e?u._then(n._progress,null,null,n,void 0):n._progress(u)},e.prototype._progressUnchecked=function(t){if(this.isPending())for(var i=this._length(),o=this._progress,s=0;s<i;s++){var a=this._progressHandlerAt(s),c=this._promiseAt(s);if(c instanceof e)"function"==typeof a?n.invoke(this._doProgressWith,this,{handler:a,promise:c,receiver:this._receiverAt(s),value:t}):n.invoke(o,c,t);else{var u=this._receiverAt(s);"function"==typeof a?a.call(u,t,c):u instanceof e&&u._isProxied()?u._progressUnchecked(t):u instanceof r&&u._promiseProgressed(t,c)}}}}},{"./async.js":2,"./errors.js":10,"./util.js":35}],20:[function(t,e,r){"use strict";function i(t){try{Promise===t&&(Promise=n)}catch(t){}return t}var n;"undefined"!=typeof Promise&&(n=Promise),e.exports=function(){function e(t){if("function"!=typeof t)throw new w("the promise constructor requires a resolver function");if(this.constructor!==e)throw new w("the promise constructor cannot be invoked directly");this._bitField=0,this._fulfillmentHandler0=void 0,this._rejectionHandler0=void 0,this._promise0=void 0,this._receiver0=void 0,this._settledValue=void 0,this._boundTo=void 0,t!==c&&this._resolveFromResolver(t)}function r(t){return t[0]}function n(){return new e.PromiseInspection(this)}var o=t("./util.js"),s=t("./async.js"),a=t("./errors.js"),c=function(){},u={},l={e:null},h=t("./thenables.js")(e,c),f=t("./promise_array.js")(e,c,h),p=t("./captured_trace.js")(),_=t("./catch_filter.js")(l),d=t("./promise_resolver.js"),v=o.isArray,y=o.errorObj,m=o.tryCatch1,g=o.tryCatch2,j=o.tryCatchApply,b=a.RangeError,w=a.TypeError,F=a.CancellationError,k=a.TimeoutError,E=a.OperationalError,P=a.originatesFromRejection,T=a.markAsOriginatingFromRejection,R=a.canAttach,x=o.thrower,A=t("./errors_api_rejection")(e),C=function(){return new w("circular promise resolution chain")};e.prototype.bind=function(t){var i=h(t,void 0),n=new e(c);if(i instanceof e){var o=i.then(function(t){n._setBoundTo(t)}),s=e.all([this,o]).then(r);n._follow(s)}else n._follow(this),n._setBoundTo(t);return n._propagateFrom(this,3),n},e.prototype.toString=function(){return"[object Promise]"},e.prototype.caught=e.prototype.catch=function(t){var r=arguments.length;if(r>1){var i,n=new Array(r-1),o=0;for(i=0;i<r-1;++i){var s=arguments[i];if("function"!=typeof s){var a=new w("A catch filter must be an error constructor or a filter function");return this._attachExtraTrace(a),e.reject(a)}n[o++]=s}n.length=o,t=arguments[i],this._resetTrace();var c=new _(n,t,this);return this._then(void 0,c.doFilter,void 0,c,void 0)}return this._then(void 0,t,void 0,void 0,void 0)},e.prototype.reflect=function(){return this._then(n,n,void 0,this,void 0)},e.prototype.then=function(t,e,r){return this._then(t,e,r,void 0,void 0)},e.prototype.done=function(t,e,r){var i=this._then(t,e,r,void 0,void 0);i._setIsFinal()},e.prototype.spread=function(t,e){return this._then(t,e,void 0,u,void 0)},e.prototype.isCancellable=function(){return!this.isResolved()&&this._cancellable()},e.prototype.toJSON=function(){var t={isFulfilled:!1,isRejected:!1,fulfillmentValue:void 0,rejectionReason:void 0};return this.isFulfilled()?(t.fulfillmentValue=this._settledValue,t.isFulfilled=!0):this.isRejected()&&(t.rejectionReason=this._settledValue,t.isRejected=!0),t},e.prototype.all=function(){return new f(this).promise()},e.is=function(t){return t instanceof e},e.all=function(t){return new f(t).promise()},e.prototype.error=function(t){return this.caught(P,t)},e.prototype._resolveFromSyncValue=function(t){if(t===y)this._cleanValues(),this._setRejected(),this._settledValue=t.e,this._ensurePossibleRejectionHandled();else{var r=h(t,void 0);r instanceof e?this._follow(r):(this._cleanValues(),this._setFulfilled(),this._settledValue=t)}},e.method=function(t){if("function"!=typeof t)throw new w("fn must be a function");return function(){var r;switch(arguments.length){case 0:r=m(t,this,void 0);break;case 1:r=m(t,this,arguments[0]);break;case 2:r=g(t,this,arguments[0],arguments[1]);break;default:for(var i=arguments.length,n=new Array(i),o=0;o<i;++o)n[o]=arguments[o];r=j(t,n,this)}var s=new e(c);return s._setTrace(void 0),s._resolveFromSyncValue(r),s}},e.attempt=e.try=function(t,r,i){if("function"!=typeof t)return A("fn must be a function");var n=v(r)?j(t,r,i):m(t,i,r),o=new e(c);return o._setTrace(void 0),o._resolveFromSyncValue(n),o},e.defer=e.pending=function(){var t=new e(c);return t._setTrace(void 0),new d(t)},e.bind=function(t){var r=h(t,void 0),i=new e(c);if(i._setTrace(void 0),r instanceof e){var n=r.then(function(t){i._setBoundTo(t)});i._follow(n)}else i._setBoundTo(t),i._setFulfilled();return i},e.cast=function(t){var r=h(t,void 0);if(!(r instanceof e)){var i=r;r=new e(c),r._setTrace(void 0),r._setFulfilled(),r._cleanValues(),r._settledValue=i}return r},e.resolve=e.fulfilled=e.cast,e.reject=e.rejected=function(t){var r=new e(c);if(r._setTrace(void 0),T(t),r._cleanValues(),r._setRejected(),r._settledValue=t,!R(t)){var i=new Error(t+"");r._setCarriedStackTrace(i)}return r._ensurePossibleRejectionHandled(),r},e.onPossiblyUnhandledRejection=function(t){p.possiblyUnhandledRejection="function"==typeof t?t:void 0};var O;e.onUnhandledRejectionHandled=function(t){O="function"==typeof t?t:void 0};var S=!("undefined"==typeof process||"string"!=typeof process.execPath||"object"!=typeof process.env||!process.env.BLUEBIRD_DEBUG&&"development"!==process.env.NODE_ENV);e.longStackTraces=function(){if(s.haveItemsQueued()&&S===!1)throw new Error("cannot enable long stack traces after promises have been created");S=p.isSupported()},e.hasLongStackTraces=function(){return S&&p.isSupported()},e.prototype._then=function(t,r,i,n,o){var a=void 0!==o,u=a?o:new e(c);if(!a){if(S){var l=this._peekContext()===this._traceParent;u._traceParent=l?this._traceParent:this}u._propagateFrom(this,7)}var h=this._addCallbacks(t,r,i,u,n);return this.isResolved()&&s.invoke(this._queueSettleAt,this,h),u},e.prototype._length=function(){return 262143&this._bitField},e.prototype._isFollowingOrFulfilledOrRejected=function(){return(939524096&this._bitField)>0},e.prototype._isFollowing=function(){return 536870912===(536870912&this._bitField)},e.prototype._setLength=function(t){this._bitField=this._bitField&-262144|262143&t},e.prototype._setFulfilled=function(){this._bitField=268435456|this._bitField},e.prototype._setRejected=function(){this._bitField=134217728|this._bitField},e.prototype._setFollowing=function(){this._bitField=536870912|this._bitField},e.prototype._setIsFinal=function(){this._bitField=33554432|this._bitField},e.prototype._isFinal=function(){return(33554432&this._bitField)>0},e.prototype._cancellable=function(){return(67108864&this._bitField)>0},e.prototype._setCancellable=function(){this._bitField=67108864|this._bitField},e.prototype._unsetCancellable=function(){this._bitField=this._bitField&-67108865},e.prototype._setRejectionIsUnhandled=function(){this._bitField=2097152|this._bitField},e.prototype._unsetRejectionIsUnhandled=function(){this._bitField=this._bitField&-2097153,this._isUnhandledRejectionNotified()&&(this._unsetUnhandledRejectionIsNotified(),this._notifyUnhandledRejectionIsHandled())},e.prototype._isRejectionUnhandled=function(){return(2097152&this._bitField)>0},e.prototype._setUnhandledRejectionIsNotified=function(){this._bitField=524288|this._bitField},e.prototype._unsetUnhandledRejectionIsNotified=function(){this._bitField=this._bitField&-524289},e.prototype._isUnhandledRejectionNotified=function(){return(524288&this._bitField)>0},e.prototype._setCarriedStackTrace=function(t){this._bitField=1048576|this._bitField,this._fulfillmentHandler0=t},e.prototype._unsetCarriedStackTrace=function(){this._bitField=this._bitField&-1048577,this._fulfillmentHandler0=void 0},e.prototype._isCarryingStackTrace=function(){return(1048576&this._bitField)>0},e.prototype._getCarriedStackTrace=function(){return this._isCarryingStackTrace()?this._fulfillmentHandler0:void 0},e.prototype._receiverAt=function(t){var e=0===t?this._receiver0:this[(t<<2)+t-5+4];return this._isBound()&&void 0===e?this._boundTo:e},e.prototype._promiseAt=function(t){return 0===t?this._promise0:this[(t<<2)+t-5+3]},e.prototype._fulfillmentHandlerAt=function(t){return 0===t?this._fulfillmentHandler0:this[(t<<2)+t-5+0]},e.prototype._rejectionHandlerAt=function(t){return 0===t?this._rejectionHandler0:this[(t<<2)+t-5+1]},e.prototype._addCallbacks=function(t,e,r,i,n){var o=this._length();if(o>=262138&&(o=0,this._setLength(0)),0===o)this._promise0=i,void 0!==n&&(this._receiver0=n),"function"!=typeof t||this._isCarryingStackTrace()||(this._fulfillmentHandler0=t),"function"==typeof e&&(this._rejectionHandler0=e),"function"==typeof r&&(this._progressHandler0=r);else{var s=(o<<2)+o-5;this[s+3]=i,this[s+4]=n,this[s+0]="function"==typeof t?t:void 0,this[s+1]="function"==typeof e?e:void 0,this[s+2]="function"==typeof r?r:void 0}return this._setLength(o+1),o},e.prototype._setProxyHandlers=function(t,e){var r=this._length();if(r>=262138&&(r=0,this._setLength(0)),0===r)this._promise0=e,this._receiver0=t;else{var i=(r<<2)+r-5;this[i+3]=e,this[i+4]=t,this[i+0]=this[i+1]=this[i+2]=void 0}this._setLength(r+1)},e.prototype._proxyPromiseArray=function(t,e){this._setProxyHandlers(t,e)},e.prototype._proxyPromise=function(t){t._setProxied(),this._setProxyHandlers(t,-15)},e.prototype._setBoundTo=function(t){void 0!==t?(this._bitField=8388608|this._bitField,this._boundTo=t):this._bitField=this._bitField&-8388609},e.prototype._isBound=function(){return 8388608===(8388608&this._bitField)},e.prototype._resolveFromResolver=function(t){function e(t){i._tryFollow(t)||i._fulfill(t)}function r(t){var e=R(t)?t:new Error(t+"");i._attachExtraTrace(e),T(t),i._reject(t,e===t?void 0:e)}var i=this;this._setTrace(void 0),this._pushContext();var n=g(t,void 0,e,r);if(this._popContext(),void 0!==n&&n===y){var o=n.e,s=R(o)?o:new Error(o+"");i._reject(o,s)}},e.prototype._spreadSlowCase=function(t,e,r,i){var n=new f(r).promise(),o=n._then(function(){return t.apply(i,arguments)},void 0,void 0,u,void 0);e._follow(o)},e.prototype._callSpread=function(t,r,i){var n=this._boundTo;if(v(i))for(var o=0,s=i.length;o<s;++o)if(h(i[o],void 0)instanceof e)return void this._spreadSlowCase(t,r,i,n);return r._pushContext(),j(t,i,n)},e.prototype._callHandler=function(t,e,r,i){var n;return e!==u||this.isRejected()?(r._pushContext(),n=m(t,e,i)):n=this._callSpread(t,r,i),r._popContext(),n},e.prototype._settlePromiseFromHandler=function(t,r,i,n){if(!(n instanceof e))return void t.call(r,i,n);var o=this._callHandler(t,r,n,i);if(!n._isFollowing())if(o===y||o===n||o===l){var s=o===n?C():o.e,a=R(s)?s:new Error(s+"");o!==l&&n._attachExtraTrace(a),n._rejectUnchecked(s,a);
}else{var c=h(o,n);if(c instanceof e){if(c.isRejected()&&!c._isCarryingStackTrace()&&!R(c._settledValue)){var a=new Error(c._settledValue+"");n._attachExtraTrace(a),c._setCarriedStackTrace(a)}n._follow(c),n._propagateFrom(c,1)}else n._fulfillUnchecked(o)}},e.prototype._follow=function(t){this._setFollowing(),t.isPending()?(this._propagateFrom(t,1),t._proxyPromise(this)):t.isFulfilled()?this._fulfillUnchecked(t._settledValue):this._rejectUnchecked(t._settledValue,t._getCarriedStackTrace()),t._isRejectionUnhandled()&&t._unsetRejectionIsUnhandled(),S&&null==t._traceParent&&(t._traceParent=this)},e.prototype._tryFollow=function(t){if(this._isFollowingOrFulfilledOrRejected()||t===this)return!1;var r=h(t,void 0);return r instanceof e&&(this._follow(r),!0)},e.prototype._resetTrace=function(){S&&(this._trace=new p(void 0===this._peekContext()))},e.prototype._setTrace=function(t){if(S){var e=this._peekContext();this._traceParent=e;var r=void 0===e;void 0!==t&&t._traceParent===e?this._trace=t._trace:this._trace=new p(r)}return this},e.prototype._attachExtraTrace=function(t){if(S){var e=this,r=t.stack;r="string"==typeof r?r.split("\n"):[],p.protectErrorMessageNewlines(r);for(var i=1,n=1;null!=e&&null!=e._trace;)r=p.combine(r,e._trace.stack.split("\n")),e=e._traceParent,n++;var o=Error.stackTraceLimit||10,s=(o+i)*n,a=r.length;a>s&&(r.length=s),a>0&&(r[0]=r[0].split("\0").join("\n")),r.length<=i?t.stack="(No stack trace)":t.stack=r.join("\n")}},e.prototype._cleanValues=function(){this._cancellable()&&(this._cancellationParent=void 0)},e.prototype._propagateFrom=function(t,e){(1&e)>0&&t._cancellable()&&(this._setCancellable(),this._cancellationParent=t),(4&e)>0&&this._setBoundTo(t._boundTo),(2&e)>0&&this._setTrace(t)},e.prototype._fulfill=function(t){this._isFollowingOrFulfilledOrRejected()||this._fulfillUnchecked(t)},e.prototype._reject=function(t,e){this._isFollowingOrFulfilledOrRejected()||this._rejectUnchecked(t,e)},e.prototype._settlePromiseAt=function(t){var r=this.isFulfilled()?this._fulfillmentHandlerAt(t):this._rejectionHandlerAt(t),i=this._settledValue,n=this._receiverAt(t),o=this._promiseAt(t);if("function"==typeof r)this._settlePromiseFromHandler(r,n,i,o);else{var s=!1,a=this.isFulfilled();void 0!==n&&(n instanceof e&&n._isProxied()?(n._unsetProxied(),a?n._fulfillUnchecked(i):n._rejectUnchecked(i,this._getCarriedStackTrace()),s=!0):n instanceof f&&(a?n._promiseFulfilled(i,o):n._promiseRejected(i,o),s=!0)),s||(a?o._fulfill(i):o._reject(i,this._getCarriedStackTrace()))}t>=4&&this._queueGC()},e.prototype._isProxied=function(){return 4194304===(4194304&this._bitField)},e.prototype._setProxied=function(){this._bitField=4194304|this._bitField},e.prototype._unsetProxied=function(){this._bitField=this._bitField&-4194305},e.prototype._isGcQueued=function(){return(this._bitField&-1073741824)===-1073741824},e.prototype._setGcQueued=function(){this._bitField=this._bitField|-1073741824},e.prototype._unsetGcQueued=function(){this._bitField=1073741823&this._bitField},e.prototype._queueGC=function(){this._isGcQueued()||(this._setGcQueued(),s.invokeLater(this._gc,this,void 0))},e.prototype._gc=function(){for(var t=5*this._length()-5,e=0;e<t;e++)delete this[e];this._clearFirstHandlerData(),this._setLength(0),this._unsetGcQueued()},e.prototype._clearFirstHandlerData=function(){this._fulfillmentHandler0=void 0,this._rejectionHandler0=void 0,this._promise0=void 0,this._receiver0=void 0},e.prototype._queueSettleAt=function(t){this._isRejectionUnhandled()&&this._unsetRejectionIsUnhandled(),s.invoke(this._settlePromiseAt,this,t)},e.prototype._fulfillUnchecked=function(t){if(this.isPending()){if(t===this){var e=C();return this._attachExtraTrace(e),this._rejectUnchecked(e,void 0)}this._cleanValues(),this._setFulfilled(),this._settledValue=t;var r=this._length();r>0&&s.invoke(this._settlePromises,this,r)}},e.prototype._rejectUncheckedCheckError=function(t){var e=R(t)?t:new Error(t+"");this._rejectUnchecked(t,e===t?void 0:e)},e.prototype._rejectUnchecked=function(t,e){if(this.isPending()){if(t===this){var r=C();return this._attachExtraTrace(r),this._rejectUnchecked(r)}if(this._cleanValues(),this._setRejected(),this._settledValue=t,this._isFinal())return void s.invokeLater(x,void 0,void 0===e?t:e);var i=this._length();void 0!==e&&this._setCarriedStackTrace(e),i>0?s.invoke(this._rejectPromises,this,null):this._ensurePossibleRejectionHandled()}},e.prototype._rejectPromises=function(){this._settlePromises(),this._unsetCarriedStackTrace()},e.prototype._settlePromises=function(){for(var t=this._length(),e=0;e<t;e++)this._settlePromiseAt(e)},e.prototype._ensurePossibleRejectionHandled=function(){this._setRejectionIsUnhandled(),void 0!==p.possiblyUnhandledRejection&&s.invokeLater(this._notifyUnhandledRejection,this,void 0)},e.prototype._notifyUnhandledRejectionIsHandled=function(){"function"==typeof O&&s.invokeLater(O,void 0,this)},e.prototype._notifyUnhandledRejection=function(){if(this._isRejectionUnhandled()){var t=this._settledValue,e=this._getCarriedStackTrace();this._setUnhandledRejectionIsNotified(),void 0!==e&&(this._unsetCarriedStackTrace(),t=e),"function"==typeof p.possiblyUnhandledRejection&&p.possiblyUnhandledRejection(t,this)}};var U=[];return e.prototype._peekContext=function(){var t=U.length-1;if(t>=0)return U[t]},e.prototype._pushContext=function(){S&&U.push(this)},e.prototype._popContext=function(){S&&U.pop()},e.noConflict=function(){return i(e)},e.setScheduler=function(t){if("function"!=typeof t)throw new w("fn must be a function");s._schedule=t},p.isSupported()||(e.longStackTraces=function(){},S=!1),e._makeSelfResolutionError=C,t("./finally.js")(e,l,h),t("./direct_resolve.js")(e),t("./synchronous_inspection.js")(e),t("./join.js")(e,f,h,c),e.RangeError=b,e.CancellationError=F,e.TimeoutError=k,e.TypeError=w,e.OperationalError=E,e.RejectionError=E,e.AggregateError=a.AggregateError,o.toFastProperties(e),o.toFastProperties(e.prototype),e.Promise=e,t("./timers.js")(e,c,h),t("./race.js")(e,c,h),t("./call_get.js")(e),t("./generators.js")(e,A,c,h),t("./map.js")(e,f,A,h,c),t("./nodeify.js")(e),t("./promisify.js")(e,c),t("./props.js")(e,f,h),t("./reduce.js")(e,f,A,h,c),t("./settle.js")(e,f),t("./some.js")(e,f,A),t("./progress.js")(e,f),t("./cancel.js")(e,c),t("./filter.js")(e,c),t("./any.js")(e,f),t("./each.js")(e,c),t("./using.js")(e,A,h),e.prototype=e.prototype,e}},{"./any.js":1,"./async.js":2,"./call_get.js":4,"./cancel.js":5,"./captured_trace.js":6,"./catch_filter.js":7,"./direct_resolve.js":8,"./each.js":9,"./errors.js":10,"./errors_api_rejection":11,"./filter.js":13,"./finally.js":14,"./generators.js":15,"./join.js":16,"./map.js":17,"./nodeify.js":18,"./progress.js":19,"./promise_array.js":21,"./promise_resolver.js":22,"./promisify.js":23,"./props.js":24,"./race.js":26,"./reduce.js":27,"./settle.js":29,"./some.js":30,"./synchronous_inspection.js":31,"./thenables.js":32,"./timers.js":33,"./using.js":34,"./util.js":35}],21:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(t){switch(t){case-1:return;case-2:return[];case-3:return{}}}function o(t){var i=this._promise=new e(r),n=void 0;t instanceof e&&(n=t,i._propagateFrom(n,5)),i._setTrace(n),this._values=t,this._length=0,this._totalResolved=0,this._init(void 0,-2)}var s=t("./errors.js").canAttach,a=t("./util.js"),c=a.isArray;return o.prototype.length=function(){return this._length},o.prototype.promise=function(){return this._promise},o.prototype._init=function t(r,o){var s=i(this._values,void 0);if(s instanceof e){if(this._values=s,s._setBoundTo(this._promise._boundTo),!s.isFulfilled())return s.isPending()?void s._then(t,this._reject,void 0,this,o):(s._unsetRejectionIsUnhandled(),void this._reject(s._settledValue));if(s=s._settledValue,!c(s)){var a=new e.TypeError("expecting an array, a promise or a thenable");return void this.__hardReject__(a)}}else if(!c(s)){var a=new e.TypeError("expecting an array, a promise or a thenable");return void this.__hardReject__(a)}if(0===s.length)return void(o===-5?this._resolveEmptyArray():this._resolve(n(o)));for(var u=this.getActualLength(s.length),l=u,h=this.shouldCopyValues()?new Array(u):this._values,f=!1,p=0;p<u;++p){var _=i(s[p],void 0);_ instanceof e?_.isPending()?_._proxyPromiseArray(this,p):(_._unsetRejectionIsUnhandled(),f=!0):f=!0,h[p]=_}this._values=h,this._length=l,f&&this._scanDirectValues(u)},o.prototype._settlePromiseAt=function(t){var r=this._values[t];r instanceof e?r.isFulfilled()?this._promiseFulfilled(r._settledValue,t):r.isRejected()&&this._promiseRejected(r._settledValue,t):this._promiseFulfilled(r,t)},o.prototype._scanDirectValues=function(t){for(var e=0;e<t&&!this._isResolved();++e)this._settlePromiseAt(e)},o.prototype._isResolved=function(){return null===this._values},o.prototype._resolve=function(t){this._values=null,this._promise._fulfill(t)},o.prototype.__hardReject__=o.prototype._reject=function(t){this._values=null;var e=s(t)?t:new Error(t+"");this._promise._attachExtraTrace(e),this._promise._reject(t,e)},o.prototype._promiseProgressed=function(t,e){this._isResolved()||this._promise._progress({index:e,value:t})},o.prototype._promiseFulfilled=function(t,e){if(!this._isResolved()){this._values[e]=t;var r=++this._totalResolved;r>=this._length&&this._resolve(this._values)}},o.prototype._promiseRejected=function(t,e){this._isResolved()||(this._totalResolved++,this._reject(t))},o.prototype.shouldCopyValues=function(){return!0},o.prototype.getActualLength=function(t){return t},o}},{"./errors.js":10,"./util.js":35}],22:[function(t,e,r){"use strict";function i(t){return t instanceof Error&&_.getPrototypeOf(t)===Error.prototype}function n(t){var e;return e=i(t)?new h(t):t,u.markAsOriginatingFromRejection(e),e}function o(t){function e(e,r){if(null!==t){if(e){var i=n(c(e));t._attachExtraTrace(i),t._reject(i)}else if(arguments.length>2){for(var o=arguments.length,s=new Array(o-1),a=1;a<o;++a)s[a-1]=arguments[a];t._fulfill(s)}else t._fulfill(r);t=null}}return e}var s,a=t("./util.js"),c=a.maybeWrapAsError,u=t("./errors.js"),l=u.TimeoutError,h=u.OperationalError,f=t("./async.js"),p=a.haveGetters,_=t("./es5.js");if(s=p?function(t){this.promise=t}:function(t){this.promise=t,this.asCallback=o(t),this.callback=this.asCallback},p){var d={get:function(){return o(this.promise)}};_.defineProperty(s.prototype,"asCallback",d),_.defineProperty(s.prototype,"callback",d)}s._nodebackForPromise=o,s.prototype.toString=function(){return"[object PromiseResolver]"},s.prototype.resolve=s.prototype.fulfill=function(t){if(!(this instanceof s))throw new TypeError("Illegal invocation, resolver resolve/reject must be called within a resolver context. Consider using the promise constructor instead.");var e=this.promise;e._tryFollow(t)||f.invoke(e._fulfill,e,t)},s.prototype.reject=function(t){if(!(this instanceof s))throw new TypeError("Illegal invocation, resolver resolve/reject must be called within a resolver context. Consider using the promise constructor instead.");var e=this.promise;u.markAsOriginatingFromRejection(t);var r=u.canAttach(t)?t:new Error(t+"");e._attachExtraTrace(r),f.invoke(e._reject,e,t),r!==t&&f.invoke(this._setCarriedStackTrace,this,r)},s.prototype.progress=function(t){if(!(this instanceof s))throw new TypeError("Illegal invocation, resolver resolve/reject must be called within a resolver context. Consider using the promise constructor instead.");f.invoke(this.promise._progress,this.promise,t)},s.prototype.cancel=function(){f.invoke(this.promise.cancel,this.promise,void 0)},s.prototype.timeout=function(){this.reject(new l("timeout"))},s.prototype.isResolved=function(){return this.promise.isResolved()},s.prototype.toJSON=function(){return this.promise.toJSON()},s.prototype._setCarriedStackTrace=function(t){this.promise.isRejected()&&this.promise._setCarriedStackTrace(t)},e.exports=s},{"./async.js":2,"./errors.js":10,"./es5.js":12,"./util.js":35}],23:[function(t,e,r){"use strict";e.exports=function(e,r){function i(t){return t.replace(/([$])/,"\\$")}function n(t){try{return t.__isPromisified__===!0}catch(t){return!1}}function o(t,e,r){var i=m.getDataPropertyOrDefault(t,e+r,P);return!!i&&n(i)}function s(t,e,r){for(var i=0;i<t.length;i+=2){var n=t[i];if(r.test(n))for(var o=n.replace(r,""),s=0;s<t.length;s+=2)if(t[s]===o)throw new F("Cannot promisify an API that has normal methods with '"+e+"'-suffix")}}function a(t,e,r,i){for(var a=m.inheritedDataKeys(t),c=[],u=0;u<a.length;++u){var l=a[u],h=t[l];"function"!=typeof h||n(h)||o(t,l,e)||!i(l,h,t)||c.push(l,h)}return s(c,e,r),c}function c(t){for(var e=[t],r=Math.max(0,t-1-5),i=t-1;i>=r;--i)i!==t&&e.push(i);for(var i=t+1;i<=5;++i)e.push(i);return e}function u(t){return m.filledRange(t,"arguments[","]")}function l(t){return m.filledRange(t,"_arg","")}function h(t){return"number"==typeof t.length?Math.max(Math.min(t.length,1024),0):0}function f(t){return m.isIdentifier(t)?"."+t:"['"+t.replace(/(['\\])/g,"\\$1")+"']"}function p(t,i,n,o,s){function a(e){var r,n=u(e).join(", "),o=e>0?", ":"";return r="string"==typeof t?"                                                          \n                this.method({{args}}, fn);                                   \n                break;                                                       \n            ".replace(".method",f(t)):i===y?"                                                         \n                callback.call(this, {{args}}, fn);                           \n                break;                                                       \n            ":void 0!==i?"                                                         \n                callback.call(receiver, {{args}}, fn);                       \n                break;                                                       \n            ":"                                                         \n                callback({{args}}, fn);                                      \n                break;                                                       \n            ",r.replace("{{args}}",n).replace(", ",o)}function p(){for(var e="",r=0;r<d.length;++r)e+="case "+d[r]+":"+a(d[r]);var n;return n="string"==typeof t?"                                                  \n                this.property.apply(this, args);                             \n            ".replace(".property",f(t)):i===y?"                                                  \n                callback.apply(this, args);                                  \n            ":"                                                  \n                callback.apply(receiver, args);                              \n            ",e+="                                                             \n        default:                                                             \n            var args = new Array(len + 1);                                   \n            var i = 0;                                                       \n            for (var i = 0; i < len; ++i) {                                  \n               args[i] = arguments[i];                                       \n            }                                                                \n            args[i] = fn;                                                    \n            [CodeForCall]                                                    \n            break;                                                           \n        ".replace("[CodeForCall]",n)}var _=Math.max(0,h(o)-1),d=c(_),v="string"==typeof n&&m.isIdentifier(n)?n+s:"promisified";return new Function("Promise","callback","receiver","withAppended","maybeWrapAsError","nodebackForPromise","INTERNAL","                                         \n        var ret = function FunctionName(Parameters) {                        \n            'use strict';                                                    \n            var len = arguments.length;                                      \n            var promise = new Promise(INTERNAL);                             \n            promise._setTrace(void 0);                                       \n            var fn = nodebackForPromise(promise);                            \n            try {                                                            \n                switch(len) {                                                \n                    [CodeForSwitchCase]                                      \n                }                                                            \n            } catch (e) {                                                    \n                var wrapped = maybeWrapAsError(e);                           \n                promise._attachExtraTrace(wrapped);                          \n                promise._reject(wrapped);                                    \n            }                                                                \n            return promise;                                                  \n        };                                                                   \n        ret.__isPromisified__ = true;                                        \n        return ret;                                                          \n        ".replace("FunctionName",v).replace("Parameters",l(_)).replace("[CodeForSwitchCase]",p()))(e,t,i,j,b,g,r)}function _(t,i){function n(){var n=i;i===y&&(n=this),"string"==typeof t&&(t=n[t]);var o=new e(r);o._setTrace(void 0);var s=g(o);try{t.apply(n,j(arguments,s))}catch(t){var a=b(t);o._attachExtraTrace(a),o._reject(a)}return o}return n.__isPromisified__=!0,n}function d(t,e,r,n){for(var o=new RegExp(i(e)+"$"),s=a(t,e,o,r),c=0,u=s.length;c<u;c+=2){var l=s[c],h=s[c+1],f=l+e;t[f]=n===T?T(l,y,l,h,e):n(h)}return m.toFastProperties(t),t}function v(t,e){return T(t,e,void 0,t)}var y={},m=t("./util.js"),g=t("./promise_resolver.js")._nodebackForPromise,j=m.withAppended,b=m.maybeWrapAsError,w=m.canEvaluate,F=t("./errors").TypeError,k="Async",E=function(t,e){return m.isIdentifier(t)&&"_"!==t.charAt(0)&&!m.isClass(e)},P={__isPromisified__:!0},T=w?p:_;e.promisify=function(t,e){if("function"!=typeof t)throw new F("fn must be a function");return n(t)?t:v(t,arguments.length<2?y:e)},e.promisifyAll=function(t,e){if("function"!=typeof t&&"object"!=typeof t)throw new F("the target of promisifyAll must be an object or a function");e=Object(e);var r=e.suffix;"string"!=typeof r&&(r=k);var i=e.filter;"function"!=typeof i&&(i=E);var n=e.promisifier;if("function"!=typeof n&&(n=T),!m.isIdentifier(r))throw new RangeError("suffix must be a valid identifier");for(var o=m.inheritedDataKeys(t,{includeHidden:!0}),s=0;s<o.length;++s){var a=t[o[s]];"constructor"!==o[s]&&m.isClass(a)&&(d(a.prototype,r,i,n),d(a,r,i,n))}return d(t,r,i,n)}}},{"./errors":10,"./promise_resolver.js":22,"./util.js":35}],24:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(t){for(var e=u.keys(t),r=e.length,i=new Array(2*r),n=0;n<r;++n){var o=e[n];i[n]=t[o],i[n+r]=o}this.constructor$(i)}function o(t){var r,o=i(t,void 0);return c(o)?(r=o instanceof e?o._then(e.props,void 0,void 0,void 0,void 0):new n(o).promise(),o instanceof e&&r._propagateFrom(o,4),r):a("cannot await properties of a non-object")}var s=t("./util.js"),a=t("./errors_api_rejection")(e),c=s.isObject,u=t("./es5.js");s.inherits(n,r),n.prototype._init=function(){this._init$(void 0,-3)},n.prototype._promiseFulfilled=function(t,e){if(!this._isResolved()){this._values[e]=t;var r=++this._totalResolved;if(r>=this._length){for(var i={},n=this.length(),o=0,s=this.length();o<s;++o)i[this._values[o+n]]=this._values[o];this._resolve(i)}}},n.prototype._promiseProgressed=function(t,e){this._isResolved()||this._promise._progress({key:this._values[e+this.length()],value:t})},n.prototype.shouldCopyValues=function(){return!1},n.prototype.getActualLength=function(t){return t>>1},e.prototype.props=function(){return o(this)},e.props=function(t){return o(t)}}},{"./errors_api_rejection":11,"./es5.js":12,"./util.js":35}],25:[function(t,e,r){"use strict";function i(t,e,r,i,n){for(var o=0;o<n;++o)r[o+i]=t[o+e]}function n(t){this._capacity=t,this._length=0,this._front=0,this._makeCapacity()}n.prototype._willBeOverCapacity=function(t){return this._capacity<t},n.prototype._pushOne=function(t){var e=this.length();this._checkCapacity(e+1);var r=this._front+e&this._capacity-1;this[r]=t,this._length=e+1},n.prototype.push=function(t,e,r){var i=this.length()+3;if(this._willBeOverCapacity(i))return this._pushOne(t),this._pushOne(e),void this._pushOne(r);var n=this._front+i-3;this._checkCapacity(i);var o=this._capacity-1;this[n+0&o]=t,this[n+1&o]=e,this[n+2&o]=r,this._length=i},n.prototype.shift=function(){var t=this._front,e=this[t];return this[t]=void 0,this._front=t+1&this._capacity-1,this._length--,e},n.prototype.length=function(){return this._length},n.prototype._makeCapacity=function(){for(var t=this._capacity,e=0;e<t;++e)this[e]=void 0},n.prototype._checkCapacity=function(t){this._capacity<t&&this._resizeTo(this._capacity<<3)},n.prototype._resizeTo=function(t){var e=this._front,r=this._capacity,n=new Array(r),o=this.length();if(i(this,0,n,0,r),this._capacity=t,this._makeCapacity(),this._front=0,e+o<=r)i(n,e,this,0,o);else{var s=o-(e+o&r-1);i(n,e,this,0,s),i(n,0,this,s,o-s)}},e.exports=n},{}],26:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(t,n){var u=i(t,void 0);if(u instanceof e)return a(u);if(!s(t))return o("expecting an array, a promise or a thenable");var l=new e(r);void 0!==n?l._propagateFrom(n,7):l._setTrace(void 0);for(var h=l._fulfill,f=l._reject,p=0,_=t.length;p<_;++p){var d=t[p];(void 0!==d||c.call(t,p))&&e.cast(d)._then(h,f,void 0,l,null)}return l}var o=t("./errors_api_rejection.js")(e),s=t("./util.js").isArray,a=function(t){return t.then(function(e){return n(e,t)})},c={}.hasOwnProperty;e.race=function(t){return n(t,void 0)},e.prototype.race=function(){return n(this,void 0)}}},{"./errors_api_rejection.js":11,"./util.js":35}],27:[function(t,e,r){"use strict";e.exports=function(e,r,i,n,o){function s(t,r,i,s){this.constructor$(t),this._preservedValues=s===o?[]:null,this._zerothIsAccum=void 0===i,this._gotAccum=!1,this._reducingIndex=this._zerothIsAccum?1:0,this._valuesPhase=void 0;var a=n(i,void 0),c=!1,u=a instanceof e;u&&(a.isPending()?a._proxyPromiseArray(this,-1):a.isFulfilled()?(i=a.value(),this._gotAccum=!0):(a._unsetRejectionIsUnhandled(),this._reject(a.reason()),c=!0)),u||this._zerothIsAccum||(this._gotAccum=!0),this._callback=r,this._accum=i,c||this._init$(void 0,-5)}function a(t,e,r,n){if("function"!=typeof e)return i("fn must be a function");var o=new s(t,e,r,n);return o.promise()}var c=t("./util.js"),u=c.tryCatch4,l=c.tryCatch3,h=c.errorObj;c.inherits(s,r),s.prototype._init=function(){},s.prototype._resolveEmptyArray=function(){(this._gotAccum||this._zerothIsAccum)&&this._resolve(null!==this._preservedValues?[]:this._accum)},s.prototype._promiseFulfilled=function(t,r){var i=this._values;if(null!==i){var o,s=this.length(),a=this._preservedValues,c=null!==a,f=this._gotAccum,p=this._valuesPhase;if(!p)for(p=this._valuesPhase=Array(s),o=0;o<s;++o)p[o]=0;if(o=p[r],0===r&&this._zerothIsAccum?(f||(this._accum=t,this._gotAccum=f=!0),p[r]=0===o?1:2):r===-1?f||(this._accum=t,this._gotAccum=f=!0):0===o?p[r]=1:(p[r]=2,f&&(this._accum=t)),f){for(var _,d=this._callback,v=this._promise._boundTo,y=this._reducingIndex;y<s;++y)if(o=p[y],2!==o){if(1!==o)return;if(t=i[y],t instanceof e){if(!t.isFulfilled())return t.isPending()?void 0:(t._unsetRejectionIsUnhandled(),this._reject(t.reason()));t=t._settledValue}if(c?(a.push(t),_=l(d,v,t,y,s)):_=u(d,v,this._accum,t,y,s),_===h)return this._reject(_.e);var m=n(_,void 0);if(m instanceof e){if(m.isPending())return p[y]=4,m._proxyPromiseArray(this,y);if(!m.isFulfilled())return m._unsetRejectionIsUnhandled(),this._reject(m.reason());_=m.value()}this._reducingIndex=y+1,this._accum=_}else this._reducingIndex=y+1;this._reducingIndex<s||this._resolve(c?a:this._accum)}}},e.prototype.reduce=function(t,e){return a(this,t,e,null)},e.reduce=function(t,e,r,i){return a(t,e,r,i)}}},{"./util.js":35}],28:[function(t,e,r){"use strict";var i,n;if("object"==typeof process&&"string"==typeof process.version)i=function(t){process.nextTick(t)};else if("undefined"!=typeof MutationObserver&&(n=MutationObserver)||"undefined"!=typeof WebKitMutationObserver&&(n=WebKitMutationObserver))i=function(){var t=document.createElement("div"),e=void 0,r=new n(function(){var t=e;e=void 0,t()});return r.observe(t,{attributes:!0}),function(r){e=r,t.classList.toggle("foo")}}();else{if("undefined"==typeof setTimeout)throw new Error("no async scheduler available");i=function(t){setTimeout(t,0)}}e.exports=i},{}],29:[function(t,e,r){"use strict";e.exports=function(e,r){function i(t){this.constructor$(t)}var n=e.PromiseInspection,o=t("./util.js");o.inherits(i,r),i.prototype._promiseResolved=function(t,e){this._values[t]=e;var r=++this._totalResolved;r>=this._length&&this._resolve(this._values)},i.prototype._promiseFulfilled=function(t,e){if(!this._isResolved()){var r=new n;r._bitField=268435456,r._settledValue=t,this._promiseResolved(e,r)}},i.prototype._promiseRejected=function(t,e){if(!this._isResolved()){var r=new n;r._bitField=134217728,r._settledValue=t,this._promiseResolved(e,r)}},e.settle=function(t){return new i(t).promise()},e.prototype.settle=function(){return new i(this).promise()}}},{"./util.js":35}],30:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(t){this.constructor$(t),this._howMany=0,this._unwrap=!1,this._initialized=!1}function o(t,e){if((0|e)!==e||e<0)return i("expecting a positive integer");var r=new n(t),o=r.promise();return o.isRejected()?o:(r.setHowMany(e),r.init(),o)}var s=t("./util.js"),a=t("./errors.js").RangeError,c=t("./errors.js").AggregateError,u=s.isArray;s.inherits(n,r),n.prototype._init=function(){if(this._initialized){if(0===this._howMany)return void this._resolve([]);this._init$(void 0,-5);var t=u(this._values);!this._isResolved()&&t&&this._howMany>this._canPossiblyFulfill()&&this._reject(this._getRangeError(this.length()))}},n.prototype.init=function(){this._initialized=!0,this._init()},n.prototype.setUnwrap=function(){this._unwrap=!0},n.prototype.howMany=function(){return this._howMany},n.prototype.setHowMany=function(t){this._isResolved()||(this._howMany=t)},n.prototype._promiseFulfilled=function(t){this._isResolved()||(this._addFulfilled(t),this._fulfilled()===this.howMany()&&(this._values.length=this.howMany(),1===this.howMany()&&this._unwrap?this._resolve(this._values[0]):this._resolve(this._values)))},n.prototype._promiseRejected=function(t){if(!this._isResolved()&&(this._addRejected(t),this.howMany()>this._canPossiblyFulfill())){for(var e=new c,r=this.length();r<this._values.length;++r)e.push(this._values[r]);this._reject(e)}},n.prototype._fulfilled=function(){return this._totalResolved},n.prototype._rejected=function(){return this._values.length-this.length()},n.prototype._addRejected=function(t){this._values.push(t)},n.prototype._addFulfilled=function(t){this._values[this._totalResolved++]=t},n.prototype._canPossiblyFulfill=function(){return this.length()-this._rejected()},n.prototype._getRangeError=function(t){var e="Input array must contain at least "+this._howMany+" items but contains only "+t+" items";return new a(e)},n.prototype._resolveEmptyArray=function(){this._reject(this._getRangeError(0))},e.some=function(t,e){return o(t,e)},e.prototype.some=function(t){return o(this,t)},e._SomePromiseArray=n}},{"./errors.js":10,"./util.js":35}],31:[function(t,e,r){"use strict";e.exports=function(t){function e(t){void 0!==t?(this._bitField=t._bitField,this._settledValue=t.isResolved()?t._settledValue:void 0):(this._bitField=0,this._settledValue=void 0)}e.prototype.isFulfilled=t.prototype.isFulfilled=function(){return(268435456&this._bitField)>0},e.prototype.isRejected=t.prototype.isRejected=function(){return(134217728&this._bitField)>0},e.prototype.isPending=t.prototype.isPending=function(){return 0===(402653184&this._bitField)},e.prototype.value=t.prototype.value=function(){if(!this.isFulfilled())throw new TypeError("cannot get fulfillment value of a non-fulfilled promise");return this._settledValue},e.prototype.error=e.prototype.reason=t.prototype.reason=function(){if(!this.isRejected())throw new TypeError("cannot get rejection reason of a non-rejected promise");return this._settledValue},e.prototype.isResolved=t.prototype.isResolved=function(){return(402653184&this._bitField)>0},t.PromiseInspection=e}},{}],32:[function(t,e,r){"use strict";e.exports=function(e,r){function i(t){try{return t.then}catch(t){return u.e=t,u}}function n(t,n){if(l(t)){if(t instanceof e)return t;if(o(t)){var a=new e(r);return a._setTrace(void 0),t._then(a._fulfillUnchecked,a._rejectUncheckedCheckError,a._progressUnchecked,a,null),a._setFollowing(),a}var h=i(t);if(h===u)return void 0!==n&&c(h.e)&&n._attachExtraTrace(h.e),e.reject(h.e);if("function"==typeof h)return s(t,h,n)}return t}function o(t){return h.call(t,"_promise0")}function s(t,r,i){function n(r){if(!u){if(u=!0,t===r){var n=e._makeSelfResolutionError();return void 0!==i&&i._attachExtraTrace(n),void a.promise._reject(n,void 0)}a.resolve(r)}}function o(t){if(!u){u=!0;var e=c(t)?t:new Error(t+"");void 0!==i&&i._attachExtraTrace(e),a.promise._reject(t,e)}}function s(t){if(!u){var e=a.promise;"function"==typeof e._progress&&e._progress(t)}}var a=e.defer(),u=!1;try{r.call(t,n,o,s)}catch(t){if(!u){u=!0;var l=c(t)?t:new Error(t+"");void 0!==i&&i._attachExtraTrace(l),a.promise._reject(t,l)}}return a.promise}var a=t("./util.js"),c=t("./errors.js").canAttach,u=a.errorObj,l=a.isObject,h={}.hasOwnProperty;return n}},{"./errors.js":10,"./util.js":35}],33:[function(t,e,r){"use strict";var i=function(t,e){var r=arguments.length,i=arguments[2],n=arguments[3],o=r>=5?arguments[4]:void 0;setTimeout(function(){t(i,n,o)},0|e)};e.exports=function(e,r,n){var o=(t("./util.js"),t("./errors.js")),s=(t("./errors_api_rejection")(e),e.TimeoutError),a=function(t,e,r){if(t.isPending()){"string"!=typeof e&&(e="operation timed out after "+r+" ms");var i=new s(e);o.markAsOriginatingFromRejection(i),t._attachExtraTrace(i),t._cancel(i)}},c=function(t,e){e._fulfill(t)},u=e.delay=function(t,o){void 0===o&&(o=t,t=void 0),o=+o;var s=n(t,void 0),a=new e(r);return s instanceof e?(a._propagateFrom(s,7),a._follow(s),a.then(function(t){return e.delay(t,o)})):(a._setTrace(void 0),i(c,o,t,a),a)};e.prototype.delay=function(t){return u(this,t)},e.prototype.timeout=function(t,n){t=+t;var o=new e(r);return o._propagateFrom(this,7),o._follow(this),i(a,t,o,n,t),o.cancellable()}}},{"./errors.js":10,"./errors_api_rejection":11,"./util.js":35}],34:[function(t,e,r){"use strict";e.exports=function(e,r,i){function n(t){for(var r=t.length,i=0;i<r;++i){var n=t[i];if(n.isRejected())return e.reject(n.error());t[i]=n.value()}return t}function o(t){setTimeout(function(){throw t},0)}function s(t){var e=i(t,void 0);return e!==t&&"function"==typeof t._isDisposable&&"function"==typeof t._getDisposer&&t._isDisposable()&&e._setDisposable(t._getDisposer()),e}function a(t,r){function n(){if(a>=c)return u.resolve();var l=s(t[a++]);if(l instanceof e&&l._isDisposable()){try{l=i(l._getDisposer().tryDispose(r),void 0)}catch(t){return o(t)}if(l instanceof e)return l._then(n,o,null,null,null)}n()}var a=0,c=t.length,u=e.defer();return n(),u.promise}function c(t){var e=new _;return e._settledValue=t,e._bitField=268435456,a(this,e).thenReturn(t)}function u(t){var e=new _;return e._settledValue=t,e._bitField=134217728,a(this,e).thenThrow(t)}function l(t,e){this._data=t,this._promise=e}function h(t,e){this.constructor$(t,e)}var f=t("./errors.js").TypeError,p=t("./util.js").inherits,_=e.PromiseInspection;l.prototype.data=function(){return this._data},l.prototype.promise=function(){return this._promise},l.prototype.resource=function(){return this.promise().isFulfilled()?this.promise().value():null},l.prototype.tryDispose=function(t){var e=this.resource(),r=null!==e?this.doDispose(e,t):null;return this._promise._unsetDisposable(),this._data=this._promise=null,
r},l.isDisposer=function(t){return null!=t&&"function"==typeof t.resource&&"function"==typeof t.tryDispose},p(h,l),h.prototype.doDispose=function(t,e){var r=this.data();return r.call(t,t,e)},e.using=function(){var t=arguments.length;if(t<2)return r("you must pass at least 2 arguments to Promise.using");var i=arguments[t-1];if("function"!=typeof i)return r("fn must be a function");t--;for(var o=new Array(t),s=0;s<t;++s){var a=arguments[s];if(l.isDisposer(a)){var h=a;a=a.promise(),a._setDisposable(h)}o[s]=a}return e.settle(o).then(n).spread(i)._then(c,u,void 0,o,void 0)},e.prototype._setDisposable=function(t){this._bitField=262144|this._bitField,this._disposer=t},e.prototype._isDisposable=function(){return(262144&this._bitField)>0},e.prototype._getDisposer=function(){return this._disposer},e.prototype._unsetDisposable=function(){this._bitField=this._bitField&-262145,this._disposer=void 0},e.prototype.disposer=function(t){if("function"==typeof t)return new h(t,this);throw new f}}},{"./errors.js":10,"./util.js":35}],35:[function(t,e,r){"use strict";function i(t,e,r){try{return t.call(e,r)}catch(t){return F.e=t,F}}function n(t,e,r,i){try{return t.call(e,r,i)}catch(t){return F.e=t,F}}function o(t,e,r,i,n){try{return t.call(e,r,i,n)}catch(t){return F.e=t,F}}function s(t,e,r,i,n,o){try{return t.call(e,r,i,n,o)}catch(t){return F.e=t,F}}function a(t,e,r){try{return t.apply(r,e)}catch(t){return F.e=t,F}}function c(t){return"string"==typeof t?t:""+t}function u(t){return null==t||t===!0||t===!1||"string"==typeof t||"number"==typeof t}function l(t){return!u(t)}function h(t){return u(t)?new Error(c(t)):t}function f(t,e){var r,i=t.length,n=new Array(i+1);for(r=0;r<i;++r)n[r]=t[r];return n[r]=e,n}function p(t,e,r){if(!j.isES5)return{}.hasOwnProperty.call(t,e)?t[e]:void 0;var i=Object.getOwnPropertyDescriptor(t,e);return null!=i?null==i.get&&null==i.set?i.value:r:void 0}function _(t,e,r){if(u(t))return t;var i={value:r,configurable:!0,enumerable:!1,writable:!0};return j.defineProperty(t,e,i),t}function d(t){throw t}function v(t){try{if("function"==typeof t){var e=j.keys(t.prototype);return e.length>0&&!(1===e.length&&"constructor"===e[0])}return!1}catch(t){return!1}}function y(t){function e(){}return e.prototype=t,e}function m(t){return T.test(t)}function g(t,e,r){for(var i=new Array(t),n=0;n<t;++n)i[n]=e+n+r;return i}var j=t("./es5.js"),b=function(){try{var t={};return j.defineProperty(t,"f",{get:function(){return 3}}),3===t.f}catch(t){return!1}}(),w="undefined"==typeof navigator,F={e:{}},k=function(t,e){function r(){this.constructor=t,this.constructor$=e;for(var r in e.prototype)i.call(e.prototype,r)&&"$"!==r.charAt(r.length-1)&&(this[r+"$"]=e.prototype[r])}var i={}.hasOwnProperty;return r.prototype=e.prototype,t.prototype=new r,t.prototype},E=function(){return"string"!==this}.call("string"),P=function(){return j.isES5?function(t,e){for(var r=[],i=Object.create(null),n=Object(e).includeHidden?Object.getOwnPropertyNames:Object.keys;null!=t;){var o;try{o=n(t)}catch(t){return r}for(var s=0;s<o.length;++s){var a=o[s];if(!i[a]){i[a]=!0;var c=Object.getOwnPropertyDescriptor(t,a);null!=c&&null==c.get&&null==c.set&&r.push(a)}}t=j.getPrototypeOf(t)}return r}:function(t){var e=[];for(var r in t)e.push(r);return e}}(),T=/^[a-z$_][a-z$_0-9]*$/i,R={isClass:v,isIdentifier:m,inheritedDataKeys:P,getDataPropertyOrDefault:p,thrower:d,isArray:j.isArray,haveGetters:b,notEnumerableProp:_,isPrimitive:u,isObject:l,canEvaluate:w,errorObj:F,tryCatch1:i,tryCatch2:n,tryCatch3:o,tryCatch4:s,tryCatchApply:a,inherits:k,withAppended:f,asString:c,maybeWrapAsError:h,wrapsPrimitiveReceiver:E,toFastProperties:y,filledRange:g};e.exports=R},{"./es5.js":12}]},{},[3])(3)}),"undefined"!=typeof t&&null!==t?t.P=t.Promise:"undefined"!=typeof self&&null!==self&&(self.P=self.Promise)});;
;
/* module-key = 'com.atlassian.jira.jira-onboarding-assets-plugin:promise', location = 'jira-onboarding-assets-module/lib/bluebird-promise-amd.js' */
define('bluebird/Promise', ["atlassian/libs/bluebird-2.3.6"], function(bluebird) {
    return bluebird;
});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-backbone-define', location = 'jira-development-integration-plugin/js/util/DevStatusBackboneDefine.js' */
"use strict";Backbone&&!Backbone.define&&(Backbone.define=function(name,ctor){eval("Backbone['Class: "+name+"'] = function() { Backbone['Class: "+name+"'].__ctor.apply(this, arguments); }");var cls=Backbone["Class: "+name];cls.__ctor=ctor,ctor.prototype.name=name,cls.prototype=ctor.prototype,_.extend(cls,ctor),_.each(ctor.prototype,function(t,e){"function"==typeof t&&(t.displayName=name+"."+e)});var context=window,parts=name.split(".");return _.each(parts,function(t,e){e===parts.length-1?context[t]=cls:context=null==context[t]?context[t]={}:context[t]}),cls});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:event-publisher', location = 'jira-development-integration-plugin/js/util/EventPublisher.js' */
"use strict";define("jira-development-status/util/event-publisher",function(){return{trigger:AJS.trigger}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-wrm', location = 'jira-development-integration-plugin/js/util/DevStatusWRM.js' */
"use strict";define("jira-development-status/util/WRM",["underscore","jira-development-status/util/event-publisher"],function(e,r){var n="wrc!com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-resources-ctx",i="jira.devsummary.dialog-resources.wrm.load",t=function(){return window.performance.now()},a=function(e){var r=t();WRM.require([n],function(){o(r),e&&e()})},u=function(e){var n=Math.round(t()-e);r.trigger("analyticsEvent",{name:i,data:{durationInMillis:n}})},o=e.once(u);return{ANALYTIC_EVENT:i,requireDetailDialogResources:a}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/DateUtils.js' */
"use strict";define("jira/dev-status/util/date",["jquery"],function(t){return{addTooltip:function(a){var e=a.find("time.livestamp");e.livestamp(),e.each(function(){var a=t(this),e=a.attr("datetime"),i=isNaN(e)?e:+e,r=moment(i);a.attr("title",r.format(JIRA.DevStatus.Date.format))})},format:"LLL"}}),function(t){AJS.namespace("JIRA.DevStatus.Date",null,t)}(require("jira/dev-status/util/date"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/dev-status-console.js' */
"use strict";define("jira-development-status/util/console",[],function(){if(console)return console;var e=function(){};return{log:e,info:e,warn:e,debug:e,error:e}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/dev-status-constants.js' */
"use strict";define("jira-development-status/util/constants",function(){return{PLUGIN_KEY:"com.atlassian.jira.plugins.jira-development-integration-plugin",RELEASE_REPORT_SELECTED_TAB:"release-report-selected-tab"}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/LocalStorage.js' */
"use strict";define("jira-development-status/util/local-storage",[],function(){return localStorage?localStorage:{setItem:function(){},getItem:function(){},removeItem:function(){},clear:function(){}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/ApplinksUtils.js' */
"use strict";define("jira-development-status/util/applinks-utils",[],function(){return ApplinksUtils});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/DevStatusLocalStorage.js' */
"use strict";define("jira-development-status/util/dev-status-local-storage",["underscore","jira-development-status/util/console","jira-development-status/util/local-storage"],function(e,t,r){var o=e.extend({},r);return o.setItem=function(e,o){try{r.setItem(e,o)}catch(a){var l="";(22===a.code||1014===a.code&&"NS_ERROR_DOM_QUOTA_REACHED"===a.name)&&(l=". Browser local storage is full. For more information please follow https://confluence.atlassian.com/jirakb/functionality-in-jira-fails-due-to-exceeding-chrome-quota-762874705.html"),t.error("Couldn't store '"+e+"' & '"+o+"' key-value pair locally: "+a.name+l)}},o.getItem=function(e){try{return r.getItem(e)}catch(o){t.error("Couldn't retrieve locally stored value for key '"+e+"': "+o.name)}},o.removeItem=function(e){try{r.removeItem(e)}catch(o){t.error("Couldn't remove locally stored value for key '"+e+"': "+o.name)}},o.clear=function(){try{r.clear()}catch(e){t.error("Couldn't clear local storage: "+e.name)}},o});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/Listeners.js' */
"use strict";define("jira/devstatus/util/listeners",["underscore"],function(t){return Class.extend({init:function(){this._listening=[]},startListening:function(t,i,n,s){var e={start:function(){return t.on(i,n,s),this},stop:function(){return t.off(i,n,s),this}};this._listening.push(e.start())},stopListening:function(){t.each(this._listening,function(t){t.stop()}),this._listening=[]}})}),Backbone.define("JIRA.DevStatus.Util.Listeners",require("jira/devstatus/util/listeners"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/DevStatusNavigation.js' */
"use strict";define("jira-development-status/util/navigate",["underscore"],function(n){return{getUrl:function(){return window.location.href},reload:function(){n.defer(function(){window.location.reload()})},navigate:function(t){n.defer(function(){window.location=t})},redirectToLogin:function(){this.navigate(AJS.contextPath()+"/login.jsp?permissionViolation=true&os_destination="+encodeURIComponent(window.location.href))}}}),function(n){AJS.namespace("JIRA.DevStatus.Navigate",null,n)}(require("jira-development-status/util/navigate"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/DevStatusURLUtils.js' */
"use strict";define("jira/dev-status/util/url",["jquery","underscore"],function(e,t){return{getDetailDialogParam:function(){var e=this._removeKickAssIHashFromUrl(JIRA.DevStatus.Navigate.getUrl()),t=parseUri(e);return t&&t.queryKey&&t.queryKey.devStatusDetailDialog},getUrlWithDetailDialogParam:function(e){var t=this._removeKickAssIHashFromUrl(JIRA.DevStatus.Navigate.getUrl()),r=parseUri(t);return r.queryKey.devStatusDetailDialog=encodeURIComponent(e),this.createUrlFromParsedUri(r)},getCreateReviewDetailUrl:function(e){return this.getUrlWithDetailDialogParam("create-review-"+e)},isCreateReviewDetailDialogLink:function(e){return e&&e.lastIndexOf&&0===e.lastIndexOf("create-review-",0)},getCreateReviewDetailDialogApplicationType:function(e){return e.substring("create-review-".length)},_removeKickAssIHashFromUrl:function(e){return e.replace("i#","")},createUrlFromParsedUri:function(r){var a=[];e.each(r.queryKey,function(r,i){t.isObject(i)?e.each(i,function(e,t){a.push(r+"="+t)}):a.push(r+"="+i)});var i="";return r.protocol&&(i+=r.protocol+"://"),r.authority&&(i+=r.authority),r.path&&(i+=r.path),a.length>0&&(i+="?"+a.join("&")),r.anchor&&(i+="#"+r.anchor),i}}}),function(e){AJS.namespace("JIRA.DevStatus.URL",null,e)}(require("jira/dev-status/util/url"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/Sanitize.js' */
"use strict";define("jira-development-status/util/sanitize",["underscore"],function(t){function n(t){return c.indexOf(t[0])>-1}function r(t){if(!t)return"about:blank";var r,e,i=t.replace(u,"").trim();return n(i)?i:(e=i.match(o))?(r=e[0],a.test(r)?"about:blank":i):"about:blank"}function e(n,e){for(var i=t.clone(n),a=e||[],u=0;u<a.length;u++){var o=a[u];n.hasOwnProperty(o)&&"string"==typeof i[o]&&(i[o]=r(i[o]))}return i}function i(n,r){return t.map(n,function(t){return e(t,r)})}var a=/^(%20|\s)*(javascript|data)/im,u=/[^\x20-\x7E]/gim,o=/^([^:]+):/gm,c=[".","/"];return{sanitizeUrl:r,sanitizeObject:e,sanitizeCollection:i}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:utils', location = 'jira-development-integration-plugin/js/util/ES6Utils.js' */
"use strict";define("jira/dev-status/util/es6",["exports"],function(e){e.stringStartsWith=function(e,t){return e.slice(0,0+t.length)===t},e.findIndex=function(e,t){for(var n=0;n<e.length;++n)if(t(e[n]))return n;return-1},e.requestIdleCallback=function(e){"requestIdleCallback"in window?window.requestIdleCallback(e):setTimeout(e)}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/templates/repository-shortcuts/repository-shortcuts.soy' */
// This file was automatically generated from repository-shortcuts.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Software.RepositoryShortcuts.Templates.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Software == 'undefined') { JIRA.Software = {}; }
if (typeof JIRA.Software.RepositoryShortcuts == 'undefined') { JIRA.Software.RepositoryShortcuts = {}; }
if (typeof JIRA.Software.RepositoryShortcuts.Templates == 'undefined') { JIRA.Software.RepositoryShortcuts.Templates = {}; }


JIRA.Software.RepositoryShortcuts.Templates.content = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.canManageShortcuts || opt_data.numberOfShortcuts > 0) {
    output += '<div class="aui-sidebar-group jira-sidebar-group-with-divider repo-shortcuts-group' + ((opt_data.numberOfShortcuts == 0) ? ' repo-shortcuts-group_empty' : '') + '" data-id="repo-shortcuts-group"><div class="aui-nav-heading">' + soy.$$escapeHtml('Source code') + '</div><ul class="aui-nav repo-shortcuts-list">';
    if (opt_data.shortcuts) {
      var shortcutList14 = opt_data.shortcuts;
      var shortcutListLen14 = shortcutList14.length;
      for (var shortcutIndex14 = 0; shortcutIndex14 < shortcutListLen14; shortcutIndex14++) {
        var shortcutData14 = shortcutList14[shortcutIndex14];
        output += JIRA.Software.RepositoryShortcuts.Templates.shortcut({canManageShortcuts: opt_data.canManageShortcuts, canManageDVCS: opt_data.canManageDVCS, id: shortcutData14.id, name: shortcutData14.name, url: shortcutData14.url, dvcsType: shortcutData14.dvcsType, shouldWarnPotentialConnection: shortcutData14.shouldWarnPotentialConnection, isFirstSyncRunning: shortcutData14.isFirstSyncRunning});
      }
    }
    output += ((opt_data.canManageShortcuts) ? '<li><a class="aui-nav-item repo-shortcuts-group__add" href="#" data-link-id="repo-shortcut-add">' + aui.icons.icon({useIconFont: true, size: 'large', icon: 'add-small'}) + '<span class="aui-nav-item-label">' + soy.$$escapeHtml('Add source code') + '</span></a></li>' : '') + '</ul></div>';
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.content.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.content';
}


JIRA.Software.RepositoryShortcuts.Templates.shortcut = function(opt_data, opt_ignored) {
  var output = '';
  var imgBaseUrl__soy37 = "" + '/download/resources/com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts/images';
  output += '<li class="repo-shortcut"><a class="aui-nav-item repo-shortcuts-group__link" href="' + soy.$$escapeHtml(opt_data.url) + '" title="' + soy.$$escapeHtml(opt_data.name) + '" target="_blank" data-shortcut-id="' + soy.$$escapeHtml(opt_data.id) + '" data-link-id="repo-shortcut-' + soy.$$escapeHtml(opt_data.id) + '">' + ((opt_data.dvcsType == 'bitbucket') ? '<span class="aui-icon aui-icon-large aui-iconfont-bitbucket">' + soy.$$escapeHtml('Bitbucket source code link') + '</span>' : (opt_data.dvcsType == 'github') ? '<img class="aui-icon" src="' + soy.$$escapeHtml(imgBaseUrl__soy37) + '/octocat-icon.svg" alt="' + soy.$$escapeHtml('GitHub source code link') + '" />' : '<span class="aui-icon aui-icon-large aui-iconfont-link">' + soy.$$escapeHtml('Unknown source code link') + '</span>') + '<span class="aui-nav-item-label">' + soy.$$escapeHtml(opt_data.name) + '</span></a>' + ((opt_data.canManageShortcuts) ? '<a href="#repo-shortcuts-dropdown_' + soy.$$escapeHtml(opt_data.id) + '" aria-owns="repo-shortcuts-dropdown_' + soy.$$escapeHtml(opt_data.id) + '" aria-haspopup="true" class="aui-dropdown2-trigger repo-shortcuts-group__actions" style="' + ((opt_data.isFirstSyncRunning || opt_data.shouldWarnPotentialConnection) ? 'right: 40px' : '') + '"><span>' + soy.$$escapeHtml('Actions') + '</span></a><div id="repo-shortcuts-dropdown_' + soy.$$escapeHtml(opt_data.id) + '" class="aui-dropdown2 aui-style-default repo-shortcuts-group__dropdown"><ul class="aui-list-truncate">' + ((opt_data.shouldWarnPotentialConnection) ? '' : '') + '<li><a class="repo-shortcuts-group__actions__edit" href="#">' + soy.$$escapeHtml('Edit') + '</a></li><li><a class="repo-shortcuts-group__actions__delete" href="#">' + soy.$$escapeHtml('Delete') + '</a></li></ul></div>' : '') + ((opt_data.isFirstSyncRunning) ? '<a class="repo-shortcuts-group__warning syncing-trigger" href="#syncing-dialog-' + soy.$$escapeHtml(opt_data.id) + '" data-aui-trigger aria-controls="syncing-dialog-' + soy.$$escapeHtml(opt_data.id) + '"><span class="aui-icon aui-icon-small aui-iconfont-warning" original-title="warning">$' + soy.$$escapeHtml('Sync in progress') + '</span></a>' + JIRA.Software.RepositoryShortcuts.Templates.syncInProgressDialog(opt_data) : '') + ((opt_data.shouldWarnPotentialConnection) ? '<a class="repo-shortcuts-group__warning suggest-connection-trigger" href="#suggest-connection-dialog-' + soy.$$escapeHtml(opt_data.id) + '" data-aui-trigger aria-controls="suggest-connection-dialog-' + soy.$$escapeHtml(opt_data.id) + '"><span class="aui-icon aui-icon-small aui-iconfont-warning" original-title="warning">$' + soy.$$escapeHtml('Sync in progress') + '</span></a>' : '') + '</li>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.shortcut.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.shortcut';
}


JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields = function(opt_data, opt_ignored) {
  var output = '<div class="repo-shortcuts-field-group">';
  var urlErrorId__soy112 = 'repo-shortcuts-url-error';
  var nameErrorId__soy113 = 'repo-shortcuts-name-error';
  var nameLabelText__soy114 = opt_data.nameLabel ? opt_data.nameLabel : 'Label';
  output += aui.form.textField({name: 'repo-shortcuts-url-' + opt_data.action, id: 'repo-shortcuts-url-' + opt_data.action, labelContent: opt_data.urlLabel ? opt_data.urlLabel : 'Repo link', extraClasses: 'repo-shortcuts-url', value: opt_data.url ? opt_data.url : '', isRequired: true, errorTexts: opt_data.errors.urlError ? [opt_data.errors.urlError] : [], errorId: urlErrorId__soy112, descriptionContent: '<div id="repo-shortcuts-url-description">' + 'Eg. https://bitbucket.org/org/projectrepository' + '</div>', extraInputAttributes: {'aria-describedby': urlErrorId__soy112 + ' repo-shortcuts-url-description', 'aria-required': true}}) + '<div class="field-group repo-shortcuts-name">' + aui.form.label({forField: 'repo-shortcuts-name-' + opt_data.action, content: nameLabelText__soy114 + '<span class="aui-icon icon-required"></span>'}) + '<div class="repo-shortcuts-name-icon-block"><div class="repo-shortcuts-icon-picker-block"></div>' + aui.form.input({name: 'repo-shortcuts-name-' + opt_data.action, id: 'repo-shortcuts-name-' + opt_data.action, extraClasses: 'repo-shortcuts-name-input' + (opt_data.isWithIcon ? ' repo-shortcuts-name-input-with-icon' : ''), value: opt_data.name ? opt_data.name : '', type: 'text', extraAttributes: {'aria-describedby': nameErrorId__soy113 + ' repo-shortcuts-name-description', 'aria-required': true}}) + '<div id="repo-shortcuts-name-description" class="description">' + soy.$$escapeHtml('Eg. Project repository') + '</div></div>' + ((opt_data.errors.iconError) ? aui.form.fieldError({message: opt_data.errors.iconError}) : '') + ((opt_data.errors.nameError) ? aui.form.fieldError({message: opt_data.errors.nameError, id: nameErrorId__soy113}) : '') + '</div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields';
}


JIRA.Software.RepositoryShortcuts.Templates.addDialog = function(opt_data, opt_ignored) {
  return '<div class="repo-shortcuts-header-image add-repo"></div><form action="" method="post" class="aui"><h3>' + soy.$$escapeHtml('Create a repo link') + '</h3><p>' + soy.$$escapeHtml('Add a link to this project\x27s repo so your team can easily find their code.') + '</p><fieldset>' + JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields(soy.$$augmentMap(opt_data, {action: 'add'})) + '<div class="buttons-container"><div class="buttons repo-shortcuts-buttons">' + aui.buttons.button({text: 'Link repo', type: 'primary', extraClasses: 'repo-shortcuts-submit'}) + aui.buttons.button({text: 'Cancel', type: 'link', extraClasses: 'repo-shortcuts-cancel'}) + '</div></div></fieldset></form>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.addDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.addDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.adg3ManageShortcutDialog = function(opt_data, opt_ignored) {
  return '<section role="dialog" id="' + soy.$$escapeHtml(opt_data.isAddDialog ? 'add-repository-dialog' : 'edit-repository-dialog') + '" class="aui-layer aui-dialog2 aui-dialog2-medium" aria-hidden="false"><header class="aui-dialog2-header" id="manage-shortcut-dialog-header"></header><div class="aui-dialog2-content"><div id="image-behind"><div id="image-behind-top"></div><div id="image-behind-bottom"></div></div><div id="manage-repository-image-container"><div id="manage-repository-dialog-image"></div></div><form action="" method="post" class="aui"><h1 id="manage-repository-dialog-title">' + soy.$$escapeHtml(opt_data.isAddDialog ? 'Connect a repository' : 'Edit repository') + '</h1><p id="manage-repository-dialog-description">' + soy.$$escapeHtml('Linking a repository will show information about your branches, commits and pull requests in Jira issues.') + '</p><p id="manage-repository-mandatory-fields-description" aria-hidden="true">' + soy.$$escapeHtml('Required fields are marked with an asterisk') + ' <span class="aui-icon icon-required"></span></p><fieldset>' + JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields(soy.$$augmentMap(opt_data, {action: opt_data.isAddDialog ? 'add' : 'edit', urlLabel: 'Repository link', nameLabel: 'Name'})) + '</fieldset><button type="submit" class="repo-shortcuts-hidden-submit" tabindex="-1" aria-hidden="true"></button></form></div><div class="aui-dialog2-footer"><div class="buttons-container"><div class="buttons">' + ((! opt_data.isAddDialog) ? '<button class="aui-button repo-shortcuts-delete">' + soy.$$escapeHtml('Delete') + '</button>' : '') + '<button class="aui-button aui-button-primary repo-shortcuts-submit">' + soy.$$escapeHtml(opt_data.isAddDialog ? 'Connect' : 'Update') + '</button><button class="aui-button aui-button-text aui-button-subtle repo-shortcuts-cancel">' + soy.$$escapeHtml('Cancel') + '</button></div></div></div></section>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.adg3ManageShortcutDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.adg3ManageShortcutDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.adg3AddDialog = function(opt_data, opt_ignored) {
  return '' + JIRA.Software.RepositoryShortcuts.Templates.adg3ManageShortcutDialog(soy.$$augmentMap(opt_data, {isAddDialog: true}));
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.adg3AddDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.adg3AddDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.adg3EditDialog = function(opt_data, opt_ignored) {
  return '' + JIRA.Software.RepositoryShortcuts.Templates.adg3ManageShortcutDialog(soy.$$augmentMap(opt_data, {isAddDialog: false}));
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.adg3EditDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.adg3EditDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.suggestConnectionDialog = function(opt_data, opt_ignored) {
  return '<div class="repo-shortcuts-header-image connection-request"></div><h3 class="repo-shortcuts-connectionRequestHeading">' + soy.$$escapeHtml('Linked but not integrated') + '</h3><p class="repo-shortcuts-connectionRequestDescription">' + soy.$$escapeHtml(AJS.format('Your repo is now linked, but your team can get visibility of development progress in their issues when {0} and Jira are integrated.',opt_data.dvcsName)) + '</p>' + ((opt_data.isIntegration) ? aui.buttons.button({text: AJS.format('Integrate Jira with {0}',opt_data.dvcsName), type: 'primary', extraClasses: 'repo-connection-start'}) : aui.buttons.button({text: 'Sync repository with Jira', type: 'primary', extraClasses: 'repo-connection-start'})) + aui.buttons.button({text: 'No thanks', type: 'link', extraClasses: 'repo-connection-cancel'});
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.suggestConnectionDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.suggestConnectionDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.syncInProgressDialog = function(opt_data, opt_ignored) {
  return '<aui-inline-dialog id="syncing-dialog-' + soy.$$escapeHtml(opt_data.id) + '" class="repo-shortcuts-syncing-dialog" responds-to="hover"><div class="repo-shortcuts-syncing-dialog-header"></div><h3>' + soy.$$escapeHtml(AJS.format('Syncing Jira with {0}',opt_data.dvcsType)) + '</h3><p>' + soy.$$escapeHtml(AJS.format('We\x27re busy syncing Jira with {0} larger repos will take an hour or two. Once done, your team will',opt_data.dvcsType)) + '&nbsp;<a href="https://confluence.atlassian.com/display/JIRASOFTWARECLOUD/Using+JIRA+applications+with+Bitbucket+Cloud">' + soy.$$escapeHtml('enjoy greater confidence') + '</a>&nbsp;' + soy.$$escapeHtml('in their development process, and they can start') + '&nbsp;<a href="https://confluence.atlassian.com/display/BITBUCKET/Processing+JIRA+Software+issues+with+Smart+Commit+messages">' + soy.$$escapeHtml('using issue keys') + '</a>&nbsp;' + soy.$$escapeHtml('in commit messages right now!') + '</p>' + ((opt_data.canManageDVCS) ? aui.buttons.button({text: 'See syncing progress', type: 'link', href: '/secure/admin/ConfigureDvcsOrganizations!default.jspa'}) : '') + '</aui-inline-dialog>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.syncInProgressDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.syncInProgressDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.editDialogChrome = function(opt_data, opt_ignored) {
  return '<section role="dialog" id="edit-repo-shortcuts-dialog" class="aui-layer aui-dialog2 aui-dialog2-small" aria-hidden="true" data-aui-remove-on-hide="true"><header class="aui-dialog2-header"><h2 class="aui-dialog2-header-main">' + soy.$$escapeHtml('Edit repo link') + '</h2></header></section>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.editDialogChrome.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.editDialogChrome';
}


JIRA.Software.RepositoryShortcuts.Templates.editDialog = function(opt_data, opt_ignored) {
  return '<div class="aui-dialog2-content"><form class="aui" method="post">' + JIRA.Software.RepositoryShortcuts.Templates.shortcutFormFields(soy.$$augmentMap(opt_data, {action: 'edit'})) + '<button type="submit" class="repo-shortcuts-hidden-submit" tabindex="-1" aria-hidden="true"></button></form></div><footer class="aui-dialog2-footer"><div class="aui-dialog2-footer-actions">' + aui.buttons.button({text: 'Save', type: 'primary', extraClasses: 'repo-shortcuts-submit'}) + aui.buttons.button({text: 'Cancel', type: 'link', extraClasses: 'repo-shortcuts-cancel'}) + '</div></footer>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.editDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.editDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.deleteDialog = function(opt_data, opt_ignored) {
  return '<section role="dialog" id="delete-repo-shortcuts-dialog" class="aui-layer aui-dialog2 aui-dialog2-small" aria-hidden="true" data-aui-remove-on-hide="true"><header class="aui-dialog2-header"><h2 class="aui-dialog2-header-main">' + soy.$$escapeHtml('Delete repo link') + '</h2></header><div class="aui-dialog2-content"><p>' + soy.$$escapeHtml('Are you sure you want to delete this repo link?') + '</p></div><footer class="aui-dialog2-footer"><div class="aui-dialog2-footer-actions">' + aui.buttons.button({text: 'Delete', type: 'primary', extraClasses: 'repo-shortcuts-submit'}) + aui.buttons.button({text: 'Cancel', type: 'link', extraClasses: 'repo-shortcuts-cancel'}) + '</div></footer></section>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.deleteDialog.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.deleteDialog';
}


JIRA.Software.RepositoryShortcuts.Templates.modalValuePropContent = function(opt_data, opt_ignored) {
  var output = '';
  var imgBaseUrl__soy278 = "" + '/download/resources/com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts/images';
  output += '<div class="aui-dialog2-content"><img src="' + soy.$$escapeHtml(imgBaseUrl__soy278) + '/integrate-product-with-jira.svg" style="width: 100%" /><div class="description-container">' + ((opt_data.canUserManageDVCSAccounts && ! opt_data.isIntegration) ? '<p>' + soy.$$escapeHtml(AJS.format('A shortcut to your {0} repository has been created.',opt_data.dvcsName)) + '</p><p>' + soy.$$escapeHtml(AJS.format('Next, sync your Jira Cloud and {0} repository.',opt_data.dvcsName)) + '</p>' : '') + '</div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.modalValuePropContent.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.modalValuePropContent';
}


JIRA.Software.RepositoryShortcuts.Templates.integrationModalContent = function(opt_data, opt_ignored) {
  return '<header class="aui-dialog2-header"><h2 class="aui-dialog2-header-main" style="overflow: visible">' + ((opt_data.isIntegration) ? soy.$$escapeHtml(AJS.format('Integrate Jira with {0}',opt_data.dvcsName)) : soy.$$escapeHtml('Sync repository with Jira')) + '</h2></header>' + JIRA.Software.RepositoryShortcuts.Templates.modalValuePropContent(opt_data) + '<footer class="aui-dialog2-footer"><div class="aui-dialog2-footer-actions">' + ((opt_data.canUserManageDVCSAccounts && opt_data.isIntegration) ? aui.buttons.button({text: AJS.format('Integrate with {0}',opt_data.dvcsName), type: 'primary', extraClasses: 'repo-connect-start'}) : (opt_data.canUserManageDVCSAccounts && ! opt_data.isIntegration) ? aui.buttons.button({text: 'Start syncing', type: 'primary', extraClasses: 'repo-connect-start'}) : '<div></div>') + ((opt_data.canUserManageDVCSAccounts) ? aui.buttons.button({text: 'Edit repository', type: 'link', extraClasses: 'repo-connect-edit aui-button-subtle'}) : aui.buttons.button({text: 'Maybe later', type: 'link', extraClasses: 'repo-connect-cancel'})) + '</div></footer>';
};
if (goog.DEBUG) {
  JIRA.Software.RepositoryShortcuts.Templates.integrationModalContent.soyTemplateName = 'JIRA.Software.RepositoryShortcuts.Templates.integrationModalContent';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/services/URLMatcher.js' */
"use strict";define("repository-shortcuts/services/url-matcher",[],function(){return{parseUrl:function(t){function s(t,s,e){if(t&&t[1]&&s.indexOf(t[1])===-1&&e.indexOf(t[2])===-1)return{dvcsOrg:t[1],dvcsRepo:t[2]}}function e(){var e=/https:\/\/bitbucket\.org(?:\/([^\/\?#]+)(?:\/([^\/\?#]+))?)?/,r=t.match(e),c=["snippets","account","dashboard"],i=["profile"];return s(r,c,i)}function r(){var e=/https:\/\/github\.com(?:\/([^\/\?#]+)(?:\/([^\/\?#]+))?)?/,r=t.match(e),c=["pulls","issues","notifications","explore","integrations","settings","blog","about","site","security"],i=[];return s(r,c,i)}if("string"!=typeof t)throw new Error("parseUrl expects URLs to be strings");return e()?{dvcsType:"bitbucket",dvcsOrg:e().dvcsOrg,dvcsRepo:e().dvcsRepo}:r()?{dvcsType:"github",dvcsOrg:r().dvcsOrg,dvcsRepo:r().dvcsRepo}:{dvcsType:"unsupported"}}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/services/DVCSAccountMatcher.js' */
"use strict";define("repository-shortcuts/services/dvcs-account-matcher",["jquery","underscore","wrm/context-path","repository-shortcuts/services/url-matcher"],function(t,e,r,n){var s=window.Promise;return{matchUrlAgainstNetwork:function(c){function i(n){var c=r()+"/rest/bitbucket/1.0/repository/summary/find?type="+n.dvcsType+"&orgName="+n.dvcsOrg+"&repoSlug="+n.dvcsRepo;return s.resolve(t.get(c)).then(function(t){return e.extend({},n,t)})["catch"](function(t){return t&&404===t.status?o(n):n})}function o(e){var n=r()+"/rest/bitbucket/1.0/organization/find?name="+e.dvcsOrg+"&type="+e.dvcsType;return s.resolve(t.get(n)).then(function(t){var r=t.dvcsType,n=t.name,s=t.approvalState,c=r===e.dvcsType,i=n===e.dvcsOrg,o="APPROVED"===s;return e.isOrganisationLinked=c&&i&&o,e})["catch"](function(t){return e})}function u(e){var n=r()+"/rest/devinfoadmin/1.0/githubAppDetails";return s.resolve(t.get(n)).then(function(t){var r=t.githubAppInstalled;return r&&(e.isOrganisationLinked=!0,e.isRepositoryLinked=!0),e.githubAppInstalled=r,e})["catch"](function(t){return e})}try{var a=n.parseUrl(c);return"unsupported"===a.dvcsType?s.resolve(a):"github"===a.dvcsType?u(a):a.dvcsRepo?i(a):o(a)}catch(p){return s.reject(p)}}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/services/DVCSIntegrator.js' */
"use strict";define("repository-shortcuts/services/dvcs-integrator",["jquery","bluebird/Promise","wrm/context-path","aui/flag"],function(t,e,o,n){function r(r){var i=r.dvcsRepoId,a=r.dvcsRepo;return e.resolve(t.ajax({type:"POST",contentType:"application/json",url:o()+"/rest/bitbucket/1.0/repo/"+i+"/autolink",data:JSON.stringify({payload:!0})})).then(function(){t.ajax({type:"POST",url:o()+"/rest/bitbucket/1.0/repository/"+i+"/softsync"}),n({type:"success",title:"You have added the repository",body:"Nicely done! Your team is going to love this.",close:"auto"})})["catch"](function(t){return n({type:"error",body:AJS.format("Failed to link \u003cstrong\u003e{0}\u003c/strong\u003e repo with Jira",a)}),e.reject(t)})}function i(t){if(void 0===t)return"";var e=t.length;if(0===e)return"";if(1===e)return"/"===t?"":t;var o="/"===t.charAt(0),n="/"===t.charAt(e-1);return t.substring(o?1:0,n?e-1:e)}function a(t,e,o,n,r){var a=i(n),c=t+"//"+i(e)+"/"+i(o),s=i(c);return s+"/"+a+"?atl_token="+r}function c(t){var e=""+o(),n=window.location.host,r=window.location.protocol,i=a(r,n,e,s,t);window.location.href=i}var s="/plugins/servlet/upm/marketplace/plugins/com.github.integration.production";return{startBBOrganisationLink:function(t){var e=""+window.location.origin+o(),n=e+"/rest/aci/1.0/installation/jira-bitbucket-connector-plugin/descriptor",r=document.getElementById("atlassian-token").getAttribute("content"),i=e+"/secure/BitbucketPostInstallApprovalAction.jspa?jiraInitiated=true&customReturnUrl="+(window.location.href+"&atl_token="+r),a="https://bitbucket.org/site/addons/authorize";window.location.href=a+"?account="+t+"&descriptor_uri="+encodeURIComponent(n)+"&redirect_uri="+encodeURIComponent(i)},startBBRepositoryLink:function(t){var e=t.dvcsRepoId,o=t.dvcsRepo;return r({dvcsRepoId:e,dvcsRepo:o})},startGithubOrganisationLink:function(){var t=document.getElementById("atlassian-token").getAttribute("content");c(t)},startGithubRepositoryLink:function(t){var e=(t.dvcsRepoId,t.dvcsRepo,document.getElementById("atlassian-token").getAttribute("content"));c(e)},normalize:function(t){return i(t)},buildAbsoluteAddOnMarketplaceUrl:function(t,e,o,n,r){return a(t,e,o,n,r)}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/services/RepoShortcutUpdateHandler.js' */
"use strict";define("repository-shortcuts/services/repo-shortcut-update-handler",["repository-shortcuts/views/connection-modal","aui/flag"],function(e,t){return function(t,r){t.attributes;if(!t.hasLinkedAllComponents()){var o={repoShortcutModel:t,canUserManageDVCSAccounts:r},n=new e(o);r&&n.render()}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/models/RepositoryShortcut.js' */
"use strict";define("repository-shortcuts/models/repository-shortcut",[],function(){return JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcut.extend({defaults:{url:"",name:"",icon:"",type:"source.code.link",dvcsType:"unsupported",isPendingApproval:!1,dvcsOrg:void 0,dvcsRepo:void 0,dvcsRepoId:void 0,isOrganisationLinked:void 0,isRepositoryLinked:void 0,isFirstSyncRunning:void 0,githubAppInstalled:!1},clear:function(){this.unset("id"),this.set(this.defaults)},hasLinkedOrg:function(){var t=this.attributes;return t.dvcsOrg&&t.isOrganisationLinked},hasNotLinkedOrg:function(){var t=this.attributes;return t.dvcsOrg&&!t.isOrganisationLinked},hasLinkedOrgAndNotRepo:function(){var t=this.attributes;return this.hasLinkedOrg()&&t.dvcsRepo&&!t.isRepositoryLinked},isGithub:function(){var t=this.attributes;return"github"===t.dvcsType},hasLinkedAllComponents:function(){function t(){return s.dvcsRepo&&s.isRepositoryLinked}function i(){return!s.dvcsRepo}var s=this.attributes;return this.isGithub()?s.githubAppInstalled:this.hasLinkedOrg()&&(t()||i())}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/models/RepositoryShortcuts.js' */
"use strict";define("repository-shortcuts/models/repository-shortcuts",["repository-shortcuts/models/repository-shortcut"],function(t){return JIRA.Projects.Sidebar.ProjectShortcuts.Entities.Shortcuts.extend({model:t,initialize:function(t,e){var i=this;this.projectKey=e.projectKey,this.canUserManageDVCSAccounts=e.canUserManageDVCSAccounts,this.listenTo(this,"dvcsremote:change",function(t){i._handleRepoLinkChangeOrAdd(t)})},_handleRepoLinkChangeOrAdd:function(t){var e=function(t,e){return t.get("dvcsType")===e.get("dvcsType")&&t.get("dvcsOrg")===e.get("dvcsOrg")},i=function(t,i){return e(t,i)&&t.get("dvcsRepo")===i.get("dvcsRepo")};this.forEach(function(n){t.id!==n.id&&(i(t,n)?n.set({isOrganisationLinked:t.get("isOrganisationLinked"),isRepositoryLinked:t.get("isRepositoryLinked"),dvcsRepoId:t.get("dvcsRepoId"),isFirstSyncRunning:t.get("isFirstSyncRunning")}):e(t,n)&&n.set({isOrganisationLinked:t.get("isOrganisationLinked")}))})}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/RepositoryShortcutsList.js' */
"use strict";define("repository-shortcuts/views/repository-shortcut-list",["jquery","repository-shortcuts/views/repository-shortcut","repository-shortcuts/dialogs/add"],function(t,e,o){return JIRA.Projects.Sidebar.ProjectShortcuts.Views.List.extend({template:JIRA.Software.RepositoryShortcuts.Templates.content,childView:e,ui:{itemsContainer:".aui-nav",add:".repo-shortcuts-group__add"},collectionEvents:{add:function(){0!==this.collection.length&&this.$el.hasClass("repo-shortcuts-group_empty")&&this.$el.removeClass("repo-shortcuts-group_empty")},remove:function(){0!==this.collection.length||this.$el.hasClass("repo-shortcuts-group_empty")||this.$el.addClass("repo-shortcuts-group_empty")}},initialize:function(){var e=this;JIRA.API.getSidebar().done(function(o){var r=o.getAUISidebar(!0);r.on("expand-end",function(){t(".aui-sidebar-submenu-dialog .repo-shortcuts-group__dropdown").remove(),t(".aui-sidebar-submenu-dialog .repo-shortcuts-syncing-dialog").remove()}),r.on("collapse-start",function(){e.$(".repo-shortcuts-group__actions.aui-dropdown2-active").trigger("aui-button-invoke"),e._addConnectionsAvailableMarkerOnSidebarIcon()})})},onRender:function(){var t=this,e=new o({sidebarItem:JIRA.API.Sidebar.getGroup(this.options.targetGroup,!0).getItem("repo-shortcut-add"),projectKey:this.collection.projectKey,collection:this.collection}),r=JIRA.API.Projects.getCurrentProjectId();this.listenTo(e,"dialog:open",function(){t.trigger("add:open"),AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.add-link.click",data:{projectId:r}})}),this.listenTo(e,"dialog:close",function(e){t.trigger("add:close",e),AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.add-link.close",data:{projectId:r,isSave:e}})}),this._addConnectionsAvailableMarkerOnSidebarIcon()},serializeData:function(){return{canManageShortcuts:!0,numberOfShortcuts:this.collection.length}},_addConnectionsAvailableMarkerOnSidebarIcon:function(){var t=this.collection.some(function(t){return t.hasNotLinkedOrg()||t.hasLinkedOrgAndNotRepo()});t&&this.$el.addClass("connections-available")}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/RepositoryShortcut.js' */
"use strict";define("repository-shortcuts/views/repository-shortcut",["jquery","underscore","repository-shortcuts/dialogs/connection","repository-shortcuts/dialogs/edit","repository-shortcuts/services/dvcs-integrator"],function(e,t,o,r,i){function n(e){return"bitbucket"===e||"github"===e}return JIRA.Projects.Sidebar.ProjectShortcuts.Views.Shortcut.extend({template:JIRA.Software.RepositoryShortcuts.Templates.shortcut,initialize:function(){t.bindAll(this,"toggleDropdown")},ui:{integrate:".repo-shortcuts-group__actions__integrate",del:".repo-shortcuts-group__actions__delete",edit:".repo-shortcuts-group__actions__edit",trigger:".repo-shortcuts-group__actions",dropdown:".repo-shortcuts-group__dropdown",link:".repo-shortcuts-group__link",connectionDialogTrigger:".suggest-connection-trigger"},templateHelpers:function(){var e=this.model.attributes,t=this.model.collection.canUserManageDVCSAccounts,o=n(e.dvcsType);if(t&&this.model.isGithub()){var r=e.githubAppInstalled;return{warnOnGithubConnection:r}}var i=!(!e.isOrganisationLinked||e.dvcsRepo&&!e.isRepositoryLinked),s=t&&o&&!i;return{shouldWarnPotentialConnection:s}},onRender:function(){this.unwrapTemplate();var t=this,n=e(window),s=e(".aui-sidebar-body");new o({$trigger:this.ui.connectionDialogTrigger,repoShortcutModel:this.model}),this.ui.integrate.on("click",function(e){var o=t.model.attributes;if(e.preventDefault(),t.ui.trigger.blur(),"bitbucket"===o.dvcsType&&t.model.hasNotLinkedOrg())i.startBBOrganisationLink(o.dvcsOrg);else if("bitbucket"===o.dvcsType&&t.model.hasLinkedOrgAndNotRepo())i.startBBRepositoryLink(t.model.attributes).then(function(){t.model.set({isRepositoryLinked:!0}),t.model.trigger("dvcsremote:change",t.model)});else{if("github"!==o.dvcsType)throw"Unsupported DVCS Type";o.githubAppInstalled||i.startGithubOrganisationLink()}}),this.ui.edit.on("click",function(e){e.preventDefault(),t.ui.trigger.blur();var o=new r({repoShortcutModel:t.model,canUserManageDVCSAccounts:t.model.collection.canUserManageDVCSAccounts});t.trigger("edit:open",t.model),t.listenToOnce(o,"dialog:close",function(e){t.trigger("edit:close",t.model,e)})}),this.ui.del.on("click",function(e){e.preventDefault(),t.ui.trigger.blur(),new JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete({model:t.model})}),this.ui.dropdown.on({"aui-dropdown2-show":function(){t.$el.addClass("aui-nav-selected"),s.one("scroll",t.toggleDropdown),n.one("scroll",t.toggleDropdown),t.ui.trigger.focus()},"aui-dropdown2-hide":function(){t.$el.removeClass("aui-nav-selected"),s.off("scroll",t.toggleDropdown),n.off("scroll",t.toggleDropdown)}}),this.ui.connectionDialogTrigger.on("click",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.warning.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutId:t.model.id}})}),this.ui.link.on("click",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.shortcut.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutId:t.model.id,shortcutType:t.model.dvcsType}})})},serializeData:function(){var e=t.extend(this.model.toJSON(),{canManageShortcuts:!0,canManageDVCS:this.model.collection.canUserManageDVCSAccounts});return e}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/DialogContent.js' */
"use strict";define("repository-shortcuts/views/dialog-content",["repository-shortcuts/services/url-matcher","repository-shortcuts/services/dvcs-account-matcher"],function(t,e){var r=JIRA.Projects.Sidebar.ProjectShortcuts.Views.DialogContent;return r.extend({ui:{form:"form",inputs:"input, button",submit:".repo-shortcuts-submit",cancel:".repo-shortcuts-cancel",url:".repo-shortcuts-url input",name:".repo-shortcuts-name input"},events:{"click @ui.cancel":function(t){t.preventDefault(),this.model.clear(),this.setNameAutomagically=!0,this.errorModel.clear(),this.trigger("cancel")},"click @ui.submit":"_handleFormSubmit","submit @ui.form":"_handleFormSubmit","blur @ui.url":function(){this.ensureProtocolPrefix(),this.tryToAutomagicallyDeriveNameFromUrl()},"input @ui.url":function(){this.model.set("url",this.ui.url.val()),this.tryToAutomagicallyDeriveNameFromUrl()},"input @ui.name":function(){this.setNameAutomagically=!1,this.model.set("name",this.ui.name.val())}},initialize:function(t){var e=t.errorModel,r=t.canUserManageDVCSAccounts;this.canUserManageDVCSAccounts=r,this.errorModel=e;var i=this.model.get("name");this.setNameAutomagically=0===i.length},serializeData:function(){return _.extend(this.model.toJSON(),{errors:this.errorModel.toJSON(),action:this.action})},onRender:function(){},hideIconPicker:function(){},_handleFormSubmit:function(r){var i=this,o=function(t){i.model.set({url:i.ui.url.val(),name:i.ui.name.val()}),i.model.set(t),i.model.save()};r.preventDefault(),this.ensureProtocolPrefix(),this.tryToAutomagicallyDeriveNameFromUrl(),this.model.set(this.model.defaults);var s=this.ui.url.val();if(this.canUserManageDVCSAccounts)e.matchUrlAgainstNetwork(s).then(function(t){return o(t)})["catch"](function(){return o({})});else{var a=t.parseUrl(s);o(a)}},tryToAutomagicallyDeriveNameFromUrl:function(){var e=this.ui.url.val().trim();if(this.setNameAutomagically){var i=t.parseUrl(e);if(i.dvcsRepo)this.setName(i.dvcsRepo);else{if(!i.dvcsOrg)return r.prototype.tryToAutomagicallyDeriveNameFromUrl.call(this);this.setName(i.dvcsOrg)}}}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/AddDialogContent.js' */
"use strict";define("repository-shortcuts/views/add-dialog-content",["repository-shortcuts/views/dialog-content"],function(t){var e=JIRA.Software.RepositoryShortcuts.Templates.adg3AddDialog;return t.extend({template:e})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/EditDialogContent.js' */
"use strict";define("repository-shortcuts/views/edit-dialog-content",["repository-shortcuts/views/dialog-content"],function(t){return t.extend({template:JIRA.Software.RepositoryShortcuts.Templates.adg3EditDialog,ui:_.extend({},t.prototype.ui,{"delete":".repo-shortcuts-delete"})})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/ConnectionDialogContent.js' */
"use strict";define("repository-shortcuts/views/connection-dialog-content",["repository-shortcuts/services/dvcs-integrator"],function(t){return JIRA.Projects.Libs.Marionette.ItemView.extend({template:JIRA.Software.RepositoryShortcuts.Templates.suggestConnectionDialog,ui:{start:".repo-connection-start",cancel:".repo-connection-cancel"},events:{"click @ui.start":function(t){t.preventDefault(),this.triggerSubmitAnalyticEvent(),this.startConnection(),this.trigger("connection:start")},"click @ui.cancel":function(t){t.preventDefault(),this.triggerCancelAnalyticEvent(),this.trigger("connection:cancel")}},triggerSubmitAnalyticEvent:function(){this.isIntegration?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.inline-integrate.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.inline-sync.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}})},triggerCancelAnalyticEvent:function(){this.isIntegration?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.inline-integrate.cancel",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.inline-sync.cancel",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}})},templateHelpers:function(){return{dvcsName:this.dvcsName,isIntegration:this.isIntegration}},initialize:function(e){var n=e.repoShortcutModel,i=function(t){t.set({isRepositoryLinked:!0}),t.trigger("dvcsremote:change",t)},r=n.attributes;if(this.dvcsName="bitbucket"===r.dvcsType?"Bitbucket":"GitHub",this.isIntegration=n.hasNotLinkedOrg(),"bitbucket"===r.dvcsType&&n.hasNotLinkedOrg())this.startConnection=function(){return t.startBBOrganisationLink(r.dvcsOrg)};else if("bitbucket"===r.dvcsType&&n.hasLinkedOrgAndNotRepo())this.startConnection=function(){t.startBBRepositoryLink(n.attributes).then(function(){return i(n)})};else{if("github"!==r.dvcsType)throw"Unsupported DVCS Type";r.githubAppInstalled||(this.startConnection=function(){t.startGithubOrganisationLink()})}}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/views/modal-dialogs/ConnectionModal.js' */
"use strict";define("repository-shortcuts/views/connection-modal",["underscore","aui/flag","repository-shortcuts/services/dvcs-integrator"],function(t,e,i){var n="aui-dialog2-small";return JIRA.Projects.Libs.Marionette.ItemView.extend({template:JIRA.Software.RepositoryShortcuts.Templates.integrationModalContent,tagName:"section",attributes:{role:"dialog","class":"aui-layer aui-dialog2 "+n+" repo-integration-dialog","aria-hidden":"true","data-aui-modal":"false","data-aui-focus-selector":".aui-dialog2-content .repo-connect-start"},ui:{submit:".repo-connect-start",cancel:".repo-connect-cancel",edit:".repo-connect-edit"},events:{"click @ui.submit":function(t){t.preventDefault(),this.triggerSubmitAnalyticEvent(),this.handleSubmit()},"click @ui.cancel":function(t){t.preventDefault(),this.triggerCancelAnalyticEvent(),this._removeAndHide()},"click @ui.edit":function(t){t.preventDefault(),this._removeAndHide(),this.triggerEditAnalyticEvent(),this.repoShortcutModel.trigger("edit:start",this.repoShortcutModel.id)}},templateHelpers:function(){return{dvcsName:this.dvcsName,canUserManageDVCSAccounts:this.canUserManageDVCSAccounts,isIntegration:this.isIntegration}},_removeAndHide:function(){var t=this;AJS.dialog2(this.$el).hide(),setTimeout(function(){return t.destroy()})},triggerSubmitAnalyticEvent:function(){this.canUserManageDVCSAccounts&&(this.isIntegration?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.integrate.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.sync.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}))},triggerEditAnalyticEvent:function(){this.canUserManageDVCSAccounts&&(this.isIntegration?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.integrate.edit",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.sync.edit",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}))},triggerCancelAnalyticEvent:function(){this.canUserManageDVCSAccounts&&(this.isIntegration?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.integrate.cancel",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.sync.cancel",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutType:this.dvcsName}}))},initialize:function(t){var e=this,n=t.repoShortcutModel,r=t.canUserManageDVCSAccounts;this.repoShortcutModel=n;var a=function(t){t.set({isRepositoryLinked:!0}),t.trigger("dvcsremote:change",t),e._removeAndHide()},c=n.attributes;if(this.dvcsName="bitbucket"===c.dvcsType?"Bitbucket":"GitHub",this.canUserManageDVCSAccounts=r,this.isIntegration=n.hasNotLinkedOrg(),"bitbucket"===c.dvcsType&&n.hasNotLinkedOrg()&&r)this.handleSubmit=function(){return i.startBBOrganisationLink(c.dvcsOrg)};else if("bitbucket"===c.dvcsType&&n.hasLinkedOrgAndNotRepo()&&r)this.handleSubmit=function(){i.startBBRepositoryLink(n.attributes).then(function(){return a(n)})["catch"](function(){return e._removeAndHide()})};else{if("github"!==c.dvcsType)throw"Unsupported DVCS Type";c.githubAppInstalled||(this.handleSubmit=function(){i.startGithubOrganisationLink()})}},onRender:function(){AJS.dialog2(this.$el).show()}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/dialogs/Add.js' */
"use strict";define("repository-shortcuts/dialogs/add",["jquery","repository-shortcuts/models/repository-shortcut","repository-shortcuts/views/add-dialog-content","repository-shortcuts/services/repo-shortcut-update-handler"],function(e,t,s,i){return JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Add.extend({initialize:function(r){_.bindAll(this,"hide","refresh","focusForm");var o=this;this.analyticsSave=!1,this.sidebarItem=r.sidebarItem,this.projectKey=r.projectKey,this.collection=r.collection,this.model=new t(null,{projectKey:this.projectKey}),this.errorModel=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors(null,{model:this.model}),this.view=new s({model:this.model,errorModel:this.errorModel,canUserManageDVCSAccounts:this.collection.canUserManageDVCSAccounts}),this.view.render();var c=e(window),n=e(document),a=e(".aui-sidebar-body");this.dialog=AJS.InlineDialog(this.sidebarItem.ui.link,"repo-shortcuts-group__add-dialog",function(e,t,s){return o.sidebarItem.$el.addClass("aui-nav-selected"),o.view.render(),o.view.$el.appendTo(e),o.view.ui.url.focus(),c.on("scroll.repo-shortcuts",function(){o.refresh()}),a.on("scroll.repo-shortcuts",function(){o.hide()}),n.on("showLayer",o.focusForm),c.on("resize",o.refresh),s(),!1},{gravity:"w",autoWidth:!0,initCallback:function(){o.trigger("dialog:open"),o.analyticsSave=!1},hideCallback:function(){o.sidebarItem.$el.removeClass("aui-nav-selected"),o.sidebarItem.ui.link.blur(),c.off("scroll.repo-shortcuts"),a.off("scroll.repo-shortcuts"),n.off("showLayer",o.focusForm),o.trigger("dialog:close",o.analyticsSave)},persistent:!0,closeOnTriggerClick:!0}),this.listenTo(this.view,"render",this.refresh),this.listenTo(this.view,"cancel",this.hideAndRender),this.listenTo(this.model,"save:success",function(){var e=new t(this.model.toJSON(),{projectKey:this.projectKey});this.collection.add(e),this.model.clear(),this.analyticsSave=!0,this.hide(),"bitbucket"!==e.attributes.dvcsType&&"github"!==e.attributes.dvcsType||i(e,this.collection.canUserManageDVCSAccounts),AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.link-repo.click",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),dvcsType:e.attributes.dvcsType}})}),this.listenTo(this.sidebarItem,"before:select",function(e){return e.preventDefault()}),AJS.sidebar(".aui-sidebar").on("collapse-start",this.hide),e(".repo-shortcuts-group").on("click","li",this.hide)}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/dialogs/AddModal.js' */
"use strict";define("repository-shortcuts/dialogs/add-modal",["jquery","repository-shortcuts/models/repository-shortcut","repository-shortcuts/views/add-dialog-content","repository-shortcuts/services/repo-shortcut-update-handler","aui/flag"],function(e,t,o,s,i){return JIRA.Projects.Libs.Marionette.Controller.extend({initialize:function(e){this.collection=e.collection,this.projectKey=e.projectKey,this.projectId=e.projectId,this.analyticsSave=!1,this.model=new t(null,{projectKey:this.projectKey}),this.errorModel=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors(null,{model:this.model}),this.view=new o({model:this.model,errorModel:this.errorModel,canUserManageDVCSAccounts:this.collection.canUserManageDVCSAccounts}),this.view.render(),this.dialog=AJS.dialog2(this.view.$el),this.listenTo(this.model,"save:success",function(){var e=new t(this.model.toJSON(),{projectKey:this.projectKey});this.collection.add(e),this.model.clear(),AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.link-repo.click",data:{projectId:this.projectId,dvcsType:e.attributes.dvcsType}}),this.analyticsSave=!0,this._closeDialog(),"bitbucket"===e.attributes.dvcsType||"github"===e.attributes.dvcsType?(s(e,this.collection.canUserManageDVCSAccounts),e.hasLinkedAllComponents()&&i({type:"success",title:"You have added the repository",body:"Nicely done! Your team is going to love this.",close:"manual"})):i({type:"success",title:"You have added the shortcut",body:"Nicely done! Your team is going to love this.",close:"manual"})}),this.listenTo(this.view,"cancel",this._closeDialog),this.listenTo(this.dialog,"hide",this._cleanUpDialog)},show:function(){this.dialog.show(),this.view.ui.url.focus(),AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.add-link.click",data:{projectId:this.projectId}})},_closeDialog:function(){this.dialog.hide()},_cleanUpDialog:function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.connect-repo.add-link.close",data:{projectId:this.projectId,isSave:this.analyticsSave}}),e("#add-repository-dialog").parent().remove()}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/dialogs/Edit.js' */
"use strict";define("repository-shortcuts/dialogs/edit",["jquery","repository-shortcuts/models/repository-shortcut","repository-shortcuts/views/edit-dialog-content","repository-shortcuts/services/repo-shortcut-update-handler","aui/flag"],function(e,t,o,r,s){return JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Edit.extend({initialize:function(i){var c=this,d=i.repoShortcutModel,n=i.canUserManageDVCSAccounts,a=i.editButtonId;_.bindAll(this,"hide"),this.model=new t(d.toJSON(),{projectKey:d.projectKey||d.collection.projectKey}),this.errorModel=new JIRA.Projects.Sidebar.ProjectShortcuts.Entities.ShortcutErrors((void 0),{model:this.model}),this.view=new o({model:this.model,errorModel:this.errorModel,canUserManageDVCSAccounts:n}),this.view.render();var l=e(JIRA.Software.RepositoryShortcuts.Templates.editDialogChrome({}));this.view.$el.appendTo(l),this.dialog=AJS.dialog2(l),this.dialog.show(),this.view.ui.url.focus();var u=JIRA.API.Projects.getCurrentProjectId();this.view.ui["delete"].on("click",function(e){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.delete-link.click",data:{projectId:u,shortcutId:c.model.id}}),e.preventDefault(),c.hide();var t=new JIRA.Projects.Sidebar.ProjectShortcuts.Dialogs.Delete({model:c.model});c.listenToOnce(t,"dialog:close",function(e){e?AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.delete-link.confirm",data:{projectId:u,shortcutId:c.model.id}}):AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.delete-link.cancel",data:{projectId:u,shortcutId:c.model.id}})})}),this.listenTo(this.model,"remove:success",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.delete-link.success",data:{projectId:u,shortcutId:c.model.id}}),d.collection.remove(d),s({type:"success",body:"Shortcut deleted.",close:"manual"})}),this.listenTo(this.model,"save:start",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.edit.save",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutId:c.model.id}})}),this.listenTo(this.view,"cancel",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.edit.cancel",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutId:d.id}}),c.hide()}),this.listenTo(this.model,"save:success",function(){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.edit.success",data:{projectId:JIRA.API.Projects.getCurrentProjectId(),shortcutId:c.model.id}}),c.hide(),d.set(c.model.toJSON()),"bitbucket"===d.get("dvcsType")||"github"===d.get("dvcsType")?(r(d,n),d.hasLinkedAllComponents()&&s({type:"success",body:"You have updated the repository",close:"manual"})):s({type:"success",body:"You have updated the shortcut",close:"manual"})}),this.dialog.on("hide",function(){c.trigger("dialog:close",c.analyticsSave);var e=document.getElementById(a);e&&e.focus()})}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts', location = 'jira-development-integration-plugin/js/repository-shortcuts/dialogs/Connection.js' */
"use strict";define("repository-shortcuts/dialogs/connection",["jquery","underscore","repository-shortcuts/views/connection-dialog-content"],function(i,e,o){return JIRA.Projects.Libs.Marionette.Controller.extend({initialize:function(t){var r=this,s=t.$trigger,n=t.repoShortcutModel;e.bindAll(this,"hide");var c=this,l={gravity:"w",persistent:!0,closeOnTriggerClick:!0,initCallback:function(){c.trigger("dialog:open"),c.analyticsSave=!1},hideCallback:function(){i(window).off("scroll.repo-shortcuts"),i(".aui-sidebar-body").off("scroll.repo-shortcuts"),i(document).off("showLayer",c.focusForm),c.trigger("syncDialog:close")}},a=function(e,o,t){var s=i(window),n=i(".aui-sidebar-body");return e.addClass("connection-dialog"),r.view.render(),r.view.$el.appendTo(e),s.on("resize",r.refresh),s.on("scroll.repo-shortcuts",r.refresh),n.on("scroll.repo-shortcuts",r.hide),t(),!1},d="suggest-connection-dialog-"+n.id;this.view=new o({repoShortcutModel:n}),this.listenTo(this.view,"connection:start",this.hide),this.listenTo(this.view,"connection:cancel",this.hide),this.dialog=AJS.InlineDialog(s,d,a,l),AJS.sidebar(".aui-sidebar").on("collapse-start",this.hide)},hide:function(){this.dialog.hide()},refresh:function(){this.dialog.refresh()}})});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts-shortcut-utils', location = 'jira-development-integration-plugin/js/repository-shortcuts/utils/ShortcutUtils.js' */
"use strict";define("repository-shortcuts/utils/repository-shortcut-utils",["exports"],function(t){t.mapDvcsTypeToIcon=function(t){switch(t){case"bitbucket":return"bitbucket";case"github":return"repos";default:return"shortcut"}},t.shouldShowSync=function(t,e){var s=t.attributes,i="bitbucket"===s.dvcsType||"github"===s.dvcsType,o=Boolean(s.isOrganisationLinked&&(!s.dvcsRepo||s.isRepositoryLinked));return e&&i&&!o}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts-navigation-next', location = 'jira-development-integration-plugin/js/repository-shortcuts/integration/navigation-next.js' */
"use strict";define("repository-shortcuts/navigation-next",["jquery","underscore","bluebird/Promise","jira/dev-status/util/es6","repository-shortcuts/models/repository-shortcuts","repository-shortcuts/dialogs/add-modal","repository-shortcuts/dialogs/edit","repository-shortcuts/views/connection-modal","repository-shortcuts/utils/repository-shortcut-utils","repository-shortcuts/services/dvcs-account-matcher","jira/featureflags/feature-manager"],function(t,e,n,r,o,i,c,a,s,u,d){var l="com.atlassian.jira.jira-projects-plugin:source.code.link.",f="com.atlassian.jira.plugins.jira-development-integration-plugin:repository-shortcuts-navigation-next.repository-shortcuts-data",p="com.pyxis.greenhopper.jira:project-sidebar-simple-add-repo",g=WRM.data.claim(f),h=g.canManageDVCS,m="endeavour.performance.shortcuts-optimization",v=d.isFeatureEnabled(m);return function(d){var f=d.shortcuts,g=d.onAdd,m=d.onEdit,y=d.onDelete,j=d.onBulkEdit,E=d.projectKey,A=void 0===E?"":E,I=d.projectId,w=void 0===I?"":I,S=d.isAdmin,C=void 0!==S&&S,b=d.canUserManageDVCSAccounts,D=void 0===b?h:b,M=A||JIRA.API.Projects.getCurrentProjectKey(),P=w||JIRA.API.Projects.getCurrentProjectId(),k=C||D,x=function(t){var e=f.find(function(e){return e.id===t});return e?e.editButtonId:null},J=new o([],{canUserManageDVCSAccounts:k,projectKey:M}),K=!1,R=function(t){if(!K){var e=t.get("icon");if(e)return e}return s.mapDvcsTypeToIcon(t.get("dvcsType"))},U=function(t){return s.shouldShowSync(t,k)},V=function(t){return l+t.id},T=function(t,n){return e.extend({},n,{name:t.get("name"),url:t.get("url"),type:t.get("type"),id:V(t),icon:R(t),showSync:U(t),onEditClick:function(){return F(t.id,"sidebar")},onSyncClick:function(){return N(t.id)}})},B=function(t){return{name:t.text,url:t.href,id:t.id,icon:t.icon}},q=function(){return new i({collection:J,projectKey:M,projectId:P}).show()},F=function(t,e){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.sidebar.connect-repo.edit",data:{projectId:P,shortcutId:t,referrer:e}}),new c({repoShortcutModel:J.get(t),canUserManageDVCSAccounts:k,editButtonId:x(t)})},N=function(t){return new a({repoShortcutModel:J.get(t),canUserManageDVCSAccounts:k}).render()},W=function(t){return g(T(t,{canEdit:!0}))},z=function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=e.canEdit,r=[].concat(t);v?j(r.map(function(t){return T(t,{canEdit:n})})):r.forEach(function(t){return m(T(t,{canEdit:n}))})},O=function(t){return y(V(t))};J.add(f.map(B),{projectKey:M}),f._collection=J,f.length&&!v&&z(J.models,{canEdit:f[0].canEdit}),J.on("add",function(t){return W(t)}).on("change",function(t,e){var n=e.canEdit,r=void 0===n||n;return z(t,{canEdit:r})}).on("remove",function(t){return O(t)}).on("edit:start",function(t){return F(t,"integrationDialog")});var _=f.map(function(t){return u.matchUrlAgainstNetwork(t.href)});return n.all(_).then(function(t){K=!0,t.forEach(function(t,e){var n=f[e],r=J.get(n.id);r&&r.set(t,{silent:v,canEdit:n.canEdit})}),v&&r.requestIdleCallback(function(){f.length&&z(J.models,{canEdit:f[0].canEdit})})})["catch"](function(t){AJS.trigger("analyticsEvent",{name:"jira-software.fe.web.notifications.connect-repo.shortcut-data-retrieve-fail",errorMessage:t&&t.message})}),(JIRA.API.getNavigationApi||t.Deferred)().then(function(t){t.onItemClick(t.viewIds.SOFTWARE,p,q)}),{add:q}}});;
;
/* module-key = 'com.atlassian.analytics.analytics-client:js-events', location = 'js/node_modules/@atlassian/cloud-analytics-js/store-1.3.1.js' */
/* Copyright (c) 2010-2012 Marcus Westin
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

(function(){
	var store = {},
		win = window,
		doc = win.document,
		localStorageName = 'localStorage',
		globalStorageName = 'globalStorage',
		namespace = '__storejs__',
		storage;

	store.disabled = false;
	store.set = function(key, value) {};
	store.get = function(key) {};
	store.remove = function(key) {};
	store.clear = function() {};
	store.transact = function(key, transactionFn) {
		var val = store.get(key);
		if (typeof val == 'undefined') { val = {} }
		transactionFn(val);
		store.set(key, val);
	};

	store.serialize = function(value) {
		return JSON.stringify(value);
	};
	store.deserialize = function(value) {
		if (typeof value != 'string') { return undefined }
		return JSON.parse(value);
	};

	// Functions to encapsulate questionable FireFox 3.6.13 behavior 
	// when about.config::dom.storage.enabled === false
	// See https://github.com/marcuswestin/store.js/issues#issue/13
	function isLocalStorageNameSupported() {
		try { return (localStorageName in win && win[localStorageName]); }
		catch(err) { return false; }
	}
	
	function isGlobalStorageNameSupported() {
		try { return (globalStorageName in win && win[globalStorageName] && win[globalStorageName][win.location.hostname]); }
		catch(err) { return false; }
	}	

	if (isLocalStorageNameSupported()) {
		storage = win[localStorageName];
		store.set = function(key, val) {
			if (val === undefined) { return store.remove(key); }
			storage.setItem(key, store.serialize(val));
		};
		store.get = function(key) { return store.deserialize(storage.getItem(key)); };
		store.remove = function(key) { storage.removeItem(key); };
		store.clear = function() { storage.clear(); };

	} else if (isGlobalStorageNameSupported()) {
		storage = win[globalStorageName][win.location.hostname];
		store.set = function(key, val) {
			if (val === undefined) { return store.remove(key); }
			storage[key] = store.serialize(val);
		};
		store.get = function(key) { return store.deserialize(storage[key] && storage[key].value); };
		store.remove = function(key) { delete storage[key]; };
		store.clear = function() { for (var key in storage ) { delete storage[key]; } };

	} else if (doc.documentElement.addBehavior) {
		var storageOwner,
			storageContainer;
		// Since #userData storage applies only to specific paths, we need to
		// somehow link our data to a specific path.  We choose /favicon.ico
		// as a pretty safe option, since all browsers already make a request to
		// this URL anyway and being a 404 will not hurt us here.  We wrap an
		// iframe pointing to the favicon in an ActiveXObject(htmlfile) object
		// (see: http://msdn.microsoft.com/en-us/library/aa752574(v=VS.85).aspx)
		// since the iframe access rules appear to allow direct access and
		// manipulation of the document element, even for a 404 page.  This
		// document can be used instead of the current document (which would
		// have been limited to the current path) to perform #userData storage.
		try {
			storageContainer = new ActiveXObject('htmlfile');
			storageContainer.open();
			storageContainer.write('<s' + 'cript>document.w=window</s' + 'cript><iframe src="/favicon.ico"></frame>');
			storageContainer.close();
			storageOwner = storageContainer.w.frames[0].document;
			storage = storageOwner.createElement('div');
		} catch(e) {
			// somehow ActiveXObject instantiation failed (perhaps some special
			// security settings or otherwse), fall back to per-path storage
			storage = doc.createElement('div');
			storageOwner = doc.body;
		}
		function withIEStorage(storeFunction) {
			return function() {
				var args = Array.prototype.slice.call(arguments, 0);
				args.unshift(storage);
				// See http://msdn.microsoft.com/en-us/library/ms531081(v=VS.85).aspx
				// and http://msdn.microsoft.com/en-us/library/ms531424(v=VS.85).aspx
				storageOwner.appendChild(storage);
				storage.addBehavior('#default#userData');
				storage.load(localStorageName);
				var result = storeFunction.apply(store, args);
				storageOwner.removeChild(storage);
				return result;
			}
		}
		store.set = withIEStorage(function(storage, key, val) {
			if (val === undefined) { return store.remove(key) }
			storage.setAttribute(key, store.serialize(val));
			storage.save(localStorageName);
		});
		store.get = withIEStorage(function(storage, key) {
			return store.deserialize(storage.getAttribute(key));
		});
		store.remove = withIEStorage(function(storage, key) {
			storage.removeAttribute(key);
			storage.save(localStorageName);
		});
		store.clear = withIEStorage(function(storage) {
			var attributes = storage.XMLDocument.documentElement.attributes;
			storage.load(localStorageName);
			for (var i=0, attr; attr = attributes[i]; i++) {
				storage.removeAttribute(attr.name);
			}
			storage.save(localStorageName);
		});
	}
	
	try {
		store.set(namespace, namespace);
		if (store.get(namespace) != namespace) { store.disabled = true; }
		store.remove(namespace);
	} catch(e) {
		store.disabled = true;
	}
	
	if (typeof module != 'undefined') { module.exports = store; }
	else if (typeof define === 'function' && define.amd) { define(store); }
	else { this.store = store; }
})();;
;
/* module-key = 'com.atlassian.analytics.analytics-client:js-events', location = 'js/node_modules/@atlassian/cloud-analytics-js/page-visibility.js' */
define('atlassian/analytics/page-visibility', function () {
    var hasBrowserSupport = (document.hidden !== undefined);

    /**
     * A partial wrapper for the Page Visibility API
     * @exports atlassian/analytics/page-visibility
     */
    var wrapper = {

        /** Is the API supported by the browser? */
        supported: hasBrowserSupport,

        /**
         * A proxy for `document.hidden`.
         * Defaults to false if the API is not supported by the browser
         * @returns {boolean}
         */
        isHidden: function () {
            return hasBrowserSupport ? document.hidden : false;
        }
    };

    return wrapper;
});;
;
/* module-key = 'com.atlassian.analytics.analytics-client:js-events', location = 'js/node_modules/@atlassian/cloud-analytics-js/atlassian-analytics.js' */
(function ($) {
    /**
     * There's a scenario where analytics queues can become "stuck".
     * A mutex that's meant to stop multiple tabs from draining a queue,
     * is never reset, causing queues to grow, until they fill localStorage.
     *
     * If we detect that the queue is abnormally large (ie. larger than
     * SUSPICIOUS_SIZE) and the mutex is locked, then we reset both the
     * queue and the mutex.
     * @param productKey
     */
    function resetStuckQueues (productKey) {
        var SUSPICIOUS_SIZE = 250 * 1024;
        var EVENT_QUEUE_KEY = 'atlassian-analytics.' + productKey;
        var EVENT_QUEUE_LOCK_KEY = EVENT_QUEUE_KEY + '.lock';
        var UNLOCKED_VALUE = 'null';
        var queueSize = (window.localStorage[EVENT_QUEUE_KEY] || '').length;
        var isLocked = (window.localStorage[EVENT_QUEUE_LOCK_KEY] || UNLOCKED_VALUE) !== UNLOCKED_VALUE;
        if (isLocked && queueSize > SUSPICIOUS_SIZE) {
            window.localStorage[EVENT_QUEUE_KEY] = JSON.stringify([{
                name: 'grow0.event.queue.cleared',
                time: new Date().valueOf(),
                properties: {queueSize: queueSize}
            }]);
            window.localStorage[EVENT_QUEUE_LOCK_KEY] = UNLOCKED_VALUE;
        }
    }

    ['jira', 'confluence', 'unknown'].forEach(function (productKey) {
        try {
            resetStuckQueues(productKey);
        } catch (e) {
            // silence errors
        }
    });

    // Make sure we are getting the jQuery.ajax method, even if it has been overridden elsewhere.
    // This will only work if this code is executed before any code which overrides the ajax method.
    var $ajax = AJS.$.ajax;
    var baseStorageKey = 'atlassian-analytics';
    var contextPath =
        typeof AJS.contextPath == "function" ? AJS.contextPath() :
        typeof AJS.Confluence != "undefined" ? AJS.Confluence.getContextPath() :
        window.contextPath != null ? window.contextPath : "";

    var publish = null;
    var storageKey = null;
    var lockKey = null;

    // A unique identifier for this browser tab
    // Source: http://stackoverflow.com/a/2117523
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });

    var determineStorageKey = function(){
        // We need to give each product it's own key for events because in ondemand multiple product live
        // at the same url.
        var product = 'unknown';
        if (document.body.id == 'jira'){
            product = 'jira';
        }
        else if (document.body.id == 'com-atlassian-confluence'){
            product = 'confluence';
        }
        storageKey = baseStorageKey + '.' + product;
        lockKey = storageKey + '.lock';
    };

    var getLock = function() {
        if (store.get(lockKey)) {
            return false;
        }

        store.set(lockKey, uuid);

        // Reduce chance of race condition - read back lock to make sure we still have it
        return (store.get(lockKey) === uuid);
    };

    var releaseLock = function() {
        store.set(lockKey, null);
    };

    /**
     * Persists the events that have been generated until such time that they can be sent.
     */
    var saveForLater = function() {
        var events = [],
            event,
            e, i, ii;
        if (AJS.EventQueue.length == 0)
            return;
        // Prime our events array with anything that's already saved.
        events = store.get(storageKey) || events;
        // Suck the events out of the event queue and in to our events array.
        for (i = 0, ii = AJS.EventQueue.length; i < ii; ++i) {
            e = AJS.EventQueue[i];
            if (e.name) {
                // the queue could contain anything - shear unusable properties
                event = { name: e.name, properties: e.properties, time: e.time || 0};
                events.push(event);
            }
        }
        // Empty the event queue
        AJS.EventQueue.length = 0;
        // Save our events for later
        store.set(storageKey, events);
    };

    // Variable to track the number of retries to publish
    var bulkPublishRetryCount = 0;

    /**
     * Gets the amount of time that should be waited until the next publish attempt.
     * @param retryCount How many requests failed since the last successful publish.
     * @returns {number} how many ms that should be waited.
     */
    var getBulkPublishBackoff = function (retryCount) {
        return Math.min(5000 * Math.pow(2, retryCount), 5*60*1000);
    };

    /**
     * Publishes every event that's ready for publishing.
     */
    var bulkPublish = function() {
        var events;

        function reschedule() {
            setTimeout(bulkPublish, getBulkPublishBackoff(bulkPublishRetryCount = 0));
        }

        function rescheduleFailed() {
            setTimeout(bulkPublish, getBulkPublishBackoff(++bulkPublishRetryCount));
        }

        // Avoid multiple browser tabs hitting this all at once
        if (!getLock()) {
            return reschedule();
        }

        // Make sure every event we might have is stored.
        saveForLater();
        // Pull the stored events out and get 'em ready for transmission.
        events = store.get(storageKey);

        if (!events || !events.length) {
            releaseLock();
            return reschedule();
        }

        // Wipe the stored events.
        store.remove(storageKey);

        releaseLock();

        // Validate events and remove any dodgy ones
        if (!validateEvents(events)) {
            return reschedule();
        }

        // try to present a rough timing of events that the server can interpret relative to it's own time.
        var currentTime = new Date().getTime();
        for (var i = 0; i < events.length; i++){
            if (events[i].time > 0){
                events[i].timeDelta = events[i].time - currentTime;
            }
            else{
                // just fake it. This corresponds to a millisecond for each place behind last in the array.
                // This should be rare. Basically, events added to EventQueue before this script was loaded.
                events[i].timeDelta = i - events.length;
            }
            delete events[i].time;
        }

        // AJS.safe.post appears to corrupt a JSON data object, so we send it as a context param instead.
        // Failing to JSON encode the data results in jQuery not attempting to send, and silently swallowing our attempt
        publish = $ajax({
            type: "POST",
            url: contextPath + "/rest/analytics/1.0/publish/bulk",
            data: JSON.stringify(events),
            contentType: "application/json",
            dataType: "json"
        });
        // In case the transmission fails, let's keep the events we just attempted to send.
        publish.fail(function() {
            // This actually drops events, but the alternative is to use something like:
            //   $.merge(AJS.EventQueue, events);
            // Unfortunately using that will cause some fairly nasty issues where duplicate events continually
            // get sent - see https://jira.atlassian.com/browse/AA-179 for more details.
            // TODO: investigate why the above happens and fix this functionality for good
            AJS.EventQueue.concat(events);

            saveForLater();
            rescheduleFailed();
        });
        publish.done(function () {
            reschedule();
        });
    };

    /**
     * Check for any invalid events and remove/sanitise them.
     * @param events - the list of events to be published
     * @returns the number of valid events remaining
     */
    var validateEvents = function(events) {
        for (var i = events.length - 1; i >= 0; i--) {
            var validMsg = "";
            var event = events[i];
            var properties = event.properties;
            if (typeof event.name === "undefined") {
                validMsg = "you must provide a name for the event.";
            } else if (typeof properties !== "undefined" && properties !== null) {
                if (properties.constructor !== Object) {
                    validMsg = "properties must be an object with key value pairs.";
                } else {
                    sanitiseProperties(properties);
                }
            }
            if (validMsg !== "") {
                AJS.log("WARN: Invalid analytics event detected and ignored, " + validMsg + "\nEvent: "+JSON.stringify(event));
                events.splice(i, 1);
            }
        }
        return events.length;
    };

    var sanitiseProperties = function(properties) {
        for (var propertyName in properties) {
            if (properties.hasOwnProperty(propertyName)) {
                var propertyValue = properties[propertyName];

                if (valueExists(propertyValue) && isAllowedType(propertyValue)) {
                    // Do nothing - the property value is safe & allowed already
                } else if (valueExists(propertyValue) && propertyValue.toString) {
                    // Sanitise the property value by invoking its "toString"
                    properties[propertyName] = propertyValue.toString();
                } else {
                    // If it's an undefined, null or invalid value - blank it out
                    properties[propertyName] = "";
                }
            }
        }
    };

    function valueExists(propertyValue) {
        return typeof propertyValue !== "undefined" && propertyValue !== null;
    }

    function isAllowedType(propertyValue) {
        return typeof propertyValue === "number" || typeof propertyValue === "string" || typeof propertyValue === "boolean";
    }

    var cancelPublish = function() {
        if (publish && !(publish.state() === "resolved" || publish.state() === "rejected")) {
            publish.abort(); // This will cancel the request to the server, and cause the events to be saved for later.
        }
    };

    /**
     * Provides a way to publish events asynchronously, without requiring AJS.Events to have loaded.
     * Users of this property must conditionally initialise it to an empty array. Objects pushed
     * must have a name property, and optionally a properties property of other data to send.
     * @example
     * AJS.EventQueue = AJS.EventQueue || [];
     * AJS.EventQueue.push({name: 'eventName', properties: {some: 'data', more: true, hits: 20}});
     */
    AJS.EventQueue = AJS.EventQueue || [];

    var arrayPush = Array.prototype.push;
    AJS.EventQueue.push = function(obj) {
    	obj.time = new Date().getTime();
    	arrayPush.call(AJS.EventQueue, obj);
    };

    AJS.toInit(function() {
    	determineStorageKey();
        setTimeout(bulkPublish, 500);
        removeOldAnalytics();
    });
    $(window).unload(function() {
        cancelPublish();
        saveForLater();
    });

    /**
     * @deprecated since v3.39, please trigger as normal and use whitelisting to denote privacy policy safe events
     */
    AJS.Analytics = {
        triggerPrivacyPolicySafeEvent: function(name, properties) {
            AJS.log("WARN: 'triggerPrivacyPolicySafeEvent' has been deprecated");
            AJS.EventQueue.push({name: name, properties: properties});
        }
    };

    /**
     * Binds to an event that developers can trigger without having to do any feature check.
     * If this code is available then the event will get published and if it's not the event
     * will go unnoticed.
     * @example
     * AJS.trigger('analytics', {name: 'pageSaved', data: {pageName: page.name, space: page.spaceKey}});
     */
    AJS.bind('analytics', function(event, data) {
    	AJS.EventQueue.push({name: data.name, properties: data.data});
    });

    // legacy binding until Confluence page layout JS is updated
    AJS.bind('analyticsEvent', function(event, data) {
    	AJS.EventQueue.push({name: data.name, properties: data.data});
    });

    /**
     * As part of bundling this plugin in BTF now, we need to remove the existing JIRA analytics setting if we see it.
     */
    var removeOldAnalytics = function () {
        if (window.location.pathname.indexOf("/secure/admin/ViewApplicationProperties") > -1) {
            AJS.$("[data-property-id='analytics-enabled']").remove();
        } else if (window.location.pathname.indexOf("/secure/admin/EditApplicationProperties") > -1) {
            var $analytics = AJS.$(":contains(Enable Atlassian analytics)");
            if ($analytics.size() > 0) {
                var parentElement = $analytics[$analytics.size() - 2];
                if (parentElement) {
                    parentElement.remove();
                }
            }
        }
    }

}(AJS.$));
;
;
/* module-key = 'com.atlassian.crowd.user-provisioning-vertigo-plugin:common-flag-resources', location = 'user-provisioning-vertigo-module/js/atlassian/aui-polyfill/flag.js' */
/*
 * Polyfill for aui/flag for use in products that don't provide a version (due to using an ancient AUI version).
 */
(function() {
    try {
        require('aui/flag')
    } catch (e) {
        define('aui/flag', [], displayFlagAsMessage);
    }

    function displayFlagAsMessage(args) {
        var type = (args.type || "").toLowerCase();
        var message = typeof AJS.messages[type] == 'function' ? AJS.messages[type] : AJS.messages.generic;

        // for some reason we display info messages as warnings... keeping that for backward compatibility
        message(".notifications", { body: args.message });
    }
})();
;
;
/* module-key = 'com.atlassian.crowd.user-provisioning-vertigo-plugin:common-flag-resources', location = 'user-provisioning-vertigo-module/js/atlassian/flag.js' */
/**
 * This is a wrapper around AUI Flag which will escape the body text of the Flag unless explicitly told not to.
 *
 * The body will NOT be escaped iff the passed in object has an attribute 'isHtml' and it is set to true.
 */
define('user-management-common/flag', [
    'aui/flag',
    'underscore',
    'jquery'
], function(
    flag,
    _,
    $
) {
    return function(options){
        var createdFlag;
        // If not explicitly HTML, escape the body
        if(!options.isHtml) {
            options.body = _.escape(options.body);
        }

        createdFlag = flag(options);
        $(createdFlag).on('aui-flag-close', function(){
            createdFlag.dispatchEvent(new CustomEvent('um-flag-close', { bubbles: true }));
        });
        return createdFlag;
    };
});
;
;
/* module-key = 'com.atlassian.plugin.jslibs:browser-storage-controls-3.0.1', location = 'atlassian-jslibs/libs/@atlassian/browser-storage-controls/dist/cookie-controls-min.js' */
define("atlassian/libs/browser-storage-controls",["analytics-web-client"],(function(e){return function(e){var t={};function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,n),o.l=!0,o.exports}return n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(r,o,function(t){return e[t]}.bind(null,o));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=6)}([function(e,t,n){var r,o;
/*!
 * JavaScript Cookie v2.2.1
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */!function(i){if(void 0===(o="function"==typeof(r=i)?r.call(t,n,t,e):r)||(e.exports=o),!0,e.exports=i(),!!0){var a=window.Cookies,c=window.Cookies=i();c.noConflict=function(){return window.Cookies=a,c}}}((function(){function e(){for(var e=0,t={};e<arguments.length;e++){var n=arguments[e];for(var r in n)t[r]=n[r]}return t}function t(e){return e.replace(/(%[0-9A-Z]{2})+/g,decodeURIComponent)}return function n(r){function o(){}function i(t,n,i){if("undefined"!=typeof document){"number"==typeof(i=e({path:"/"},o.defaults,i)).expires&&(i.expires=new Date(1*new Date+864e5*i.expires)),i.expires=i.expires?i.expires.toUTCString():"";try{var a=JSON.stringify(n);/^[\{\[]/.test(a)&&(n=a)}catch(e){}n=r.write?r.write(n,t):encodeURIComponent(String(n)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent),t=encodeURIComponent(String(t)).replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent).replace(/[\(\)]/g,escape);var c="";for(var s in i)i[s]&&(c+="; "+s,!0!==i[s]&&(c+="="+i[s].split(";")[0]));return document.cookie=t+"="+n+c}}function a(e,n){if("undefined"!=typeof document){for(var o={},i=document.cookie?document.cookie.split("; "):[],a=0;a<i.length;a++){var c=i[a].split("="),s=c.slice(1).join("=");n||'"'!==s.charAt(0)||(s=s.slice(1,-1));try{var l=t(c[0]);if(s=(r.read||r)(s,l)||t(s),n)try{s=JSON.parse(s)}catch(e){}if(o[l]=s,e===l)break}catch(e){}}return e?o[e]:o}}return o.set=i,o.get=function(e){return a(e,!1)},o.getJSON=function(e){return a(e,!0)},o.remove=function(t,n){i(t,"",e(n,{expires:-1}))},o.defaults={},o.withConverter=n,o}((function(){}))}))},,function(t,n){t.exports=e},function(e,t,n){"use strict";(function(e){n.d(t,"b",(function(){return f})),n.d(t,"a",(function(){return d}));var r=n(4);const o="__PLATFORM_FEATURE_FLAGS__",i=void 0!==e&&!0,a=!!i&&"true"===Object({NODE_ENV:"production"}).ENABLE_PLATFORM_FF,c=!!i&&"true"===Object({NODE_ENV:"production"}).STORYBOOK_ENABLE_PLATFORM_FF,s=a||c,l={earlyResolvedFlags:new Map,booleanResolver:function(e){return!1}},u="undefined"!=typeof window?window:globalThis;function f(e){u[o].booleanResolver=e}function d(e){if(s)return Object(r.a)('[%s]: The feature flags were enabled while running tests. The flag "%s" will be always enabled.',"@atlaskit/platform-feature-flags",e),!0;try{var t;const n=null===(t=u[o])||void 0===t?void 0:t.booleanResolver(e);return"boolean"!=typeof n?(console.warn(e+" resolved to a non-boolean value, returning false for safety"),!1):n}catch(e){return!1}}u[o]=u[o]||l}).call(this,n(5))},function(e,t,n){"use strict";var r,o;n.d(t,"a",(function(){return a}));const i=!(void 0!==(null===globalThis||void 0===globalThis||null===(r=globalThis.process)||void 0===r||null===(r=r.env)||void 0===r?void 0:r.JEST_WORKER_ID))&&"production"!==(null===globalThis||void 0===globalThis||null===(o=globalThis.process)||void 0===o||null===(o=o.env)||void 0===o?void 0:o.NODE_ENV),a=(...e)=>{i&&console.debug(...e)}},function(e,t){var n,r,o=e.exports={};function i(){throw new Error("setTimeout has not been defined")}function a(){throw new Error("clearTimeout has not been defined")}function c(e){if(n===setTimeout)return setTimeout(e,0);if((n===i||!n)&&setTimeout)return n=setTimeout,setTimeout(e,0);try{return n(e,0)}catch(t){try{return n.call(null,e,0)}catch(t){return n.call(this,e,0)}}}!function(){try{n="function"==typeof setTimeout?setTimeout:i}catch(e){n=i}try{r="function"==typeof clearTimeout?clearTimeout:a}catch(e){r=a}}();var s,l=[],u=!1,f=-1;function d(){u&&s&&(u=!1,s.length?l=s.concat(l):f=-1,l.length&&p())}function p(){if(!u){var e=c(d);u=!0;for(var t=l.length;t;){for(s=l,l=[];++f<t;)s&&s[f].run();f=-1,t=l.length}s=null,u=!1,function(e){if(r===clearTimeout)return clearTimeout(e);if((r===a||!r)&&clearTimeout)return r=clearTimeout,clearTimeout(e);try{r(e)}catch(t){try{return r.call(null,e)}catch(t){return r.call(this,e)}}}(e)}}function y(e,t){this.fun=e,this.array=t}function b(){}o.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];l.push(new y(e,t)),1!==l.length||u||c(p)},y.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=b,o.addListener=b,o.once=b,o.off=b,o.removeListener=b,o.removeAllListeners=b,o.emit=b,o.prependListener=b,o.prependOnceListener=b,o.listeners=function(e){return[]},o.binding=function(e){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(e){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},function(e,t,n){"use strict";n.r(t),n.d(t,"deleteCookie",(function(){return R})),n.d(t,"getCookie",(function(){return V})),n.d(t,"setCookie",(function(){return Fe})),n.d(t,"setStrictlyNecessaryCookie",(function(){return he})),n.d(t,"packUserPreferences",(function(){return ye})),n.d(t,"unpackUserPreferencesCookie",(function(){return be})),n.d(t,"initializeControls",(function(){return Re}));var r=n(0),o=n.n(r),i=n(3);function a(e){return Object(i.a)(e)}var c=n(2),s=n.n(c);let l,u;const f=()=>(null==l&&(l=!0),{analyticsEnabled:l,product:u});function d(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function p(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?d(Object(n),!0).forEach((function(t){y(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):d(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function y(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const b="[browser-storage-controls]";class g{static info(e,t){console.log(`${b}: ${e}`,t?JSON.stringify(t):"")}static error(e,t){console.error(`${b}: ${e}`,t?JSON.stringify(t):"")}static errorWithOperationalEvent({action:e,attributes:t={},message:n,metadata:r}){try{I({action:e,attributes:p({error:n},t)})}catch(t){this.error(`Failed to send operational event on error: ${e}. ${t.message||""}`)}this.error(n,r?JSON.stringify(r):"")}static warn(e,t){console.warn(`${b}: ${e}`,t?JSON.stringify(t):"")}}const m=Object({NODE_ENV:"production"})._PACKAGE_NAME_,v=Object({NODE_ENV:"production"})._PACKAGE_VERSION_;const O=new class{get cachedSamplingConfig(){return this.cache}set cachedSamplingConfig(e){this.cache=e}},w=()=>{const e=!("undefined"!=typeof document&&"undefined"!=typeof window&&Document&&Document.prototype&&Object&&Object.defineProperty),t=!a,n=!Boolean(s.a);return e&&g.warn("Browser context is not available."),t&&g.warn("Platform Feature Flag library is not available"),s.a||g.warn("analytics-web-client is not available"),!!(e||t||n)};let k,h,C;const E=async()=>{if(k)return k;try{return h||(h=fetch("https://atlassian-cookies--categories.us-east-1.prod.public.atl-paas.net/categories.json")),k=await(async e=>{if(!e)throw new Error("Failed to fetch Cookies Cache! Cached promise was undefined");const t=await e;if(!t.ok)throw new Error("Failed to fetch Cookies Cache! status: "+t.status);return C=C||(null==t?void 0:t.json()),C})(h),k}catch(e){g.errorWithOperationalEvent({action:"loadStorageControlsError",message:e.message||""}),k=void 0,h=void 0,C=void 0}},j={usedGetCookie:1e5,usedGetCookieError:1,usedSetCookie:1e3,usedSetCookieError:1,usedSetStrictlyNecessaryCookie:1e4,usedSetStrictlyNecessaryCookieError:1,usedDeleteCookie:10,usedDeleteCookieError:1,usedCheckThirdParty:1e5,checkThirdPartyError:1,usedDocumentCookie:100,usedDocumentCookieError:1,initializeControlsError:1,loadStorageControlsError:1,updatePreferencesError:1,fetchConsentPreferencesError:1,saveConsentPreferencesError:1},S=["loadStorageControlsError"];async function P(e){if(S.includes(e))return j[e];const t=await async function(){if(O.cachedSamplingConfig)return O.cachedSamplingConfig;if(w())return;const e=await E(),t=null==e?void 0:e.analyticsSamplingRatio;return O.cachedSamplingConfig=t,t}(),n=null!=t?t:j;return void 0!==(null==n?void 0:n[e])?n[e]:j[e]}async function T(e,t){!function(e,t){!Math.floor(Math.random()*e)&&t()}(await P(e),t)}function D(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function N(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?D(Object(n),!0).forEach((function(t){A(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):D(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function A(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const U=()=>{const{hostname:e}=window.location;return e.includes(".dev.")||e.includes(".stg.")?c.envType.STAGING:e.includes("localhost")||e.includes("ngrok")||e.includes("atlastunnel")?c.envType.DEV:c.envType.PROD},_=()=>{const{origin:e,pathname:t}=window.location,n=(e=>{let t="";if(!e)return t;const n=t=>new RegExp(`^${t}(/|$)`).test(String(e));return n("/wiki")&&(t="/wiki"),n("/jira")&&(t="/jira"),n("/compass")&&(t="/compass"),n("/canvas")&&(t="/canvas"),(n("/servicedesk")||n("/jira/servicedesk"))&&(t="/servicedesk"),t})(t),r=`${e}${n}`;return{domain:r,product:(e=>"https://trello.com"===e?"trello":null)(r)||n.slice(1)}},F=e=>{var t,n;const{domain:r,product:o}=_();return N({featureFlagOn:a("platform.moonjelly.browser-storage-controls"),packageName:m,packageVersion:v,domain:r,isInCookieBannerExperiment1:a("platform.moonjelly.browser-storage-controls-experiment-one"),product:null!==(t=null===(n=f().product)||void 0===n?void 0:n.toLowerCase())&&void 0!==t?t:o},e&&e)},L=(()=>{let e;return()=>{try{!e&&f().analyticsEnabled&&(e=new s.a({env:U(),product:"atlassianCookies"},{useLegacyUrl:!1,disableCookiePersistence:!0}))}catch(e){g.error("Failed to initialize AnalyticsWebClient. "+e)}if(f().analyticsEnabled)return e}})();function I(e){T(e.action,()=>{var t;return null===(t=L())||void 0===t?void 0:t.sendOperationalEvent({source:"package",actionSubject:"package",action:e.action,attributes:F(e.attributes)})})}const R=(e,t)=>{try{a("platform.moonjelly.browser-storage-controls")&&I({action:"usedDeleteCookie",attributes:{cookieKey:e}}),o.a.remove(e,t)}catch(t){g.errorWithOperationalEvent({action:"usedDeleteCookieError",attributes:{cookieKey:e},message:"Failed to use delete cookie. "+(t.message||"")})}};function V(e){try{return a("platform.moonjelly.browser-storage-controls")&&I({action:"usedGetCookie",attributes:{cookieKey:e}}),e?o.a.get(e):o.a.get()}catch(t){g.errorWithOperationalEvent({action:"usedGetCookieError",attributes:{cookieKey:e},message:"Failed to use get cookie. "+(t.message||"")})}}const K=async(e=2e3,t=0)=>M("platform.moonjelly.browser-storage-controls",e,t),M=(e,t=2e3,n=0)=>{if(n>3e5)return Promise.resolve(!1);if(!a(e)){const e=2*t,r=Math.min(e,3e5);return new Promise(e=>{setTimeout(async()=>{const t=n+r,o=await K(r,t);e(o)},r)})}return Promise.resolve(!0)};let x=function(e){return e.StrictlyNecessary="STRICTLY_NECESSARY",e.Functional="FUNCTIONAL",e.Marketing="MARKETING",e.Analytics="ANALYTICS",e.Unknown="UNKNOWN",e}({}),G=function(e){return e.ConsentDataUnavailable="CONSENT_DATA_UNAVAILABLE",e.ConsentedUnderGDPR="CONSENTS_SAVED_IN_GDPR_LOCALE",e.ConsentedUnderCPRA="CONSENTS_SAVED_IN_CPRA_LOCALE",e.ConsentedUnderLGPD="CONSENTS_SAVED_IN_LGPD_LOCALE",e.ConsentedUnderFADP="CONSENTS_SAVED_IN_FADP_LOCALE",e}({}),W=function(e){return e.ConsentsAreDefault="DEFAULT_CONSENTS",e.UserIsAuthenticated="USER_AUTHENTICATED",e.ConsentDataUnavailable="CONSENT_DATA_UNAVAILABLE",e}({});function B(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function $(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?B(Object(n),!0).forEach((function(t){Y(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):B(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function Y(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}x.StrictlyNecessary,x.Functional,x.Marketing,x.Analytics,x.Unknown;const J=$($({},{[x.StrictlyNecessary]:!0,[x.Functional]:!1,[x.Marketing]:!1,[x.Analytics]:!1,[x.Unknown]:!1}),{},{[W.ConsentsAreDefault]:!0,[W.UserIsAuthenticated]:!1,[W.ConsentDataUnavailable]:!0}),z="001",H="002",Z="003",q=e=>Number(e).toString(),Q=e=>{if(e)return!!Number(e)};let X=function(e){return e.StrictlyNecessary="strictlyNecessaryCookies",e.Functional="functionalCookies",e.Analytics="performanceCookies",e.Marketing="targetingCookies",e.Unknown="unknownCookies",e}({});const ee=e=>e[0]+e[1]+e[2]===H,te=e=>{if(ee(e)){const t="1"===e[8],n="1"===e[9],r="1"===e[10],o="1"===e[11];return t||n||r||o}return!1},ne=e=>{if(ee(e)){return!te(e)}return Q(e[7])},re=e=>`${Z}${Object.entries(J).reduce((t,[n,r])=>{if(n===x.StrictlyNecessary)return t;if(n===W.UserIsAuthenticated){return t+q(!e)}return n===W.ConsentDataUnavailable?t+q(!!e):t+q(r)},"")}`,oe=({consents:e})=>{if(e)return 0===e.length?re():(e=>{var t,n,r,o;return[Z,q(!(null===(t=e.find(e=>e.key===X.Functional))||void 0===t||!t.granted)),q(!(null===(n=e.find(e=>e.key===X.Analytics))||void 0===n||!n.granted)),q(!(null===(r=e.find(e=>e.key===X.Marketing))||void 0===r||!r.granted)),q(!(null===(o=e.find(e=>e.key===X.Unknown))||void 0===o||!o.granted)),0,1,0].join("")})(e);{const e=V("atl-bsc-consent-token-fallback");return e||re(!0)}};Error;function ie(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function ae(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?ie(Object(n),!0).forEach((function(t){ce(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):ie(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function ce(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const se=e=>{if(e.length<3)return{isValid:!1,isV001:!1,isV002:!1,isV003:!1};const t=e[0]+e[1]+e[2],n=t===z&&7===e.length,r=t===H&&12===e.length,o=t===Z&&10===e.length;return{isValid:[z,H,Z].includes(t)&&(n||r||o),isV001:n,isV002:r,isV003:o}},le=e=>[z,q(e.FUNCTIONAL),q(e.ANALYTICS),q(e.MARKETING),q(e.UNKNOWN)].join(""),ue=e=>{if(7===e.length)return{[x.StrictlyNecessary]:!0,[x.Functional]:"1"===e[3],[x.Analytics]:"1"===e[4],[x.Marketing]:"1"===e[5],[x.Unknown]:"1"===e[6]}},fe=e=>({[x.StrictlyNecessary]:!0,[x.Functional]:"1"===e[3],[x.Analytics]:"1"===e[4],[x.Marketing]:"1"===e[5],[x.Unknown]:"1"===e[6],[W.ConsentsAreDefault]:"1"===e[7],[W.UserIsAuthenticated]:"1"===e[8],[W.ConsentDataUnavailable]:"1"===e[9]}),de=[W.ConsentDataUnavailable,G.ConsentedUnderGDPR,G.ConsentedUnderCPRA,G.ConsentedUnderLGPD,G.ConsentedUnderFADP],pe=[W.ConsentsAreDefault,W.UserIsAuthenticated,W.ConsentDataUnavailable];function ye(e){if(!a("platform.moonjelly.browser-storage-controls-v2"))return le(e);if(de.every(t=>t in e))return(e=>{const t=Z,n=!(e[G.ConsentedUnderGDPR]||e[G.ConsentedUnderCPRA]||e[G.ConsentedUnderLGPD]||e[G.ConsentedUnderFADP]),r=e[W.ConsentDataUnavailable],o=!r;return[t,q(e[x.Functional]),q(e[x.Analytics]),q(e[x.Marketing]),q(e[x.Unknown]),q(n),q(o),q(r)].join("")})(e);return pe.every(t=>t in e)?(e=>[Z,q(e[x.Functional]),q(e[x.Analytics]),q(e[x.Marketing]),q(e[x.Unknown]),q(e[W.ConsentsAreDefault]),q(e[W.UserIsAuthenticated]),q(e[W.ConsentDataUnavailable])].join(""))(e):le(e)}function be(e){if(!a("platform.moonjelly.browser-storage-controls-v2")){if(e.length<3)return;return e[0]+e[1]+e[2]===z?ue(e):void 0}const{isValid:t,isV001:n,isV002:r,isV003:o}=se(e);if(t)return n?ue(e):r?(e=>{const t=ne(e),n="1"===e[7],r=!n;return ae(ae({},fe(e)),{},{[W.ConsentsAreDefault]:!!t,[W.UserIsAuthenticated]:r,[W.ConsentDataUnavailable]:n})})(e):o?fe(e):void 0}const ge=e=>{const{isV002:t}=se(e);let n=e[8];if(t){n="1"===e[7]?"0":"1"}return n},me=({consentToken:e,fallbackConsentToken:t})=>{const n=!!ne(e);if(n)return(e=>{if(e){const t=ge(e),n=!Q(t),r=!ne(e);if(n&&r)return!r;if(!n&&r)return!1}return!0})(t);return!(te(e)||!n)||!t},ve=({consentToken:e,consentTimestamp:t,fallbackConsentToken:n})=>{if(!!ne(e))return(e=>{if(e){const t=ge(e),n=!Q(t);return!!ne(e)||!!n}return!0})(n);if(t){return(e=>{let t=!1;if(e){const n=new Date;n.setFullYear(n.getFullYear()-1),t=new Date(e)<n}return t})(t)}return!n};function Oe(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function we(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?Oe(Object(n),!0).forEach((function(t){ke(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Oe(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function ke(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const he=(e,t,n)=>{try{a("platform.moonjelly.browser-storage-controls")&&I({action:"usedSetStrictlyNecessaryCookie",attributes:{cookieKey:e}}),o.a.set(e,t,we(we({},n),{},{"atl-set-cookie":!0}))}catch(t){g.errorWithOperationalEvent({action:"usedSetStrictlyNecessaryCookieError",attributes:{cookieKey:e},message:"Failed to use set strictly necessary cookie. "+(t.message||"")})}},Ce=e=>{const t=new Date;t.setTime(t.getTime()+6e5),he("atl-bsc-consent-token",e,{expires:t,path:"/"})},Ee=(e,t)=>{const n=(({consentToken:e,consentTimestamp:t,fallbackConsentToken:n})=>{const r=w()?n:n||V("atl-bsc-consent-token-fallback");let o=ge(e);let i=!0;return i=!Q(o)?me({consentToken:e,fallbackConsentToken:r}):ve({consentToken:e,fallbackConsentToken:r,consentTimestamp:t}),i})({consentToken:e,consentTimestamp:t}),r=q(!!n),o=new Date;o.setTime(o.getTime()+6e5),he("atl-bsc-show-banner",r,{expires:o,path:"/"})},je=e=>{if(e){return{consentToken:oe(e),consentTimestamp:(({consents:e})=>{if(e&&e.length){const t=e.map(e=>new Date(e.updatedTs).getTime()),n=Math.max(...t);return new Date(n).toISOString()}})(e)}}return{consentToken:oe({}),consentHubInaccessible:!0}},Se=async e=>{const t=await(async()=>{const{origin:e}=window.location,t=e+"/gateway/api/consenthub/session/user/consents/cookies";try{const e=await fetch(t,{method:"GET",headers:{"Content-Type":"application/json"}});if(!e.ok)throw new Error("Failed to fetch preferences from ConsentHub with status: "+e.status);const n=await e.json();return je(n)}catch(e){return g.errorWithOperationalEvent({action:"fetchConsentPreferencesError",message:e.message||""}),je()}})();let{consentToken:n,consentTimestamp:r,consentHubInaccessible:o}=t,{isValid:i}=se(n);return i&&o&&(n=e||n.slice(0,8)+"1111"),i?{consentToken:n,consentTimestamp:r}:void 0},Pe=async()=>{const e=V("atl-bsc-consent-token-fallback"),t=await Se(e);if(t){const{consentToken:e,consentTimestamp:r}=t,o=(n=e,V("atl-testing-consents")||n),i=V("atl-testing-consents");return i||""===i?(Ee(o),Ce(o),""===o?void 0:o):(((e,t)=>{Ce(e),Ee(e,t)})(o,r),e)}var n};let Te=function(e){return e.SUCCESS="SUCCESS",e.BLOCKED="BLOCKED",e.FAILED="FAILED",e}({});function De(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function Ne(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?De(Object(n),!0).forEach((function(t){Ae(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):De(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function Ae(e,t,n){var r;return(t="symbol"==typeof(r=function(e,t){if("object"!=typeof e||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,t||"default");if("object"!=typeof r)return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?r:String(r))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const Ue=(e,t)=>{let n=null;const{keys:r,categories:o,patterns:i}=t;n=e in Object(r)?r[e]:((e,{startsWith:t})=>{let n=t,r=0;for(;r<e.length;){const t=n[e[r]];if(void 0===t)return null;if("number"==typeof t)return t;n=t,r++}return null})(e,i);const a={[o.STRICTLY_NECESSARY]:x.StrictlyNecessary,[o.FUNCTIONAL]:x.Functional,[o.ANALYTICS]:x.Analytics,[o.MARKETING]:x.Marketing,[o.UNKNOWN]:x.Unknown};return null!==n?a[n]:null},_e=async({cookieKey:e,allowedCallback:t=(()=>{}),blockedCallback:n=(()=>{})})=>{let r;const o=await(async e=>{const t=await E();return t?Ue(e,t):null})(e);if(o===x.StrictlyNecessary)r=!0;else{const e=await async function(){if(!a("platform.moonjelly.browser-storage-controls-v2")){const e=V("atl-gdpr-consent");if(!e)return;return be(e)}let e=V("atl-bsc-consent-token");if(!e){const e=await Pe();return e?be(e):void 0}return be(e)}();let t=!1;e&&o&&(t=e[o]),r=t}return r?null==t||t():null==n||n({cookieHasCategory:null!=o}),r},Fe=async(e,t,n)=>{if(!a("platform.moonjelly.browser-storage-controls")){const r={wasRejected:!1,cookieKey:e};try{return o.a.set(e,t,n),Te.SUCCESS}catch(e){return g.errorWithOperationalEvent({action:"usedSetCookieError",attributes:r,message:"Failed to use set cookie. "+(e.message||"")}),Te.FAILED}}const r=await _e({cookieKey:e}),i={wasRejected:!r,cookieKey:e};try{return I({action:"usedSetCookie",attributes:i}),r?(o.a.set(e,t,Ne(Ne({},n),{},{"atl-set-cookie":!0})),Te.SUCCESS):Te.BLOCKED}catch(e){return g.errorWithOperationalEvent({action:"usedSetCookieError",attributes:i,message:"Failed to use set cookie. "+(e.message||"")}),Te.BLOCKED}},Le=e=>t=>{const n=t.includes("atl-set-cookie");if(n)try{return e.apply(document,[t])}catch(e){g.errorWithOperationalEvent({action:"usedDocumentCookieError",message:"document.cookie setter failed to set cookie set by package. "+(e.message||""),attributes:{outsidePackage:!1}})}try{const r=t.slice(0,t.indexOf("="))||"";I({action:"usedDocumentCookie",attributes:{cookieKey:r,outsidePackage:!n}});try{_e({cookieKey:r,allowedCallback:()=>e.apply(document,[t]),blockedCallback:({cookieHasCategory:n})=>a("platform.moonjelly.block-unknown-cookies")||n?void 0:e.apply(document,[t])})}catch(e){g.errorWithOperationalEvent({action:"usedDocumentCookieError",message:"Failed to set cookie. "+(e.message||""),attributes:{cookieKey:r}})}}catch(e){g.errorWithOperationalEvent({action:"usedDocumentCookieError",message:"Failed to send document.cookie setter event. "+(e.message||"")})}},Ie=async(e={})=>{if(w())return;if(!(e.flagEnabled||await K()))return;(({analyticsEnabled:e=!0,product:t="NONE"}={})=>{l=e,u=t})(e);const t=Object.getOwnPropertyDescriptor(Document.prototype,"cookie"),n=null==t?void 0:t.set,r=null==t?void 0:t.get;if(!n||!r)return void g.warn("No document.cookie capabilities found");if(!!!L())throw new Error("Failed to initialize AnalyticsWebClient. Analytics logging will not be set for document.cookie.");Object.defineProperty(document,"cookie",{get:r,set:Le(n),configurable:!0})},Re=async(e={})=>{try{await Ie(e)}catch(e){g.errorWithOperationalEvent({action:"initializeControlsError",message:"Failed to initialize browser storage controls. "+(e.message||"")})}}}])}));;
;
/* module-key = 'com.atlassian.crowd.user-provisioning-vertigo-plugin:impersonation-resources', location = 'user-provisioning-vertigo-module/js/atlassian/helpers/cookies.js' */
define('user-management-common/helpers/cookies', [
    'atlassian/libs/browser-storage-controls'
], function(
    browserStorageControls
) {
    return {
        readCookie: function (name) {
            return browserStorageControls.getCookie(name);
        }
    };
});
;
;
/* module-key = 'com.atlassian.crowd.user-provisioning-vertigo-plugin:impersonation-resources', location = 'user-provisioning-vertigo-module/js/atlassian/impersonation/impersonation.js' */
/**
 * This module displays an informational message with a link to drop the impersonation, if the current user is
 * being impersonated. This script is used in both user management and user provisioning plugins.
 */
define('user-management-common/impersonation/impersonation', [
    'jquery',
    'underscore',
    'user-management-common/flag',
    'user-management-common/helpers/cookies',
    'jira/featureflags/feature-manager',
], function (
    $,
    _,
    flag,
    cookies,
    FeatureManager,
) {
    var showImpersonationMessaging = function (username) {
        var message = AJS.format("You\'\'re temporarily logged in as {0}. When you\'\'re done, {1}switch back{2} to your account.",
            _.escape(impersonation.getDisplayName()),
            '<a id="impersonation-dismiss-trigger" href="#">', '</a>');

        var messageFlag = flag({ type: 'info', isHtml: true, body: message });

        $(messageFlag).find("#impersonation-dismiss-trigger").click(function (e) {
            e.preventDefault();
            impersonation.dropImpersonation().then(function () {
                if (username) {
                    window.open("/admin/users/view?username=" + encodeURIComponent(username), "_top");
                } else {
                    window.open("/admin/users", "_top");
                }
            });
        });
    };

    function showImpersonationFlag() {
        var message = AJS.format("You\'\'re temporarily logged in as another user. When you\'\'re done, {0}switch back{1} to your account.",
            '<a id="impersonation-dismiss-trigger" href="#">', '</a>');

        var messageFlag = flag({ type: 'info', isHtml: true, body: message });

        $(messageFlag).find('#impersonation-dismiss-trigger').click(function (e) {
            e.preventDefault();
            impersonation.getReleaseImpersonationLink().then(function (data) {
                window.open(data.link, '_top');
            });
        });
    }

    var impersonation = {
        init: function () {
            if (FeatureManager.isFeatureEnabled('jira-impersonation-cookie-deprecation')) {
                impersonation.getImpersonationData().then(function (data) {
                    if (data.isImpersonating) {
                        impersonation.userId = data.targetUserId;
                        showImpersonationFlag();
                    }
                });
            } else {
                if (impersonation.isImpersonated()) {
                    showImpersonationMessaging(impersonation.getUsername());
                } else if (impersonation.getUserId()) {
                    showImpersonationFlag();
                }
            }
        },

        getUserId: function () {
            if (FeatureManager.isFeatureEnabled('jira-impersonation-cookie-deprecation')) {
                return impersonation.userId;
            } else {
                return cookies.readCookie('um.user.impersonated.userid');
            }
        },

        getUsername: function () {
            return cookies.readCookie("um.user.impersonated.username");
        },

        getDisplayName: function () {
            return cookies.readCookie("um.user.impersonated.displayname");
        },

        getReleaseImpersonationLink: function () {
            var userId = impersonation.getUserId();
            var cloudId = AJS.Meta.get('cloud-id');
            return $.ajax({
                type: 'POST',
                url: '/gateway/api/adminhub/um/site/' + cloudId + '/users/' + userId + '/impersonate/release',
                dataType: 'json'
            });
        },

        dropImpersonation: function () {
            return $.ajax({
                type: "POST",
                contentType: 'application/json',
                url: "/admin/rest/um/1/impersonate/release"
            });
        },

        isImpersonated: function () {
            return !!impersonation.getUsername();
        },

        getImpersonationData: function () {
            var cloudId = AJS.Meta.get('cloud-id');
            return $.ajax({
                type: 'GET',
                url: '/gateway/api/impersonation?targetId=' + cloudId,
                dataType: 'json'
            });
        },
    };
    return impersonation;
});
;
;
/* module-key = 'com.atlassian.crowd.user-provisioning-vertigo-plugin:impersonation-resources', location = 'user-provisioning-vertigo-module/js/atlassian/impersonation-init.js' */
require(['jquery', 'user-management-common/impersonation/impersonation'],
function($, impersonation) {
    $(impersonation.init);
});;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/js/ajs-amd.js' */
define('pas/ajs', [], function () {
    'use strict';

    return AJS;
});;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/js/store_js/store.js' */
//
// store.js by Frank Kohlhepp
// Copyright (c) 2011 - 2012 Frank Kohlhepp
// https://github.com/frankkohlhepp/store-js
// License: MIT-license
//
(function () {
    var has = function (object, key) {
        return Object.prototype.hasOwnProperty.call(object, key);
    };

    var objectGetLength = function (object) {
        var count = 0;
        for (var key in object) {
            if (has(object, key)) {
                count++;
            }
        }

        return count;
    };

    var arrayIndexOf = function (array, item, from) {
        var length = array.length >>> 0;
        for (var i = (from < 0) ? Math.max(0, length + from) : from || 0; i < length; i++) {
            if (array[i] === item) {
                return i;
            }
        }

        return -1;
    };

    var arrayContains = function (array, item, from) {
        return arrayIndexOf(array, item, from) !== -1;
    };

    var arrayInclude = function (array, item) {
        if (!arrayContains(array, item)) {
            array.push(item);
        }
        return array;
    };

    var Store = this.Store = function (name, defaults, watcherSpeed) {
        this.name = name;
        this.defaults = defaults || {};
        this.watcherSpeed = watcherSpeed || 500;
        this.listeners = {};

        // Apply defaults
        this.applyDefaults();
    };

    Store.clear = function () {
        localStorage.clear();
    };

    Store.prototype.applyDefaults = function () {
        for (var key in this.defaults) {
            if (has(this.defaults, key) && this.get(key) === undefined) {
                this.set(key, this.defaults[key]);
            }
        }

        return this;
    };

    Store.prototype.watcher = function (force) {
        if (this.watcherTimer) {
            clearTimeout(this.watcherTimer);
        }

        if (objectGetLength(this.listeners) || force) {
            this.newObject = this.toObject();

            if (this.oldObject) {
                for (var key in this.newObject) {
                    if (has(this.newObject, key) && this.newObject[key] !== this.oldObject[key]) {
                        this.fireEvent(key, this.newObject[key]);
                    }
                }

                for (var key in this.oldObject) {
                    if (has(this.oldObject, key) && !has(this.newObject, key)) {
                        this.fireEvent(key, this.newObject[key]);
                    }
                }
            }

            this.oldObject = this.newObject;
            var that = this;
            this.watcherTimer = setTimeout(function () {
                that.watcher();
            }, this.watcherSpeed);
        }

        return this;
    };

    Store.prototype.get = function (name) {
        var value = localStorage.getItem("store." + this.name + "." + name);
        if (value === null) {
            return undefined;
        }
        try {
            return JSON.parse(value);
        } catch (e) {
            return null;
        }
    };

    Store.prototype.set = function (name, value) {
        if (value === undefined) {
            this.remove(name);
        } else {
            if (typeof value === "function") {
                value = null;
            }
            try {
                value = JSON.stringify(value);
            } catch (e) {
                value = null;
            }
            localStorage.setItem("store." + this.name + "." + name, value);
        }

        return this;
    };

    Store.prototype.remove = function (name) {
        localStorage.removeItem("store." + this.name + "." + name);
        return this.applyDefaults();
    };

    Store.prototype.reset = function () {
        var name = "store." + this.name + ".";
        for (var i = (localStorage.length - 1); i >= 0; i--) {
            if (localStorage.key(i).substring(0, name.length) === name) {
                localStorage.removeItem(localStorage.key(i));
            }
        }

        return this.applyDefaults();
    };

    Store.prototype.toObject = function () {
        var values = {};
        var name = "store." + this.name + ".";
        for (var i = (localStorage.length - 1); i >= 0; i--) {
            if (localStorage.key(i).substring(0, name.length) === name) {
                var key = localStorage.key(i).substring(name.length);
                var value = this.get(key);
                if (value !== undefined) {
                    values[key] = value;
                }
            }
        }

        return values;
    };

    Store.prototype.fromObject = function (values, merge) {
        if (!merge) {
            this.reset();
        }
        for (var key in values) {
            if (has(values, key)) {
                this.set(key, values[key]);
            }
        }

        return this;
    };

    Store.prototype.addEvent = function (selector, callback) {
        this.watcher(true);
        if (!this.listeners[selector]) {
            this.listeners[selector] = [];
        }
        arrayInclude(this.listeners[selector], callback);
        return this;
    };

    Store.prototype.removeEvent = function (selector, callback) {
        for (var i = (this.listeners[selector].length - 1); i >= 0; i--) {
            if (this.listeners[selector][i] === callback) {
                this.listeners[selector].splice(i, 1);
            }
        }

        if (!this.listeners[selector].length) {
            delete this.listeners[selector];
        }
        return this;
    };

    Store.prototype.fireEvent = function (name, value) {
        var selectors = [name, "*"];
        for (var i = 0; i < selectors.length; i++) {
            var selector = selectors[i];
            if (this.listeners[selector]) {
                for (var j = 0; j < this.listeners[selector].length; j++) {
                    this.listeners[selector][j](value, name, this.name);
                }
            }
        }

        return this;
    };
}());;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/js/store_js/store-amd.js' */
define("pas/js/store_js/store", function () {
    return Store;
});;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/js/pasConfig.js' */
define("pas/js/pas-config", [
    "jquery",
    "pas/ajs",
    "pas/js/store_js/store"
], function ($,
             AJS,
             Store) {
    "use strict";

    var MINUTE = 60 * 1000;

    return {
        timeUpdateInterval: MINUTE,
        pollingInterval: 15 * MINUTE,
        url: AJS.contextPath() + "/rest/pas/latest/announcement",
        store: new Store("Atlassian.PAS.Announcements." + document.location.hostname + AJS.contextPath() + "." + $("meta[name='ajs-remote-user']").attr('content')),
        nextAnnouncementKey: "nextAnnouncement",
        timeStampKey: "timeStamp",
        config: {
            url: AJS.contextPath() + "/rest/pas/latest/settings",
            timeStampKey: "configTimeStampKey",
            pollingInterval: 30 * 60 * 1000,
            currentConfigKey: "currentConfigKey"
        },
        cookieKey: AJS.contextPath().replace('/', '') + "_pas.dismiss"
    };
});;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/js/pas.js' */
require([
    "jquery",
    "aui/flag",
    "pas/ajs",
    "pas/js/pas-config"
], function ($,
             flag,
             AJS,
             PAS) {
    "use strict";

    AJS.toInit(function () {
        var showTimeout = null;
        var hideTimeout = null;
        var updateTimeout = null;
        var timeLeft = 0;

        var announcementSource;
        var projectKey;
        var issueNumber;

        var friendlyFormatDate = function (delay) {
            var padString = function (s, c, len) {
                s = "" + s; // ensure it's a string
                while (s.length < len) {
                    s = c + s;
                }
                return s;
            };
            var pluralize = function (val, unit) {
                var result = val + " " + unit;
                if (val != 1) {
                    result += "s";
                }
                return result;
            };

            var oneMinute = 60000;
            var oneHour = 3600000;
            var oneDay = 86400000;

            if (delay < oneMinute) {
                return "in less than a minute";
            }
            else if (delay < oneHour) {
                return "in " + pluralize(Math.round(delay / oneMinute), "min");
            }
            else if (delay < oneDay) {
                return "in " + pluralize(Math.round(delay / oneHour), "hour") + " " + pluralize(Math.round((delay % oneHour) / oneMinute), "minute");
            }
            else {
                var d = new Date();
                d.setSeconds(d.getSeconds() + Math.round(delay / 1000));
                return (
                    padString(d.getFullYear(), '0', 4) +
                    "/" +
                    padString(d.getMonth() + 1, '0', 2) +
                    "/" +
                    padString(d.getDate(), '0', 2) +
                    " " +
                    padString(d.getHours(), '0', 2) +
                    ":" +
                    padString(d.getMinutes(), '0', 2)
                );
            }
        };

        var clearState = function () {
            if (showTimeout != null) {
                clearTimeout(showTimeout);
            }
            if (hideTimeout != null) {
                clearTimeout(hideTimeout);
            }
            if (updateTimeout != null) {
                clearInterval(updateTimeout);
            }
            document.getElementById("pas-announcement").close();
        };

        var showAnnouncement = function () {
            var announcementContent = PAS.announcementText;
            var announcementUrl = PAS.announcementUrl || "";
            var announcementTime = PAS.announcementTime;
            var announcementId = PAS.announcementId;

            var announcementTicket = PAS.announcementTicket;
            announcementSource = PAS.announcementSource;

            var projectKeyPattern = /([A-Z])\w+/g;
            var issueNumberPattern = /\d+/g;

            projectKey = projectKeyPattern.exec(announcementTicket);
            issueNumber = issueNumberPattern.exec(announcementTicket);

            function escapeRegExp(str) {
                return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
            }

            var announcementTargetPath = escapeRegExp(PAS.announcementTargetPath) || "";
            var announcementTargetPathRegex = new RegExp(announcementTargetPath);

            var announcementFlag;

            if (location.href.match(announcementTargetPathRegex) !== null) {
                announcementFlag = flag({
                    type: "info",
                    title: "Public service announcement",
                    body: announcementContent + announcementUrl + announcementTime,
                    close: "manual"
                });

                if (announcementSource == "alertr") {
                    triggerPasAlertrAnalytics({
                        name: "pas.alertr.announcement.display"
                    });
                }
            }

            if (announcementFlag !== undefined) {
                announcementFlag.setAttribute("id", "pas-announcement");
                announcementFlag.setAttribute("announcementId", announcementId);

                announcementFlag.addEventListener("aui-flag-close", function () {
                    dismissAnnouncement();
                });
            }

            addUrlClickedEventHandler();
        };

        var addUrlClickedEventHandler = function () {
            AJS.$("#more-info").on('click', function () {
                if (announcementSource == "alertr") {
                    triggerPasAlertrAnalytics({
                        name: "pas.alertr.announcement.url.clicked"
                    });
                }
            });
        };

        var dismissAnnouncement = function () {
            var announcementId = PAS.announcementId;
            var expiry = new Date();
            var cookieValue;

            expiry.setMonth(expiry.getMonth() + 1);
            cookieValue = announcementId + "; expires=" + expiry.toUTCString();
            document.cookie = PAS.cookieKey + "=" + cookieValue + "; path=/";
            AJS.trigger('analyticsEvent', {
                name: 'com.atlassian.plugins.pas.dismiss-announcement.click',
                data: {message: $("#pas-announcement span:first").text()}
            });

            if (announcementSource == "alertr") {
                triggerPasAlertrAnalytics({
                    name: "pas.alertr.announcement.dismissed"
                });
            }
        };

        var checkDismissed = function (announcementId, cookieKey) {
            var cookies = document.cookie.split(";");
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i];
                var pos = cookie.indexOf("=");
                var key = cookie.substr(0, pos).trim();
                var value = cookie.substr(pos + 1).trim();
                if (key == cookieKey) {
                    return value == announcementId;
                }
            }
            return false;
        };

        var updateTimeLeft = function () {
            if (timeLeft > 0) {
                var newTimeLeft = timeLeft - PAS.timeUpdateInterval;
                timeLeft = newTimeLeft;
                PAS.announcementTime = Atlassian.PAS.Templates.pasTime({
                    time: friendlyFormatDate(newTimeLeft)
                });
            }
            else {
                clearInterval(updateTimeout);
                updateTimeout = null;
            }
        };

        var triggerPasAlertrAnalytics = function (event) {
            var key = projectKey[0];
            AJS.trigger('analyticsEvent', {
                name: event.name,
                data: {issueNumber: issueNumber, project: key}
            });
        };

        var scheduleAnnouncementToAppear = function () {
            function adjustTimeToStart() {
                return data.timeToStart - getTimeSinceLastPoll();
            }

            var data = getFromLocalStorage(PAS.nextAnnouncementKey);

            // Do nothing if no announcement or if the user dismissed it
            if (data == null || data.message == null || checkDismissed(data.id, PAS.cookieKey)) {
                return;
            }

            timeLeft = data.timeLeft;

            PAS.announcementText = data.message;
            PAS.announcementTime = Atlassian.PAS.Templates.pasTime({
                time: friendlyFormatDate(timeLeft)
            });
            updateTimeout = setInterval(updateTimeLeft, PAS.timeUpdateInterval);
            if (data.url) {
                PAS.announcementUrl = Atlassian.PAS.Templates.pasUrl({
                    url: data.url
                });
            }

            PAS.announcementTargetPath = data.targetPath;
            PAS.announcementId = data.id;

            var timeToHide = data.duration;
            data.timeToStart = adjustTimeToStart();

            if (data.source) {
                PAS.announcementSource = data.source;
            }
            if (data.incidentTicket) {
                PAS.announcementTicket = data.incidentTicket;
            }

            if (data.timeToStart > 0) {
                timeToHide += data.timeToStart;
                showTimeout = setTimeout(function () {
                    showAnnouncement();
                }, data.timeToStart);
            } else {
                showAnnouncement();
            }

            if (timeToHide > 0) {
                hideTimeout = setTimeout(function () {
                    clearState();
                }, timeToHide);
            }
        };

        function pollForMessage(callback) {
            $.ajax({
                type: "GET",
                contentType: "application/json",
                url: PAS.url,
                cache: false,
                global: false,
                timeout: 5000,
                success: function (json, resultStatus) {
                    setInLocalStorage(PAS.timeStampKey, nowInMs());
                    setInLocalStorage(PAS.nextAnnouncementKey, json);
                    callback();
                }, error: function (xhr, resultStatus, e) {
                    AJS.log("Could not get announcement from server: " + e);
                }

            });
        }

        var nowInMs = function () {
            return new Date().getTime();
        };

        var getTimeSinceLastPoll = function () {
            return (nowInMs() - getFromLocalStorage(PAS.timeStampKey));
        };

        function getFromLocalStorage(key) {
            return PAS.store.get(key);
        }

        function setInLocalStorage(key, value) {
            return PAS.store.set(key, value);
        }

        function isStale(timeStampKey, pollingInterval) {
            var previousPollTimeStamp = getFromLocalStorage(timeStampKey);
            var timeSinceLastPoll = nowInMs() - previousPollTimeStamp;
            return previousPollTimeStamp == undefined || timeSinceLastPoll > pollingInterval
        }

        function announcementCacheIsStale() {
            return isStale(PAS.timeStampKey, PAS.pollingInterval);
        }

        function configurationCacheIsStale() {
            return isStale(PAS.config.timeStampKey, PAS.config.pollingInterval);
        }

        function setupAnalyticsEvents() {
            $("#more-info").live("click", function (event) {
                AJS.trigger('analyticsEvent', {
                    name: 'com.atlassian.plugins.pas.more-info.click',
                    data: {message: $("#pas-announcement span:first").text()}
                });
            });
        }

        function pollForMessageIfNecessary() {
            if (announcementCacheIsStale()) {
                pollForMessage(scheduleAnnouncementToAppear);
            } else {
                scheduleAnnouncementToAppear();
            }
        }

        setupAnalyticsEvents();

        pollForMessageIfNecessary();
    });
});

;
;
/* module-key = 'com.atlassian.pas:pas-everypage-static', location = 'public-announcement-module/templates/soy/pas.soy' */
// This file was automatically generated from pas.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Atlassian.PAS.Templates.
 */

if (typeof Atlassian == 'undefined') { var Atlassian = {}; }
if (typeof Atlassian.PAS == 'undefined') { Atlassian.PAS = {}; }
if (typeof Atlassian.PAS.Templates == 'undefined') { Atlassian.PAS.Templates = {}; }


Atlassian.PAS.Templates.pasTime = function(opt_data, opt_ignored) {
  return '<span class="pas-announcement-time">' + soy.$$escapeHtml(opt_data.time) + '</span>';
};
if (goog.DEBUG) {
  Atlassian.PAS.Templates.pasTime.soyTemplateName = 'Atlassian.PAS.Templates.pasTime';
}


Atlassian.PAS.Templates.pasUrl = function(opt_data, opt_ignored) {
  return '<p><a id="more-info" target="_blank" href=\'' + soy.$$escapeHtml(opt_data.url) + '\'>' + soy.$$escapeHtml('More information') + '</a></p>';
};
if (goog.DEBUG) {
  Atlassian.PAS.Templates.pasUrl.soyTemplateName = 'Atlassian.PAS.Templates.pasUrl';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devsummarycf-resources-init', location = 'jira-development-integration-plugin/js/customfields/devsummary/dev-summary-custom-field-init.js' */
"use strict";require(["jira/skate","jquery"],function(e,t){var i="wrc!com.atlassian.jira.plugins.jira-development-integration-plugin:devsummarycf-resources";e("fusion-devsummary-cf",{type:e.type.CLASS,created:function(e){WRM.require([i],function(){var i=require("jira-development-status/customfields/dev-summary-custom-field-column-view"),r=require("jira-development-status/component/tooltip"),o=t(e);new i({el:o}),r.tipsify({selector:".fusion-widget-tooltip",context:o,html:!0})})}})});;
;
/* module-key = 'com.pyxis.greenhopper.jira:gh-create-board-adg3-no-condition', location = 'jira-agile-module/includes/js/sidebar/create-board-adg3.js' */
define("jira-agile/sidebar/create-board-adg3",["wrm/require","jira/analytics"],function(r,i){"use strict";var t="gh.rapid.board.create";function d(){var e=0<arguments.length&&void 0!==arguments[0]&&arguments[0];function a(){e?GH.StartWizardView.startWizardWithoutProjectCreate():GH.StartWizardView.startWizardWithUserConfigCheck(),i.send({name:"jira.frontend.fe.navigation.scope-switcher.action.click",properties:{actionId:t,pageMode:GH&&GH.RapidBoard&&GH.RapidBoard.State&&GH.RapidBoard.State.getMode&&GH.RapidBoard.State.getMode()||"other"}}),AJS.$(GH).unbind("WizardViewLoaded",a)}return AJS.dim(),r(["wr!com.pyxis.greenhopper.jira:gh-create-board"],function(){if(GH.StartWizardView)return a;AJS.$(GH).bind("WizardViewLoaded",a)}())}return{handleCreateBoardAction:function(e,a){if(a.actionId===t)return e.preventDefault(),d(!0)},openCreateBoardModal:d}}),function(){var a=require("jira-agile/sidebar/create-board-adg3");AJS.$(function(){JIRA&&JIRA.API&&JIRA.API.getSidebar().done(function(e){e.on(e.events.SCOPE_SWITCHER_SELECT_ACTION,a.handleCreateBoardAction,!0)})})}();;;try{window.performance.mark('jira.webresources,jira.webresources,com.atlassian.administration.atlassian-admin-quicksearch-jira,jira.webresources,com.atlassian.jira.plugins.jira-development-integration-plugin,com.atlassian.analytics.analytics-client,com.atlassian.jira.jira-issue-nav-plugin,com.atlassian.crowd.user-provisioning-vertigo-plugin,com.atlassian.jira.jira-atlaskit-plugin,com.atlassian.pas,com.atlassian.auiplugin,com.atlassian.jira.plugins.jira-development-integration-plugin,com.pyxis.greenhopper.jira_batch_file_eval:end');} catch(e){};